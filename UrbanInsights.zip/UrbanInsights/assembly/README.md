# assembly/

`severity.asm` is the real severity classifier - `backend/Complaint.cpp`'s
`evaluateSeverity()` calls into it directly. Full writeup, formulas, and
toolchain notes: `../docs/ASSEMBLY_CONCEPTS_MAP.md`.

## Build

Handled automatically by the root `Makefile` (`make run` from the project
root assembles this with NASM and links it into the same binary as the
C++ backend). To assemble it on its own:

```bash
nasm -f elf64 severity.asm -o severity.o
```

Requires NASM (`apt install nasm` / `sudo apt-get install nasm`).

## Independent 64-bit COA practical

`coa_demo.asm` is a separate x86-64 NASM exercise; it does not replace or
change the severity engine. It demonstrates:

- Computational arithmetic: estimate a category's total repair budget
  by multiplying its complaint count by a per-complaint estimate using
  successive addition and right/left shifts (add-and-shift).
- String processing: scan comma-separated complaint categories and count
  exact category matches.

The runner uses a small built-in sample list, not the live project
database: `traffic, garbage, water, traffic, electricity, garbage,
traffic`. It asks for a category and estimated cost per complaint, then
prints the matching count and estimated budget. Category matching is
lowercase and case-sensitive. The C++ runner handles input and validates
overflow; the arithmetic and category scanning are performed in assembly.
The functions use the Windows x64 calling convention. From the project
root, build with `make coa-demo` and run `bin/coa_demo.exe`. The target
creates separate `coa_demo` object and executable files in `bin/`.

## Combined severity + COA executable

`urban_insights_demo.asm` contains the severity classifier, category
counter, and shift-add multiplier in one NASM source. Its C++ runner offers
severity-only, COA-only, and combined modes. In combined mode, choose one
category, enter impact and urgency, then a per-complaint repair estimate;
the program reports both severity and the sample-list budget. Like the
standalone COA practical, the sample list is illustrative and does not read
from PostgreSQL.

From the project root, build and run it with:

```powershell
make assembly-demo
bin/urban_insights_demo.exe
```
