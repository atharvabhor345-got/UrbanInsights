; Independent 64-bit COA practical for Urban Insights.
; Built as NASM win64 and called using the Windows x64 ABI.

bits 64
default rel

section .text
global multiply_shift_add
global count_category

; uint64_t multiply_shift_add(uint64_t multiplicand, uint64_t multiplier)
; Windows x64: RCX = multiplicand, RDX = multiplier, RAX = result.
; Used to estimate the total repair budget for a complaint category.
multiply_shift_add:
    xor  rax, rax
.multiply_loop:
    test rdx, 1
    jz   .skip_add
    add  rax, rcx
.skip_add:
    shl  rcx, 1
    shr  rdx, 1
    jnz  .multiply_loop
    ret

; uint64_t count_category(const char *categories, const char *target)
; Windows x64: RCX = comma-separated categories, RDX = target, RAX = count.
; Category matching is exact and case-sensitive.
count_category:
    xor  r9d, r9d
.next_category:
    movzx eax, byte [rcx]
    test al, al
    jz   .count_done
    cmp  al, ' '
    je   .skip_separator
    cmp  al, ','
    je   .skip_separator
    cmp  al, ';'
    je   .skip_separator

    mov  r8, rcx
    mov  r10, rdx
.compare_character:
    mov  al, [r8]
    mov  r11b, [r10]
    test r11b, r11b
    jz   .check_category_end
    test al, al
    jz   .skip_category
    cmp  al, r11b
    jne  .skip_category
    inc  r8
    inc  r10
    jmp  .compare_character

.check_category_end:
    cmp  al, 0
    je   .matched
    cmp  al, ' '
    je   .matched
    cmp  al, ','
    je   .matched
    cmp  al, ';'
    je   .matched

.skip_category:
    movzx eax, byte [rcx]
    test al, al
    jz   .count_done
    cmp  al, ' '
    je   .next_category
    cmp  al, ','
    je   .next_category
    cmp  al, ';'
    je   .next_category
    inc  rcx
    jmp  .skip_category

.matched:
    inc  r9
.skip_separator:
    inc  rcx
    jmp  .next_category

.count_done:
    mov  rax, r9
    ret

section .note.GNU-stack noalloc noexec nowrite
