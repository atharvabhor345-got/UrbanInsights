#include <cstdint>
#include <iostream>
#include <limits>
#include <string>

extern "C" std::uint64_t multiply_shift_add(std::uint64_t multiplicand,
                                           std::uint64_t multiplier);
extern "C" std::uint64_t count_category(const char* categories,
                                       const char* target);

int main() {
    constexpr char sample_categories[] =
        "traffic, garbage, water, traffic, electricity, garbage, traffic";
    std::string category;
    std::uint64_t cost_per_complaint = 0;

    std::cout << "Urban Insights sample complaint summary\n"
              << "Categories: traffic, garbage, water, electricity\n"
              << "Enter a category: ";
    if (!(std::cin >> category) ||
        (category != "traffic" && category != "garbage" &&
         category != "water" && category != "electricity")) {
        std::cerr << "Enter one of the listed categories in lowercase.\n";
        return 1;
    }

    std::cout << "Enter estimated repair cost per complaint (whole number): ";
    if (!(std::cin >> cost_per_complaint)) {
        std::cerr << "Enter a valid non-negative whole number.\n";
        return 1;
    }

    const std::uint64_t complaint_count =
        count_category(sample_categories, category.c_str());
    if (complaint_count != 0 &&
        cost_per_complaint >
            std::numeric_limits<std::uint64_t>::max() / complaint_count) {
        std::cerr << "The estimated total is too large for a 64-bit result.\n";
        return 1;
    }

    const std::uint64_t estimated_budget =
        multiply_shift_add(cost_per_complaint, complaint_count);

    std::cout << "\nMatching complaints: " << complaint_count << '\n'
              << "Estimated budget: " << estimated_budget << '\n';
    return 0;
}
