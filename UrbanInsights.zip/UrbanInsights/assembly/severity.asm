; =================================================================
; URBAN INSIGHTS -- assembly/severity.asm
; =================================================================
; The real severity engine. backend/Complaint.cpp's per-category
; calculatePriorityScore() overrides are marked as an "interim
; formula" with a comment pointing here - this is that hand-off:
; Complaint::evaluateSeverity() (backend/Complaint.cpp) now calls
; straight into calculateSeverityAsm() below for the authoritative
; Low/Medium/High classification instead of doing the threshold
; check in C++.
;
; Toolchain note: the course material describes an "80386 module"
; using MOV/ADD/CMP and conditional jumps - genuine 80386-level
; instructions, all present below. What's adapted for this sandbox
; is the CALLING CONVENTION: rather than 16-bit DOS/TASM (INT 21h,
; segmented memory) this is NASM targeting x86-64 Linux, called
; directly from the real C++ backend with the System V AMD64 ABI,
; because that's what actually links into a running program here.
; The instruction-level content - registers, MOV, ADD, IMUL, CMP,
; conditional jumps - is the same either way. See README.md in this
; folder for how to retarget this to 32-bit/DOS-style tooling if
; your course specifically grades against TASM/MASM output.
;
; ----------------------------------------------------------------
; int calculateSeverityAsm(int category, int impactScore, int urgencyScore)
;
;   System V AMD64: category=EDI, impact=ESI, urgency=EDX
;   Windows x64:    category=ECX, impact=EDX, urgency=R8D
%ifidn __OUTPUT_FORMAT__, win64
%define ARG_CATEGORY ecx
%define ARG_IMPACT   edx
%define ARG_URGENCY  r8d
%else
%define ARG_CATEGORY edi
%define ARG_IMPACT   esi
%define ARG_URGENCY  edx
%endif
;   returns       (EAX) : 0=Low 1=Medium 2=High
;
; Per-category weighted score (integer arithmetic, matches the
; weights already used in backend/Complaint.cpp's interim formulas
; so behaviour doesn't silently change when this gets wired in):
;
;   Traffic     : (impact*6  + urgency*4 ) / 10
;   Garbage     : (impact*5  + urgency*5 ) / 10
;   Electricity : (impact*7  + urgency*3 ) / 10
;   Water       : (impact*65 + urgency*35) / 100
;
; Thresholds (Integrated Review slides - "Severity Calculation
; Flow"): score > 7 -> High, score >= 4 -> Medium, else Low.
;
; Register use: only EAX/ECX/EDX/ESI/EDI (all caller-saved in the
; System V AMD64 ABI) plus a properly paired push/pop of RBP for the
; stack frame - nothing callee-saved is clobbered, so this is safe
; to call from C++ without the compiler's own register allocation
; getting silently corrupted.
; =================================================================

BITS 64
section .text
global calculateSeverityAsm

calculateSeverityAsm:
    push rbp
    mov  rbp, rsp

    cmp  ARG_CATEGORY, 0
    je   .traffic
    cmp  ARG_CATEGORY, 1
    je   .garbage
    cmp  ARG_CATEGORY, 2
    je   .electricity
    jmp  .water                 ; anything else (or 3) falls through to water

.traffic:
    mov  eax, ARG_IMPACT       ; EAX = impactScore
    imul eax, eax, 6              ; EAX = impact*6
    imul edx, ARG_URGENCY, 4              ; EDX = urgency*4
    add  eax, edx                 ; EAX = impact*6 + urgency*4
    mov  ecx, 10                  ; ECX = divisor   ;(Impact × 6 + Urgency × 4) / 10
    jmp  .divide

.garbage:
    mov  eax, ARG_IMPACT
    imul eax, eax, 5
    imul edx, ARG_URGENCY, 5
    add  eax, edx
    mov  ecx, 10
    jmp  .divide

.electricity:
    mov  eax, ARG_IMPACT
    imul eax, eax, 7
    imul edx, ARG_URGENCY, 3
    add  eax, edx
    mov  ecx, 10
    jmp  .divide

.water:
    mov  eax, ARG_IMPACT
    imul eax, eax, 65
    imul edx, ARG_URGENCY, 35
    add  eax, edx
    mov  ecx, 100
    ; fall through to .divide

.divide:
    cdq                           ; sign-extend EAX into EDX:EAX before IDIV
    idiv ecx                      ; EAX = score (integer division)

    ; classify: score < 4 -> Low, score > 7 -> High, else Medium
    cmp  eax, 4
    jl   .low
    cmp  eax, 7
    jg   .high

    mov  eax, 1                   ; Medium
    jmp  .done
.low:
    mov  eax, 0                   ; Low
    jmp  .done
.high:
    mov  eax, 2                   ; High
.done:
    pop  rbp
    ret

; Marks this object as not needing an executable stack - without this,
; linking hand-written NASM against g++-compiled code prints a
; "missing .note.GNU-stack section" warning. Adds no code, just a
; linker metadata section.
section .note.GNU-stack noalloc noexec nowrite

