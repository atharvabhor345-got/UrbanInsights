#include <iostream>
extern "C" int calculateSeverityAsm(int category,int impact,int urgency);
int main(int argc,char**argv){ if(argc!=4){std::cerr<<"usage: severity_runner <category 0-3> <impact 0-10> <urgency 0-10>\n";return 2;} int c=calculateSeverityAsm(std::stoi(argv[1]),std::stoi(argv[2]),std::stoi(argv[3])); std::cout<<c<<"\n"; return 0; }
