; Combined severity and COA practicals for the Urban Insights sample app.
; Built as NASM win64 and called using the Windows x64 ABI.

bits 64
default rel

%ifidn __OUTPUT_FORMAT__, win64
%define ARG_CATEGORY rcx
%define ARG_IMPACT   rdx
%define ARG_URGENCY  r8
%else
%define ARG_CATEGORY rdi
%define ARG_IMPACT   rsi
%define ARG_URGENCY  rdx
%endif

section .text
global calculateSeverityAsm
global multiply_shift_add
global count_category

; int calculateSeverityAsm(int64_t category, int64_t impact, int64_t urgency)
; Categories: 0=traffic, 1=garbage, 2=electricity, 3=water.
; Returns: 0=Low, 1=Medium, 2=High.
calculateSeverityAsm:
    push rbp
    mov  rbp, rsp

    cmp  ARG_CATEGORY, 0
    je   .traffic
    cmp  ARG_CATEGORY, 1
    je   .garbage
    cmp  ARG_CATEGORY, 2
    je   .electricity
    jmp  .water

.traffic:
    imul rax, ARG_IMPACT, 6
    imul rdx, ARG_URGENCY, 4
    add  rax, rdx
    mov  rcx, 10
    jmp  .divide

.garbage:
    imul rax, ARG_IMPACT, 5
    imul rdx, ARG_URGENCY, 5
    add  rax, rdx
    mov  rcx, 10
    jmp  .divide

.electricity:
    imul rax, ARG_IMPACT, 7
    imul rdx, ARG_URGENCY, 3
    add  rax, rdx
    mov  rcx, 10
    jmp  .divide

.water:
    imul rax, ARG_IMPACT, 65
    imul rdx, ARG_URGENCY, 35
    add  rax, rdx
    mov  rcx, 100

.divide:
    cqo
    idiv rcx
    cmp  eax, 4
    jl   .low
    cmp  eax, 7
    jg   .high
    mov  eax, 1
    jmp  .severity_done
.low:
    xor  eax, eax
    jmp  .severity_done
.high:
    mov  eax, 2
.severity_done:
    pop  rbp
    ret

; uint64_t multiply_shift_add(uint64_t multiplicand, uint64_t multiplier)
; Windows x64: RCX=multiplicand, RDX=multiplier, RAX=result.
multiply_shift_add:
    xor  rax, rax
.multiply_loop:
    test rdx, 1
    jz   .skip_add
    add  rax, rcx
.skip_add:
    shl  rcx, 1
    shr  rdx, 1
    jnz  .multiply_loop
    ret

; uint64_t count_category(const char *categories, const char *target)
; Windows x64: RCX=comma-separated list, RDX=target, RAX=count.
; Matching is exact and case-sensitive; comma, semicolon, and spaces separate tokens.
count_category:
    xor  r9d, r9d
.next_category:
    movzx eax, byte [rcx]
    test al, al
    jz   .count_done
    cmp  al, ' '
    je   .skip_separator
    cmp  al, ','
    je   .skip_separator
    cmp  al, ';'
    je   .skip_separator

    mov  r8, rcx
    mov  r10, rdx
.compare_character:
    mov  al, [r8]
    mov  r11b, [r10]
    test r11b, r11b
    jz   .check_category_end
    test al, al
    jz   .skip_category
    cmp  al, r11b
    jne  .skip_category
    inc  r8
    inc  r10
    jmp  .compare_character

.check_category_end:
    cmp  al, 0
    je   .matched
    cmp  al, ' '
    je   .matched
    cmp  al, ','
    je   .matched
    cmp  al, ';'
    je   .matched

.skip_category:
    movzx eax, byte [rcx]
    test al, al
    jz   .count_done
    cmp  al, ' '
    je   .next_category
    cmp  al, ','
    je   .next_category
    cmp  al, ';'
    je   .next_category
    inc  rcx
    jmp  .skip_category

.matched:
    inc  r9
.skip_separator:
    inc  rcx
    jmp  .next_category

.count_done:
    mov  rax, r9
    ret

section .note.GNU-stack noalloc noexec nowrite