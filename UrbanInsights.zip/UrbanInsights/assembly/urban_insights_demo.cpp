#include <cstdint>
#include <iostream>
#include <limits>
#include <string>

extern "C" int calculateSeverityAsm(std::int64_t category, std::int64_t impact,
                                     std::int64_t urgency);
extern "C" std::uint64_t multiply_shift_add(std::uint64_t multiplicand,
                                             std::uint64_t multiplier);
extern "C" std::uint64_t count_category(const char* categories, const char* target);

namespace {

constexpr const char* categoryNames[] = {
    "traffic", "garbage", "electricity", "water"
};
constexpr char sampleCategories[] =
    "traffic, garbage, water, traffic, electricity, garbage, traffic";

int categoryId(const std::string& category) {
    for (int i = 0; i < 4; ++i) {
        if (category == categoryNames[i]) return i;
    }
    return -1;
}

bool readCategory(std::string& category) {
    std::cout << "Category (traffic/garbage/electricity/water): ";
    if (!(std::cin >> category) || categoryId(category) < 0) {
        std::cerr << "Enter one of the listed categories in lowercase.\n";
        return false;
    }
    return true;
}

bool readScores(std::int64_t& impact, std::int64_t& urgency) {
    std::cout << "Impact (0-10): ";
    if (!(std::cin >> impact) || impact < 0 || impact > 10) {
        std::cerr << "Impact must be a whole number from 0 to 10.\n";
        return false;
    }
    std::cout << "Urgency (0-10): ";
    if (!(std::cin >> urgency) || urgency < 0 || urgency > 10) {
        std::cerr << "Urgency must be a whole number from 0 to 10.\n";
        return false;
    }
    return true;
}

const char* severityName(int severity) {
    constexpr const char* names[] = {"Low", "Medium", "High"};
    return names[severity];
}

bool readRepairCost(std::uint64_t& repairCost) {
    std::cout << "Estimated repair cost per complaint (whole number): ";
    if (!(std::cin >> repairCost)) {
        std::cerr << "Enter a valid non-negative whole number.\n";
        return false;
    }
    return true;
}

bool printBudget(const std::string& category, std::uint64_t repairCost) {
    const std::uint64_t count = count_category(sampleCategories, category.c_str());
    if (count != 0 && repairCost > std::numeric_limits<std::uint64_t>::max() / count) {
        std::cerr << "The estimated total is too large for a 64-bit result.\n";
        return false;
    }
    const std::uint64_t budget = multiply_shift_add(repairCost, count);
    std::cout << "Matching complaints in sample: " << count << '\n'
              << "Estimated budget: " << budget << '\n';
    return true;
}

bool runSeverity(const std::string& category) {
    std::int64_t impact = 0;
    std::int64_t urgency = 0;
    if (!readScores(impact, urgency)) return false;
    const int severity = calculateSeverityAsm(categoryId(category), impact, urgency);
    std::cout << "Assembly severity result: " << severityName(severity) << '\n';
    return true;
}

bool runCoa(const std::string& category) {
    std::uint64_t repairCost = 0;
    return readRepairCost(repairCost) && printBudget(category, repairCost);
}

} // namespace

int main() {
    std::cout << "Urban Insights | Combined Assembly Demo\n"
              << "1. Severity classification\n"
              << "2. COA category count and repair budget\n"
              << "3. Run both\n"
              << "Choose (1-3): ";

    int choice = 0;
    if (!(std::cin >> choice) || choice < 1 || choice > 3) {
        std::cerr << "Choose 1, 2, or 3.\n";
        return 1;
    }

    std::string category;
    if (!readCategory(category)) return 1;
    if ((choice == 1 || choice == 3) && !runSeverity(category)) return 1;
    if ((choice == 2 || choice == 3) && !runCoa(category)) return 1;
    return 0;
}