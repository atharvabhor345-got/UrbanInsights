-- Development-only credentials for the seeded administrator accounts.
-- Change these credentials before using any non-local deployment.
BEGIN;

UPDATE users
SET password_hash = 'pbkdf2_sha256$120000$557262616e496e73696768747341646d696e44656d6f$0ea7998fcaf934447307ef2dd46a23338fa6e75f4aa9917d581045d3599e633a'
WHERE email IN ('priya@uinsights.gov.in', 'karan@uinsights.gov.in')
  AND role IN ('admin', 'super_admin');

COMMIT;