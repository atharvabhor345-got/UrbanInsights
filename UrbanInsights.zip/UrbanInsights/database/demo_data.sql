-- ================================================================
-- Urban Insights - demo_data.sql
-- Purpose:
--   Populate the EXISTING urbaninsights database with deterministic
--   demonstration data for the WebGL map and category filters.
--
-- IMPORTANT:
--   1. Run schema.sql + seed.sql first.
--   2. Run this file against the same urbaninsights database.
--   3. This file does NOT recreate tables, states, or districts.
--   4. It creates a demo city for every district that has no city.
--   5. It creates four demo complaints per district (one per category).
--   6. It is safe to run again: Demo complaints are identified by
--      locality values beginning with 'DEMO-MAP-'.
--
-- Resulting map design:
--   State groups intentionally contain HIGH, MEDIUM, LOW, and NONE
--   states so the map displays different severity colors.
--
-- Categories:
--   traffic, garbage, electricity, water
--
-- Severity distribution:
--   Each state's demo profile is determined from its state_id.
--   HIGH-profile states have at least one HIGH complaint.
--   MEDIUM-profile states have MEDIUM/LOW complaints but no HIGH.
--   LOW-profile states have LOW complaints only.
--   NONE-profile states receive no demo complaints.
--
-- Existing seed complaints are preserved.
-- ================================================================

BEGIN;

-- ------------------------------------------------
-- 1. Ensure every district has a city
-- ------------------------------------------------
-- Existing cities such as Pune, Mumbai, Nashik, Bengaluru,
-- Jaipur and New Delhi are preserved.
--
-- For a district without a city, create:
--     "Demo City - <district name>"
--
-- The city uses the district's stored coordinates.

INSERT INTO cities (
    state_id,
    district_id,
    name,
    latitude,
    longitude
)
SELECT
    d.state_id,
    d.id,
    LEFT('Demo City - ' || d.name, 100),
    d.latitude,
    d.longitude
FROM districts d
WHERE NOT EXISTS (
    SELECT 1
    FROM cities c
    WHERE c.district_id = d.id
)
AND NOT EXISTS (
    SELECT 1
    FROM cities c
    WHERE c.state_id = d.state_id
      AND c.name = LEFT('Demo City - ' || d.name, 100)
);

-- ------------------------------------------------
-- 2. Temporary district/city mapping
-- ------------------------------------------------
-- One row represents one district.
-- district_no is used only to make the demonstration pattern
-- deterministic.

CREATE TEMP TABLE demo_districts
ON COMMIT DROP
AS
SELECT
    d.id AS district_id,
    d.state_id,
    s.name AS state_name,
    d.name AS district_name,
    c.id AS city_id,
    ROW_NUMBER() OVER (
        ORDER BY d.state_id, d.id
    ) AS district_no,
    DENSE_RANK() OVER (
        ORDER BY d.state_id
    ) AS state_no
FROM districts d
JOIN states s
    ON s.id = d.state_id
JOIN LATERAL (
    SELECT c1.id
    FROM cities c1
    WHERE c1.district_id = d.id
    ORDER BY
        CASE
            WHEN c1.name NOT LIKE 'Demo City - %' THEN 0
            ELSE 1
        END,
        c1.id
    LIMIT 1
) c
    ON TRUE;

-- ------------------------------------------------
-- 3. Insert demo complaints
-- ------------------------------------------------
--
-- Each district gets four categories unless the state is assigned
-- the NONE profile.
--
-- State profile:
--
--   state_no % 4 = 1 -> HIGH profile
--   state_no % 4 = 2 -> MEDIUM profile
--   state_no % 4 = 3 -> LOW profile
--   state_no % 4 = 0 -> NONE profile
--
-- Category position:
--   1 = traffic
--   2 = garbage
--   3 = electricity
--   4 = water
--
-- This gives:
--
-- HIGH state:
--   traffic      HIGH
--   garbage      MEDIUM
--   electricity  LOW
--   water        MEDIUM
--
-- MEDIUM state:
--   traffic      MEDIUM
--   garbage      LOW
--   electricity  LOW
--   water        MEDIUM
--
-- LOW state:
--   all categories LOW
--
-- NONE state:
--   no demo complaints
--
-- Therefore:
--   * ALL filter shows HIGH + MEDIUM + LOW + NONE
--   * category filters produce visibly different map patterns
--   * district drilldown also has different severities
--
-- Severity values are stored explicitly because this is demo seed data.
-- The normal citizen POST flow still calculates severity through the
-- existing backend/Assembly pipeline.

WITH demo_categories AS (
    SELECT *
    FROM (
        VALUES
            (1, 'traffic'::text),
            (2, 'garbage'::text),
            (3, 'electricity'::text),
            (4, 'water'::text)
    ) AS v(category_no, category)
),
demo_rows AS (
    SELECT
        dd.district_id,
        dd.state_id,
        dd.state_name,
        dd.district_name,
        dd.city_id,
        dd.state_no,
        dd.district_no,
        dc.category_no,
        dc.category,

        CASE
            WHEN dd.state_no % 4 = 1 AND dc.category_no = 1
                THEN 'high'
            WHEN dd.state_no % 4 = 1 AND dc.category_no IN (2, 4)
                THEN 'medium'
            WHEN dd.state_no % 4 = 1 AND dc.category_no = 3
                THEN 'low'

            WHEN dd.state_no % 4 = 2 AND dc.category_no IN (1, 4)
                THEN 'medium'
            WHEN dd.state_no % 4 = 2
                THEN 'low'

            WHEN dd.state_no % 4 = 3
                THEN 'low'

            ELSE NULL
        END AS severity
    FROM demo_districts dd
    CROSS JOIN demo_categories dc
),
scored AS (
    SELECT
        *,
        CASE severity
            WHEN 'high' THEN
                CASE
                    WHEN category = 'traffic' THEN 9
                    WHEN category = 'garbage' THEN 8
                    WHEN category = 'electricity' THEN 7
                    ELSE 8
                END
            WHEN 'medium' THEN
                CASE
                    WHEN category = 'traffic' THEN 6
                    WHEN category = 'garbage' THEN 5
                    WHEN category = 'electricity' THEN 5
                    ELSE 6
                END
            WHEN 'low' THEN
                CASE
                    WHEN category = 'traffic' THEN 3
                    WHEN category = 'garbage' THEN 2
                    WHEN category = 'electricity' THEN 3
                    ELSE 2
                END
            ELSE 0
        END AS impact_score,

        CASE severity
            WHEN 'high' THEN
                CASE
                    WHEN category = 'traffic' THEN 9
                    WHEN category = 'garbage' THEN 8
                    WHEN category = 'electricity' THEN 7
                    ELSE 8
                END
            WHEN 'medium' THEN
                CASE
                    WHEN category = 'traffic' THEN 5
                    WHEN category = 'garbage' THEN 4
                    WHEN category = 'electricity' THEN 4
                    ELSE 5
                END
            WHEN 'low' THEN
                CASE
                    WHEN category = 'traffic' THEN 2
                    WHEN category = 'garbage' THEN 2
                    WHEN category = 'electricity' THEN 1
                    ELSE 2
                END
            ELSE 0
        END AS urgency_score
    FROM demo_rows
)
INSERT INTO complaints (
    reference_code,
    category,
    city_id,
    district_id,
    locality,
    description,
    citizen_id,
    impact_score,
    urgency_score,
    severity,
    status
)
SELECT
    next_complaint_reference(),
    s.category::complaint_category,
    s.city_id,
    s.district_id,
    CASE s.category
        WHEN 'traffic' THEN 'DEMO-MAP-TRAFFIC'
        WHEN 'garbage' THEN 'DEMO-MAP-GARBAGE'
        WHEN 'electricity' THEN 'DEMO-MAP-ELECTRICITY'
        WHEN 'water' THEN 'DEMO-MAP-WATER'
    END,
    CASE s.category
        WHEN 'traffic'
            THEN 'Demonstration traffic and road infrastructure complaint.'
        WHEN 'garbage'
            THEN 'Demonstration garbage collection complaint.'
        WHEN 'electricity'
            THEN 'Demonstration electricity and street lighting complaint.'
        WHEN 'water'
            THEN 'Demonstration water supply complaint.'
    END,
    (
        SELECT u.id
        FROM users u
        WHERE u.role = 'citizen'
        ORDER BY u.id
        LIMIT 1
    ),
    s.impact_score,
    s.urgency_score,
    s.severity::severity_level,
    (CASE
        WHEN s.severity = 'high' THEN 'in_progress'
        WHEN s.severity = 'medium' THEN 'assigned'
        WHEN s.severity = 'low' THEN 'pending'
        ELSE 'pending'
    END)::complaint_status
FROM scored s
WHERE s.severity IS NOT NULL
AND NOT EXISTS (
    SELECT 1
    FROM complaints existing
    WHERE existing.district_id = s.district_id
      AND existing.locality = CASE s.category
          WHEN 'traffic' THEN 'DEMO-MAP-TRAFFIC'
          WHEN 'garbage' THEN 'DEMO-MAP-GARBAGE'
          WHEN 'electricity' THEN 'DEMO-MAP-ELECTRICITY'
          WHEN 'water' THEN 'DEMO-MAP-WATER'
      END
);

COMMIT;

-- ================================================================
-- 4. Verification queries
-- ================================================================

-- Total demo complaints:
SELECT COUNT(*) AS demo_complaints
FROM complaints
WHERE locality LIKE 'DEMO-MAP-%';

-- Severity distribution:
SELECT
    severity,
    COUNT(*) AS complaints
FROM complaints
WHERE locality LIKE 'DEMO-MAP-%'
GROUP BY severity
ORDER BY
    CASE severity
        WHEN 'high' THEN 1
        WHEN 'medium' THEN 2
        WHEN 'low' THEN 3
        ELSE 4
    END;

-- Category distribution:
SELECT
    category,
    COUNT(*) AS complaints
FROM complaints
WHERE locality LIKE 'DEMO-MAP-%'
GROUP BY category
ORDER BY category;

-- State-level distribution:
SELECT
    s.name AS state,
    COUNT(c.id) AS demo_complaints,
    COUNT(*) FILTER (WHERE c.severity = 'high') AS high,
    COUNT(*) FILTER (WHERE c.severity = 'medium') AS medium,
    COUNT(*) FILTER (WHERE c.severity = 'low') AS low
FROM states s
LEFT JOIN districts d
    ON d.state_id = s.id
LEFT JOIN complaints c
    ON c.district_id = d.id
   AND c.locality LIKE 'DEMO-MAP-%'
GROUP BY s.id, s.name
ORDER BY s.id;

-- ================================================================
-- END demo_data.sql
-- ================================================================
