-- ================================================================
-- URBAN INSIGHTS -- database/schema.sql
-- ================================================================
-- PostgreSQL schema backing the whole app. Mirrors the C++ OOP model
-- one-to-one where it makes sense (users/citizen_profiles/admin_profiles
-- mirrors the User -> Citizen/Admin/SuperAdmin hierarchy in
-- backend/User.h) so the eventual backend<->DB mapping is close to
-- mechanical, not a redesign.
--
-- Tested against a real PostgreSQL 16 instance while writing this -
-- every CREATE TABLE, the trigger, both views, and the seed data all
-- actually run (see docs/DATABASE_NOTES.md for the verification log).
--
-- Load with:  psql -U <user> -d urbaninsights -f database/schema.sql
-- ================================================================

BEGIN;

-- ================================================================
-- RESET (makes this file safe to re-run)
-- Drops everything this schema creates so it can be loaded again on a
-- database that already has an earlier copy. WARNING: this deletes all
-- existing data in these tables - run seed.sql / demo_data.sql after.
-- ================================================================
DROP VIEW     IF EXISTS city_rankings CASCADE;
DROP TABLE    IF EXISTS complaint_status_history CASCADE;
DROP TABLE    IF EXISTS complaint_attachments    CASCADE;
DROP TABLE    IF EXISTS complaints               CASCADE;
DROP TABLE    IF EXISTS admin_profiles           CASCADE;
DROP TABLE    IF EXISTS citizen_profiles         CASCADE;
DROP TABLE    IF EXISTS departments              CASCADE;
DROP TABLE    IF EXISTS users                    CASCADE;
DROP TABLE    IF EXISTS cities                   CASCADE;
DROP TABLE    IF EXISTS districts                CASCADE;
DROP TABLE    IF EXISTS states                   CASCADE;
DROP FUNCTION IF EXISTS log_complaint_status_change() CASCADE;
DROP FUNCTION IF EXISTS next_complaint_reference()    CASCADE;
DROP SEQUENCE IF EXISTS complaint_reference_seq;
DROP TYPE     IF EXISTS attachment_type;
DROP TYPE     IF EXISTS user_role;
DROP TYPE     IF EXISTS complaint_status;
DROP TYPE     IF EXISTS severity_level;
DROP TYPE     IF EXISTS complaint_category;

-- ================================================================
-- ENUM TYPES
-- Match backend/Complaint.h's Severity / ComplaintStatus enums and
-- backend/User.h's UserRole enum exactly, so a later C++ <-> Postgres
-- mapping layer is a straight lookup, not a translation.
-- ================================================================

CREATE TYPE complaint_category AS ENUM ('traffic', 'garbage', 'electricity', 'water');
CREATE TYPE severity_level     AS ENUM ('low', 'medium', 'high', 'unset');
CREATE TYPE complaint_status   AS ENUM ('pending', 'assigned', 'in_progress', 'resolved');
CREATE TYPE user_role          AS ENUM ('citizen', 'admin', 'super_admin');
CREATE TYPE attachment_type    AS ENUM ('photo', 'video');

-- ================================================================
-- GEOGRAPHY: states, districts, cities
-- Backs the WebGL India map (opengl/webgl-india-map.js) once it's
-- reading from the database aggregation APIs.
-- ================================================================

CREATE TABLE states (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(64)  NOT NULL UNIQUE,
    code        VARCHAR(8)                       -- e.g. 'MH', 'UP' - optional, for future use
);

CREATE TABLE districts (
    id          SERIAL PRIMARY KEY,
    state_id    INTEGER NOT NULL REFERENCES states(id) ON DELETE RESTRICT,
    name        VARCHAR(100) NOT NULL,
    code        VARCHAR(16),
    latitude    DOUBLE PRECISION,
    longitude   DOUBLE PRECISION,
    UNIQUE (state_id, name),
    UNIQUE (id, state_id)
);

CREATE INDEX idx_districts_state ON districts(state_id);

CREATE TABLE cities (
    id          SERIAL PRIMARY KEY,
    state_id    INTEGER NOT NULL REFERENCES states(id) ON DELETE RESTRICT,
    district_id INTEGER NOT NULL REFERENCES districts(id) ON DELETE RESTRICT,
    name        VARCHAR(80)  NOT NULL,
    latitude    DOUBLE PRECISION,
    longitude   DOUBLE PRECISION,
    UNIQUE (state_id, name),
    UNIQUE (id, state_id)
);

CREATE INDEX idx_cities_state ON cities(state_id);
ALTER TABLE cities ADD CONSTRAINT fk_city_district_state FOREIGN KEY (district_id, state_id) REFERENCES districts(id, state_id);

-- ================================================================
-- PEOPLE: users + role-specific profile tables
-- One row per person in `users`; the matching role-specific table
-- holds the fields that only make sense for that role - the relational
-- equivalent of Citizen/Admin/SuperAdmin inheriting from User in C++.
-- ================================================================

CREATE TABLE users (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL,
    email           VARCHAR(160) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    phone           VARCHAR(20),
    role            user_role NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE departments (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(120) NOT NULL UNIQUE,   -- "Road Department", "Water Department", ...
    category        complaint_category NOT NULL,
    staff_count     INTEGER NOT NULL DEFAULT 0 CHECK (staff_count >= 0)
);

-- Citizen : User  (see backend/User.h)
CREATE TABLE citizen_profiles (
    user_id             INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    trust_score         NUMERIC(5,2) NOT NULL DEFAULT 50.00,
    complaints_filed    INTEGER NOT NULL DEFAULT 0 CHECK (complaints_filed >= 0)
);

-- Admin : User, Auditable, Notifiable  (+ SuperAdmin : Admin)
CREATE TABLE admin_profiles (
    user_id             INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    department_id       INTEGER REFERENCES departments(id) ON DELETE SET NULL,
    complaints_resolved INTEGER NOT NULL DEFAULT 0 CHECK (complaints_resolved >= 0),
    is_super_admin      BOOLEAN NOT NULL DEFAULT FALSE,
    cities_managed      INTEGER CHECK (cities_managed IS NULL OR cities_managed >= 0)
);

-- A super admin profile with no department is intentional (SuperAdmin's
-- C++ constructor passes "All Departments"); admins should have one.
CREATE INDEX idx_admin_department ON admin_profiles(department_id);

-- ================================================================
-- COMPLAINTS - the centre of the schema
-- Mirrors backend/Complaint.h's fields closely: category, city,
-- locality, description, severity, status, impact/urgency scores.
-- ================================================================

CREATE TABLE complaints (
    id              SERIAL PRIMARY KEY,
    reference_code  VARCHAR(20) NOT NULL UNIQUE,      -- e.g. 'UI-2026-000123', see function below
    category        complaint_category NOT NULL,
    city_id         INTEGER NOT NULL REFERENCES cities(id) ON DELETE RESTRICT,
    district_id     INTEGER NOT NULL REFERENCES districts(id) ON DELETE RESTRICT,
    locality        VARCHAR(120) NOT NULL,
    description     TEXT NOT NULL CHECK (length(trim(description)) > 0),
    citizen_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    department_id   INTEGER REFERENCES departments(id) ON DELETE SET NULL,
    severity        severity_level NOT NULL DEFAULT 'unset',
    status          complaint_status NOT NULL DEFAULT 'pending',
    impact_score    SMALLINT NOT NULL DEFAULT 5 CHECK (impact_score BETWEEN 0 AND 10),
    urgency_score   SMALLINT NOT NULL DEFAULT 5 CHECK (urgency_score BETWEEN 0 AND 10),
    latitude        DOUBLE PRECISION,
    longitude       DOUBLE PRECISION,
    reported_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at     TIMESTAMPTZ,
    CHECK (resolved_at IS NULL OR resolved_at >= reported_at)
);

CREATE INDEX idx_complaints_city       ON complaints(city_id);
CREATE INDEX idx_complaints_district   ON complaints(district_id);
CREATE INDEX idx_complaints_severity   ON complaints(severity);
CREATE INDEX idx_complaints_reported   ON complaints(reported_at);
CREATE INDEX idx_complaints_status     ON complaints(status);
CREATE INDEX idx_complaints_category   ON complaints(category);
CREATE INDEX idx_complaints_citizen    ON complaints(citizen_id);
CREATE INDEX idx_complaints_department ON complaints(department_id);
-- Primary key already gives O(1)-ish hash/btree lookup by id - the
-- relational-database equivalent of dsa/HashTable.cpp's job in memory.

-- Attachments: Plan.pdf's "File attachment as photo or video"
CREATE TABLE complaint_attachments (
    id              SERIAL PRIMARY KEY,
    complaint_id    INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,
    file_type       attachment_type NOT NULL,
    uploaded_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_attachments_complaint ON complaint_attachments(complaint_id);

-- Status history: the relational mirror of dsa/Stack.cpp's status-change
-- stack - append-only, most-recent-last, queried most-recent-first.
CREATE TABLE complaint_status_history (
    id              SERIAL PRIMARY KEY,
    complaint_id    INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    status          complaint_status NOT NULL,
    changed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    note            VARCHAR(255)
);

CREATE INDEX idx_status_history_complaint ON complaint_status_history(complaint_id, changed_at DESC);

-- ================================================================
-- AUTOMATION
-- ================================================================

-- Every time a complaint's status changes, record it automatically -
-- the app never has to remember to write to complaint_status_history
-- itself, and it can't forget or write it inconsistently.
CREATE OR REPLACE FUNCTION log_complaint_status_change() RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' OR NEW.status IS DISTINCT FROM OLD.status THEN
        INSERT INTO complaint_status_history (complaint_id, status)
        VALUES (NEW.id, NEW.status);

        IF NEW.status = 'resolved' AND NEW.resolved_at IS NULL THEN
            NEW.resolved_at := now();
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_complaint_status_insert
    AFTER INSERT ON complaints
    FOR EACH ROW EXECUTE FUNCTION log_complaint_status_change();

CREATE TRIGGER trg_complaint_status_update
    BEFORE UPDATE ON complaints
    FOR EACH ROW EXECUTE FUNCTION log_complaint_status_change();

-- Human-readable complaint reference codes, e.g. 'UI-2026-000042'.
-- Plan.pdf calls this "Generate Complaint id" on the Report page.
CREATE SEQUENCE complaint_reference_seq START 1;

CREATE OR REPLACE FUNCTION next_complaint_reference() RETURNS VARCHAR AS $$
DECLARE
    seq_val INTEGER;
BEGIN
    seq_val := nextval('complaint_reference_seq');
    RETURN 'UI-' || to_char(now(), 'YYYY') || '-' || lpad(seq_val::TEXT, 6, '0');
END;
$$ LANGUAGE plpgsql;

-- ================================================================
-- VIEWS
-- ================================================================
CREATE OR REPLACE VIEW city_rankings AS
SELECT
    ci.id AS city_id,
    ci.name AS city_name,
    di.name AS district_name,
    st.name AS state_name,
    count(co.id) AS total_complaints,
    count(co.id) FILTER (WHERE co.status <> 'resolved') AS active_complaints,
    count(co.id) FILTER (WHERE co.severity = 'high') AS high_severity_count,
    count(co.id) FILTER (WHERE co.severity = 'medium') AS medium_severity_count,
    count(co.id) FILTER (WHERE co.severity = 'low') AS low_severity_count,
    count(co.id) FILTER (WHERE co.status = 'resolved') AS resolved_count,
    CASE WHEN count(co.id) = 0 THEN 0
         ELSE round(100.0 * count(co.id) FILTER (WHERE co.status = 'resolved') / count(co.id), 2)
    END AS resolution_rate
FROM cities ci
JOIN districts di ON di.id = ci.district_id
JOIN states st ON st.id = ci.state_id
LEFT JOIN complaints co ON co.city_id = ci.id
GROUP BY ci.id, ci.name, di.name, st.name;

COMMIT;
