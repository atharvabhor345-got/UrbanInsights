-- ================================================================
-- URBAN INSIGHTS -- database/seed.sql
-- ================================================================
-- Sample data so the schema is demonstrable immediately - run this
-- straight after schema.sql and every view/query below returns real
-- rows, not an empty table.
--
--   psql -U <user> -d urbaninsights -f database/schema.sql
--   psql -U <user> -d urbaninsights -f database/seed.sql
-- ================================================================

BEGIN;

INSERT INTO states (name, code) VALUES
    ('Andaman and Nicobar', 'AN'),
    ('Andhra Pradesh', 'AP'),
    ('Arunachal Pradesh', 'AR'),
    ('Assam', 'AS'),
    ('Bihar', 'BR'),
    ('Chandigarh', 'CH'),
    ('Chhattisgarh', 'CG'),
    ('Dadra and Nagar Haveli', 'DN'),
    ('Daman and Diu', 'DD'),
    ('Delhi', 'DL'),
    ('Goa', 'GA'),
    ('Gujarat', 'GJ'),
    ('Haryana', 'HR'),
    ('Himachal Pradesh', 'HP'),
    ('Jammu and Kashmir', 'JK'),
    ('Jharkhand', 'JH'),
    ('Karnataka', 'KA'),
    ('Kerala', 'KL'),
    ('Lakshadweep', 'LD'),
    ('Madhya Pradesh', 'MP'),
    ('Maharashtra', 'MH'),
    ('Manipur', 'MN'),
    ('Meghalaya', 'ML'),
    ('Mizoram', 'MZ'),
    ('Nagaland', 'NL'),
    ('Odisha', 'OD'),
    ('Puducherry', 'PY'),
    ('Punjab', 'PB'),
    ('Rajasthan', 'RJ'),
    ('Sikkim', 'SK'),
    ('Tamil Nadu', 'TN'),
    ('Tripura', 'TR'),
    ('Uttar Pradesh', 'UP'),
    ('Uttarakhand', 'UK'),
    ('West Bengal', 'WB')
ON CONFLICT (name) DO NOTHING;

-- Andaman and Nicobar districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andaman and Nicobar'), 'Andaman Islands', 12.602, 92.83) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andaman and Nicobar'), 'Nicobar Islands', 7.026, 93.807) ON CONFLICT (state_id, name) DO NOTHING;
-- Andhra Pradesh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Adilabad', 19.254, 78.967) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Anantapur', 14.475, 77.571) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Chittoor', 13.457, 79.004) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Cuddapah', 14.451, 78.774) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'East Godavari', 17.187, 81.999) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Guntur', 16.292, 80.081) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Hyderabad', 17.386, 78.464) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Karimnagar', 18.546, 79.235) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Khammam', 17.59, 80.679) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Krishna', 16.55, 80.793) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Kurnool', 15.528, 78.0) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Mahbubnagar', 16.493, 78.14) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Medak', 17.885, 78.211) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Nalgonda', 17.062, 79.281) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Nellore', 14.431, 79.722) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Nizamabad', 18.524, 78.139) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Prakasam', 15.611, 79.51) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Rangareddi', 17.286, 78.179) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Srikakulam', 18.571, 83.979) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Vishakhapatnam', 17.885, 82.682) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Vizianagaram', 18.465, 83.364) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'Warangal', 17.95, 79.792) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Andhra Pradesh'), 'West Godavari', 16.887, 81.392) ON CONFLICT (state_id, name) DO NOTHING;
-- Arunachal Pradesh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Changlang', 27.377, 96.357) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'East Kameng', 27.294, 93.032) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'East Siang', 28.118, 95.163) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Kurung Kumey', 28.038, 93.318) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Lohit', 27.988, 96.591) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Lower Dibang Valley', 28.364, 95.818) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Lower Subansiri', 27.671, 93.872) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Papum Pare', 27.275, 93.588) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Tawang', 27.656, 91.914) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Tirap', 26.955, 95.451) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Upper Dibang Valley', 28.955, 95.943) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Upper Siang', 28.828, 94.908) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'Upper Subansiri', 28.292, 93.932) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'West Kameng', 27.433, 92.514) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Arunachal Pradesh'), 'West Siang', 28.314, 94.508) ON CONFLICT (state_id, name) DO NOTHING;
-- Assam districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Barpeta', 26.439, 91.026) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Bongaigaon', 26.49, 90.646) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Cachar', 24.814, 92.857) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Darrang', 26.606, 92.026) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Dhemaji', 27.59, 94.78) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Dhuburi', 26.104, 90.03) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Dibrugarh', 27.371, 95.055) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Goalpara', 26.048, 90.609) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Golaghat', 26.479, 93.837) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Hailakandi', 24.497, 92.589) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Jorhat', 26.795, 94.274) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Kamrup', 26.136, 91.535) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Karbi Anglong', 26.159, 93.407) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Karimganj', 24.579, 92.381) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Kokrajhar', 26.583, 90.197) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Lakhimpur', 27.174, 94.135) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Marigaon', 26.286, 92.28) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Nagaon', 26.226, 92.842) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Nalbari', 26.53, 91.435) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'North Cachar Hills', 25.38, 93.034) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Sibsagar', 27.012, 94.819) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Sonitpur', 26.783, 92.927) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Assam'), 'Tinsukia', 27.584, 95.625) ON CONFLICT (state_id, name) DO NOTHING;
-- Bihar districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Araria', 26.201, 87.346) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Aurangabad', 24.794, 84.404) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Banka', 24.852, 86.834) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Begusarai', 25.496, 86.124) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Bhabua', 24.993, 83.599) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Bhagalpur', 25.269, 87.077) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Bhojpur', 25.47, 84.536) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Buxar', 25.493, 84.094) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Darbhanga', 26.115, 86.017) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Gaya', 24.699, 84.928) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Gopalganj', 26.445, 84.368) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Jamui', 24.785, 86.289) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Jehanabad', 25.159, 84.881) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Katihar', 25.545, 87.639) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Khagaria', 25.512, 86.596) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Kishanganj', 26.295, 87.929) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Lakhisarai', 25.16, 86.128) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Madhepura', 25.826, 86.889) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Madhubani', 26.406, 86.212) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Munger', 25.211, 86.527) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Muzaffarpur', 26.153, 85.322) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Nalanda', 25.221, 85.448) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Nawada', 24.811, 85.587) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Pashchim Champaran', 27.079, 84.337) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Patna', 25.457, 85.214) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Purba Champaran', 26.621, 84.916) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Purnia', 25.816, 87.401) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Rohtas', 24.981, 84.02) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Saharsa', 25.817, 86.583) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Samastipur', 25.778, 85.896) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Saran', 25.906, 84.817) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Sheikhpura', 25.132, 85.815) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Sheohar', 26.485, 85.323) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Sitamarhi', 26.597, 85.557) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Siwan', 26.163, 84.381) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Supaul', 26.247, 86.792) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Bihar'), 'Vaishali', 25.763, 85.362) ON CONFLICT (state_id, name) DO NOTHING;
-- Chandigarh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chandigarh'), 'Chandigarh', 30.734, 76.768) ON CONFLICT (state_id, name) DO NOTHING;
-- Chhattisgarh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Bastar', 19.437, 81.573) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Bilaspur', 22.35, 81.954) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Dantewada', 18.655, 81.052) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Dhamtari', 20.553, 81.803) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Durg', 21.189, 81.347) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Janjgir-Champa', 21.924, 82.731) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Jashpur', 22.799, 83.859) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Kanker', 20.134, 81.121) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Kawardha', 22.091, 81.216) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Korba', 22.532, 82.604) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Koriya', 23.469, 82.229) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Mahasamund', 21.203, 82.604) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Raigarh', 22.083, 83.299) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Raipur', 21.069, 82.167) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Raj Nandgaon', 21.038, 80.812) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Chhattisgarh'), 'Surguja', 23.358, 83.212) ON CONFLICT (state_id, name) DO NOTHING;
-- Dadra and Nagar Haveli districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Dadra and Nagar Haveli'), 'Dadra and Nagar Haveli', 20.195, 73.081) ON CONFLICT (state_id, name) DO NOTHING;
-- Daman and Diu districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Daman and Diu'), 'Daman', 20.414, 72.842) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Daman and Diu'), 'Junagadh', 20.84, 70.787) ON CONFLICT (state_id, name) DO NOTHING;
-- Delhi districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Delhi'), 'Delhi', 28.646, 77.109) ON CONFLICT (state_id, name) DO NOTHING;
-- Goa districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Goa'), 'North Goa', 15.551, 73.984) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Goa'), 'South Goa', 15.195, 74.121) ON CONFLICT (state_id, name) DO NOTHING;
-- Gujarat districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Ahmadabad', 22.727, 72.203) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Amreli', 21.421, 71.264) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Anand', 22.452, 72.795) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Banas Kantha', 24.281, 72.039) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Bharuch', 21.788, 72.923) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Bhavnagar', 21.671, 71.85) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Dahod', 22.91, 74.02) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Gandhinagar', 23.208, 72.7) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Jamnagar', 22.248, 69.927) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Junagadh', 21.214, 70.568) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Kachchh', 23.623, 70.005) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Kheda', 22.876, 73.024) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Mahesana', 23.58, 72.496) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Narmada', 21.711, 73.657) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Navsari', 20.813, 73.104) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Panch Mahals', 22.853, 73.609) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Patan', 23.768, 71.8) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Porbandar', 21.638, 69.802) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Rajkot', 22.255, 70.792) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Sabar Kantha', 23.658, 73.167) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Surat', 21.235, 73.311) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Surendranagar', 22.795, 71.552) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'The Dangs', 20.799, 73.706) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Vadodara', 22.226, 73.541) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Gujarat'), 'Valsad', 20.418, 73.119) ON CONFLICT (state_id, name) DO NOTHING;
-- Haryana districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Ambala', 30.359, 76.966) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Bhiwani', 28.724, 75.958) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Faridabad', 28.164, 77.323) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Fatehabad', 29.579, 75.569) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Gurgaon', 28.169, 76.983) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Hisar', 29.22, 75.805) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Jhajjar', 28.592, 76.616) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Jind', 29.442, 76.294) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Kaithal', 29.816, 76.408) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Karnal', 29.697, 76.881) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Kurukshetra', 30.05, 76.83) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Mahendragarh', 28.178, 76.136) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Panchkula', 30.71, 76.959) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Panipat', 29.337, 76.915) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Rewari', 28.21, 76.555) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Rohtak', 28.914, 76.511) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Sirsa', 29.616, 74.892) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Sonepat', 29.065, 76.864) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Haryana'), 'Yamuna Nagar', 30.257, 77.33) ON CONFLICT (state_id, name) DO NOTHING;
-- Himachal Pradesh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Bilaspur', 31.375, 76.658) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Chamba', 32.678, 76.338) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Hamirpur', 31.671, 76.511) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Kangra', 32.11, 76.302) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Kinnaur', 31.601, 78.397) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Kullu', 31.908, 77.384) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Lahul and Spiti', 32.483, 77.599) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Mandi', 31.641, 76.978) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Shimla', 31.201, 77.618) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Sirmaur', 30.672, 77.417) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Solan', 31.047, 76.896) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Himachal Pradesh'), 'Una', 31.583, 76.196) ON CONFLICT (state_id, name) DO NOTHING;
-- Jammu and Kashmir districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Anantnag (Kashmir South)', 33.804, 75.332) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Bagdam', 33.945, 74.788) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Baramula (Kashmir North)', 34.357, 74.668) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Doda', 33.439, 75.934) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Jammu', 32.736, 74.895) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Kargil', 33.813, 76.619) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Kathua', 32.548, 75.59) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Kupwara (Muzaffarabad)', 34.541, 74.222) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Ladakh (Leh)', 33.904, 77.959) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Pulwama', 33.84, 75.022) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Punch', 33.746, 74.343) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Rajauri', 33.261, 74.456) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Srinagar', 34.245, 75.103) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jammu and Kashmir'), 'Udhampur', 33.062, 75.189) ON CONFLICT (state_id, name) DO NOTHING;
-- Jharkhand districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Bokaro', 23.692, 85.988) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Chatra', 24.173, 84.88) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Deoghar', 24.327, 86.735) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Dhanbad', 23.83, 86.471) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Dumka', 24.318, 87.261) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Garhwa', 24.103, 83.69) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Giridih', 24.297, 86.104) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Godda', 24.859, 87.306) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Gumla', 23.101, 84.528) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Hazaribag', 23.98, 85.45) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Jamtara', 23.975, 86.912) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Koderma', 24.518, 85.702) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Latehar', 23.717, 84.436) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Lohardaga', 23.475, 84.663) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Pakur', 24.562, 87.658) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Palamu', 24.2, 84.159) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Pashchim Singhbhum', 22.416, 85.513) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Purba Singhbhum', 22.579, 86.447) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Ranchi', 23.211, 85.33) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Sahibganj', 25.007, 87.674) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Saraikela Kharsawan', 22.842, 85.946) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Jharkhand'), 'Simdega', 22.578, 84.56) ON CONFLICT (state_id, name) DO NOTHING;
-- Karnataka districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bagalkot', 16.218, 75.627) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bangalore Rural', 12.887, 77.422) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bangalore Urban', 12.942, 77.587) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Belgaum', 16.118, 74.828) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bellary', 15.105, 76.531) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bidar', 17.95, 77.224) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Bijapur', 16.791, 75.953) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Chamrajnagar', 11.949, 77.09) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Chikmagalur', 13.449, 75.69) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Chitradurga', 14.162, 76.512) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Dakshin Kannad', 12.833, 75.267) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Davanagere', 14.351, 75.931) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Dharwad', 15.387, 75.156) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Gadag', 15.428, 75.667) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Gulbarga', 17.052, 76.881) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Hassan', 12.99, 76.105) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Haveri', 14.734, 75.418) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Kodagu', 12.319, 75.799) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Kolar', 13.356, 78.012) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Koppal', 15.558, 76.22) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Mandya', 12.604, 76.79) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Mysore', 12.202, 76.436) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Raichur', 16.086, 76.89) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Shimoga', 14.052, 75.176) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Tumkur', 13.419, 76.897) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Udupi', 13.465, 74.883) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Karnataka'), 'Uttar Kannand', 14.788, 74.624) ON CONFLICT (state_id, name) DO NOTHING;
-- Kerala districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Alappuzha', 9.409, 76.447) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Ernakulam', 10.059, 76.479) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Idukki', 9.874, 77.013) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Kannur', 11.992, 75.536) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Kasaragod', 12.461, 75.153) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Kollam', 8.954, 76.868) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Kottayam', 9.628, 76.649) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Kozhikode', 11.481, 75.831) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Malappuram', 11.129, 76.152) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Palakkad', 10.787, 76.548) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Pattanamtitta', 9.276, 76.913) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Thiruvananthapuram', 8.606, 77.005) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Thrissur', 10.466, 76.312) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Kerala'), 'Wayanad', 11.705, 76.092) ON CONFLICT (state_id, name) DO NOTHING;
-- Lakshadweep districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Lakshadweep'), 'Kavaratti', 8.28, 73.049) ON CONFLICT (state_id, name) DO NOTHING;
-- Madhya Pradesh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Anuppur', 23.148, 81.872) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Ashoknagar', 24.614, 77.869) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Balaghat', 21.881, 80.354) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Barwani', 21.79, 75.023) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Betul', 21.88, 77.867) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Bhind', 26.426, 78.715) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Bhopal', 23.482, 77.392) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Burhanpur', 21.374, 76.369) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Chhatarpur', 24.802, 79.658) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Chhindwara', 22.124, 78.85) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Damoh', 23.816, 79.52) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Datia', 25.845, 78.607) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Dewas', 22.748, 76.454) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Dhar', 22.5, 75.105) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Dindori', 22.835, 81.046) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'East Nimar', 21.939, 76.57) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Guna', 24.559, 77.196) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Gwalior', 26.045, 78.139) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Harda', 22.237, 77.118) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Hoshangabad', 22.591, 77.984) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Indore', 22.716, 75.781) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Jabalpur', 23.174, 79.945) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Jhabua', 22.609, 74.523) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Katni', 23.704, 80.335) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Mandla', 22.666, 80.447) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Mandsaur', 24.215, 75.404) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Morena', 26.419, 77.861) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Narsinghpur', 22.937, 79.081) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Neemuch', 24.609, 75.143) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Panna', 24.425, 80.185) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Raisen', 23.221, 78.113) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Rajgarh', 23.865, 76.731) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Ratlam', 23.504, 75.09) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Rewa', 24.758, 81.581) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Sagar', 23.852, 78.753) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Satna', 24.536, 80.825) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Sehore', 22.995, 77.125) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Seoni', 22.317, 79.684) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Shahdol', 23.463, 81.433) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Shajapur', 23.584, 76.343) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Sheopur', 25.758, 77.005) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Shivpuri', 25.368, 77.806) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Sidhi', 24.22, 82.148) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Tikamgarh', 24.993, 78.94) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Ujjain', 23.335, 75.667) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Umaria', 23.607, 80.914) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'Vidisha', 23.897, 77.808) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Madhya Pradesh'), 'West Nimar', 21.923, 75.774) ON CONFLICT (state_id, name) DO NOTHING;
-- Maharashtra districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Ahmednagar', 19.233, 74.645) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Akola', 20.75, 77.045) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Amravati', 21.189, 77.569) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Aurangabad', 20.023, 75.276) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Bhandara', 21.129, 79.745) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Bid', 18.925, 75.802) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Buldana', 20.511, 76.404) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Chandrapur', 20.117, 79.438) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Dhule', 21.112, 74.605) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Garhchiroli', 19.782, 80.234) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Gondiya', 21.121, 80.155) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Greater Bombay', 19.145, 72.923) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Hingoli', 19.615, 77.117) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Jalgaon', 20.937, 75.491) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Jalna', 19.82, 75.983) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Kolhapur', 16.467, 74.167) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Latur', 18.373, 76.76) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Nagpur', 21.177, 79.082) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Nanded', 19.115, 77.621) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Nandurbar', 21.547, 74.22) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Nashik', 20.26, 74.078) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Osmanabad', 18.188, 76.039) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Parbhani', 19.286, 76.682) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Pune', 18.571, 74.077) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Raigarh', 18.51, 73.23) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Ratnagiri', 17.273, 73.461) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Sangli', 17.111, 74.775) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Satara', 17.668, 74.181) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Sindhudurg', 16.132, 73.743) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Solapur', 17.789, 75.485) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Thane', 19.618, 73.166) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Wardha', 20.796, 78.583) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Washim', 20.238, 77.217) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Yavatmal', 20.084, 78.158) ON CONFLICT (state_id, name) DO NOTHING;
-- Manipur districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Bishnupur', 24.54, 93.803) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Chandel', 24.241, 94.096) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Churachandpur', 24.304, 93.421) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'East Imphal', 24.837, 94.018) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Senapati', 25.202, 94.041) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Tamenglong', 24.951, 93.528) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Thoubal', 24.536, 93.974) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'Ukhrul', 25.026, 94.436) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Manipur'), 'West Imphal', 24.808, 93.878) ON CONFLICT (state_id, name) DO NOTHING;
-- Meghalaya districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'East Garo Hills', 25.735, 90.631) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'East Khasi Hills', 25.386, 91.801) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'Jaintia Hills', 25.371, 92.381) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'Ri-Bhoi', 25.875, 91.888) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'South Garo Hills', 25.302, 90.596) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'West Garo Hills', 25.582, 90.146) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Meghalaya'), 'West Khasi Hills', 25.527, 91.258) ON CONFLICT (state_id, name) DO NOTHING;
-- Mizoram districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Aizawl', 23.836, 92.888) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Champhai', 23.54, 93.237) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Kolasib', 24.201, 92.728) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Lawngtlai', 22.386, 92.716) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Lunglei', 22.974, 92.724) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Mamit', 23.755, 92.468) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Saiha', 22.379, 93.015) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Mizoram'), 'Serchhip', 23.29, 92.947) ON CONFLICT (state_id, name) DO NOTHING;
-- Nagaland districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Dimapur', 25.778, 93.787) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Kohima', 25.616, 93.832) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Mokokchung', 26.477, 94.532) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Mon', 26.685, 95.022) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Phek', 25.652, 94.538) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Tuensang', 26.137, 94.857) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Wokha', 26.19, 94.193) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Nagaland'), 'Zunheboto', 26.008, 94.487) ON CONFLICT (state_id, name) DO NOTHING;
-- Odisha districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Angul', 20.981, 84.903) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Baleshwar', 21.489, 86.904) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Baragarh', 21.217, 83.346) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Bhadrak', 20.979, 86.616) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Bolangir', 20.586, 83.167) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Boudh', 20.641, 84.171) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Cuttack', 20.444, 85.698) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Deogarh', 21.462, 84.797) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Dhenkanal', 20.82, 85.52) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Gajapati', 19.165, 84.153) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Ganjam', 19.622, 84.659) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Jagatsinghpur', 20.218, 86.33) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Jajpur', 20.85, 86.147) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Jharsuguda', 21.803, 83.948) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Kalahandi', 19.862, 83.102) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Kandhamal', 20.123, 84.04) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Kendrapara', 20.533, 86.581) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Keonjhar', 21.532, 85.699) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Khordha', 20.082, 85.505) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Koraput', 18.811, 82.707) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Malkangiri', 18.25, 81.948) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Mayurbhanj', 21.891, 86.406) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Nabarangpur', 19.583, 82.33) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Nayagarh', 20.206, 84.993) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Nuapada', 20.461, 82.571) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Puri', 19.865, 85.697) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Rayagada', 19.355, 83.506) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Sambalpur', 21.448, 84.274) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Sonepur', 20.927, 83.818) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Odisha'), 'Sundargarh', 22.077, 84.504) ON CONFLICT (state_id, name) DO NOTHING;
-- Puducherry districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Puducherry'), 'Karaikal', 10.913, 79.796) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Puducherry'), 'Mahe', 12.074, 75.286) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Puducherry'), 'Puducherry', 11.909, 79.748) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Puducherry'), 'Yanam', 16.719, 82.239) ON CONFLICT (state_id, name) DO NOTHING;
-- Punjab districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Amritsar', 31.53, 74.866) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Bathinda', 30.184, 75.03) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Faridkot', 30.611, 74.768) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Fatehgarh Sahib', 30.636, 76.35) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Firozpur', 30.562, 74.394) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Gurdaspur', 32.023, 75.373) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Hoshiarpur', 31.627, 75.845) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Jalandhar', 31.214, 75.554) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Kapurthala', 31.372, 75.307) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Ludhiana', 30.811, 75.824) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Mansa', 29.911, 75.428) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Moga', 30.767, 75.158) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Muktsar', 30.295, 74.531) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Nawan Shehar', 31.112, 76.143) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Patiala', 30.309, 76.398) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Rupnagar', 30.963, 76.539) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Punjab'), 'Sangrur', 30.269, 75.751) ON CONFLICT (state_id, name) DO NOTHING;
-- Rajasthan districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Ajmer', 26.241, 74.785) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Alwar', 27.597, 76.598) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Banswara', 23.509, 74.396) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Baran', 25.0, 76.752) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Barmer', 25.73, 71.479) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Bharatpur', 27.251, 77.271) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Bhilwara', 25.483, 74.727) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Bikaner', 28.191, 73.077) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Bundi', 25.474, 75.774) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Chittaurgarh', 24.577, 74.641) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Churu', 28.293, 74.562) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Dausa', 26.866, 76.52) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Dhaulpur', 26.686, 77.696) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Dungarpur', 23.734, 73.858) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Ganganagar', 29.408, 73.598) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Hanumangarh', 29.24, 74.597) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jaipur', 26.984, 75.718) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jaisalmer', 27.07, 70.901) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jalor', 25.095, 72.217) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jhalawar', 24.333, 76.194) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jhunjhunun', 28.096, 75.545) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Jodhpur', 26.749, 72.788) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Karauli', 26.522, 76.94) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Kota', 25.129, 76.125) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Nagaur', 27.066, 74.184) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Pali', 25.709, 73.521) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Rajsamand', 25.197, 73.875) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Sawai Madhopur', 26.193, 76.444) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Sikar', 27.64, 75.281) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Sirohi', 24.758, 72.779) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Tonk', 26.15, 75.667) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Rajasthan'), 'Udaipur', 24.392, 73.756) ON CONFLICT (state_id, name) DO NOTHING;
-- Sikkim districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Sikkim'), 'East', 27.293, 88.671) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Sikkim'), 'North Sikkim', 27.744, 88.526) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Sikkim'), 'South Sikkim', 27.287, 88.38) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Sikkim'), 'West Sikkim', 27.347, 88.174) ON CONFLICT (state_id, name) DO NOTHING;
-- Tamil Nadu districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Ariyalur', 11.147, 79.228) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Chennai', 13.048, 80.235) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Coimbatore', 10.837, 77.072) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Cuddalore', 11.525, 79.445) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Dharmapuri', 12.296, 78.097) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Dindigul', 10.379, 77.805) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Erode', 11.319, 77.447) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Kancheepuram', 12.681, 79.936) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Kanniyakumari', 8.306, 77.347) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Karur', 10.832, 78.118) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Madurai', 9.91, 77.99) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Nagapattinam', 11.141, 79.704) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Namakkal', 11.305, 78.122) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Nilgiris', 11.448, 76.633) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Perambalur', 11.26, 78.878) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Pudukkottai', 10.342, 78.867) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Ramanathapuram', 9.447, 78.666) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Salem', 11.663, 78.209) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Sivaganga', 9.907, 78.576) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Thanjavur', 10.655, 79.224) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Theni', 9.881, 77.424) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Thiruvallur', 13.23, 79.925) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Thiruvarur', 10.67, 79.534) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Thoothukudi', 8.878, 77.988) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Tiruchchirappalli', 10.877, 78.555) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Tirunelveli Kattabo', 8.79, 77.523) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Tiruvannamalai', 12.419, 79.154) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Vellore', 12.801, 78.998) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Villupuram', 11.96, 79.284) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tamil Nadu'), 'Virudhunagar', 9.481, 77.894) ON CONFLICT (state_id, name) DO NOTHING;
-- Tripura districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tripura'), 'Dhalai', 23.85, 91.928) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tripura'), 'North Tripura', 24.134, 92.154) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tripura'), 'South Tripura', 23.371, 91.612) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Tripura'), 'West Tripura', 23.804, 91.465) ON CONFLICT (state_id, name) DO NOTHING;
-- Uttar Pradesh districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Agra', 27.008, 78.063) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Aligarh', 27.926, 78.077) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Allahabad', 25.3, 81.965) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Ambedkar Nagar', 26.424, 82.66) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Auraiya', 26.65, 79.449) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Azamgarh', 26.055, 83.041) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Badaun', 28.121, 78.935) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Baghpat', 29.06, 77.303) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Bahraich', 27.741, 81.412) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Ballia', 25.877, 84.097) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Balrampur', 27.487, 82.369) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Banda', 25.471, 80.553) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Bara Banki', 26.917, 81.372) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Bareilly', 28.456, 79.411) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Basti', 26.79, 82.606) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Bijnor', 29.393, 78.387) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Bulandshahr', 28.367, 77.999) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Chandauli', 25.139, 83.253) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Chitrakoot', 25.209, 81.081) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Deoria', 26.425, 83.827) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Etah', 27.635, 78.762) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Etawah', 26.79, 79.081) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Faizabad', 26.635, 82.071) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Farrukhabad', 27.436, 79.451) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Fatehpur', 25.878, 80.798) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Firozabad', 27.206, 78.457) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Gautam Buddha Nagar', 28.396, 77.537) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Ghaziabad', 28.745, 77.696) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Ghazipur', 25.625, 83.548) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Gonda', 27.088, 82.013) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Gorakhpur', 26.626, 83.36) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Hamirpur', 25.737, 79.871) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Hardoi', 27.334, 80.152) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Hathras', 27.576, 78.144) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Jalaun', 26.096, 79.38) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Jaunpur', 25.749, 82.567) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Jhansi', 25.511, 78.946) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Jyotiba Phule Nagar', 28.843, 78.349) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Kannauj', 27.018, 79.678) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Kanpur Dehat', 26.428, 79.954) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Kanpur', 26.38, 80.321) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Kaushambi', 25.492, 81.459) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Kushinagar', 26.865, 83.925) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Lakhimpur Kheri', 28.128, 80.657) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Lalitpur', 24.658, 78.555) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Lucknow', 26.847, 80.897) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Maharajganj', 27.188, 83.501) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Mahoba', 25.352, 79.693) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Mainpuri', 27.186, 79.044) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Mathura', 27.601, 77.621) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Mau', 26.035, 83.503) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Meerut', 29.042, 77.784) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Mirzapur', 24.988, 82.611) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Moradabad', 28.761, 78.702) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Muzaffarnagar', 29.444, 77.581) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Pilibhit', 28.548, 79.95) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Pratapgarh', 25.876, 81.823) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Rae Bareli', 26.233, 81.222) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Rampur', 28.802, 79.094) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Saharanpur', 29.955, 77.535) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Sant Kabir Nagar', 26.748, 83.03) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Sant Ravi Das Nagar', 25.351, 82.456) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Shahjahanpur', 27.982, 79.834) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Shravasti', 27.678, 81.816) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Siddharth Nagar', 27.233, 82.86) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Sitapur', 27.523, 80.847) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Sonbhadra', 24.404, 83.046) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Sultanpur', 26.279, 82.011) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Unnao', 26.614, 80.55) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttar Pradesh'), 'Varanasi', 25.391, 82.909) ON CONFLICT (state_id, name) DO NOTHING;
-- Uttarakhand districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Almora', 29.695, 79.489) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Bageshwar', 29.997, 79.846) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Chamoli', 30.499, 79.558) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Champawat', 29.303, 80.062) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Dehra Dun', 30.469, 77.96) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Haridwar', 29.877, 77.989) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Naini Tal', 29.317, 79.455) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Pauri Garhwal', 29.899, 78.757) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Pithoragarh', 30.112, 80.334) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Rudra Prayag', 30.595, 79.098) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Tehri Garhwal', 30.443, 78.57) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Udham Singh Nagar', 29.043, 79.499) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Uttarakhand'), 'Uttarkashi', 30.978, 78.589) ON CONFLICT (state_id, name) DO NOTHING;
-- West Bengal districts
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Bankura', 23.138, 87.13) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Barddhaman', 23.425, 87.763) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Birbhum', 23.952, 87.662) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Dakshin Dinajpur', 25.362, 88.593) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Darjiling', 26.914, 88.392) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'East Midnapore', 22.027, 87.77) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Haora', 22.524, 88.065) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Hugli', 22.881, 88.076) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Jalpaiguri', 26.663, 89.081) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Kochbihar', 26.292, 89.35) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Kolkata', 22.552, 88.352) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Maldah', 25.136, 88.088) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Murshidabad', 24.161, 88.227) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Nadia', 23.476, 88.516) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'North 24 Parganas', 22.791, 88.697) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Puruliya', 23.275, 86.413) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'South 24 Parganas', 22.225, 88.419) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'Uttar Dinajpur', 25.874, 88.157) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'West Bengal'), 'West Midnapore', 22.41, 87.262) ON CONFLICT (state_id, name) DO NOTHING;

INSERT INTO districts (state_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name = 'Maharashtra'), 'Mumbai', 19.076, 72.8777) ON CONFLICT (state_id, name) DO NOTHING;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Maharashtra'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Maharashtra' AND d.name='Pune'), 'Pune', 18.5204, 73.8567) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Maharashtra'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Maharashtra' AND d.name='Mumbai'), 'Mumbai', 19.076, 72.8777) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Maharashtra'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Maharashtra' AND d.name='Nashik'), 'Nashik', 20.0059, 73.791) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Delhi'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Delhi' AND d.name='Delhi'), 'New Delhi', 28.6139, 77.209) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Karnataka'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Karnataka' AND d.name='Bangalore Urban'), 'Bengaluru', 12.9716, 77.5946) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;
INSERT INTO cities (state_id, district_id, name, latitude, longitude) VALUES ((SELECT id FROM states WHERE name='Rajasthan'), (SELECT d.id FROM districts d JOIN states s ON s.id=d.state_id WHERE s.name='Rajasthan' AND d.name='Jaipur'), 'Jaipur', 26.9124, 75.7873) ON CONFLICT (state_id, name) DO UPDATE SET district_id=EXCLUDED.district_id;

INSERT INTO departments (name, category, staff_count) VALUES
    ('Road Department',        'traffic',     12),
    ('Sanitation Department',  'garbage',     18),
    ('Electricity Board',      'electricity',  9),
    ('Water Supply Department','water',       14);

-- Citizens
INSERT INTO users (name, email, password_hash, phone, role) VALUES
    ('Aarav Sharma', 'aarav@example.com',  'pbkdf2_sha256$urbaninsights$3a7a12bcda80b4086f7fd60fc1f44eafb08054b520da2988c6f7f1fbc5007316', '9999900000', 'citizen'),
    ('Meera Iyer',   'meera@example.com',  'pbkdf2_sha256$urbaninsights$3a7a12bcda80b4086f7fd60fc1f44eafb08054b520da2988c6f7f1fbc5007316', '9999900001', 'citizen'),
    ('Rohit Verma',  'rohit@example.com',  'pbkdf2_sha256$urbaninsights$3a7a12bcda80b4086f7fd60fc1f44eafb08054b520da2988c6f7f1fbc5007316', '9999900002', 'citizen');

INSERT INTO citizen_profiles (user_id, trust_score, complaints_filed)
SELECT id, 62.5, 3 FROM users WHERE email = 'aarav@example.com';
INSERT INTO citizen_profiles (user_id, trust_score, complaints_filed)
SELECT id, 55.0, 1 FROM users WHERE email = 'meera@example.com';
INSERT INTO citizen_profiles (user_id, trust_score, complaints_filed)
SELECT id, 50.0, 1 FROM users WHERE email = 'rohit@example.com';

-- Admins
INSERT INTO users (name, email, password_hash, phone, role) VALUES
    ('Priya Nair',  'priya@uinsights.gov.in', 'pbkdf2_sha256$urbaninsights$3a7a12bcda80b4086f7fd60fc1f44eafb08054b520da2988c6f7f1fbc5007316', '9888800000', 'admin'),
    ('Karan Mehta', 'karan@uinsights.gov.in', 'pbkdf2_sha256$urbaninsights$3a7a12bcda80b4086f7fd60fc1f44eafb08054b520da2988c6f7f1fbc5007316', '9777700000', 'admin');

INSERT INTO admin_profiles (user_id, department_id, complaints_resolved, is_super_admin, cities_managed)
SELECT u.id, d.id, 1, FALSE, NULL
FROM users u, departments d
WHERE u.email = 'priya@uinsights.gov.in' AND d.name = 'Road Department';

INSERT INTO admin_profiles (user_id, department_id, complaints_resolved, is_super_admin, cities_managed)
SELECT u.id, NULL, 0, TRUE, 5
FROM users u
WHERE u.email = 'karan@uinsights.gov.in';

-- Complaints (reference_code generated the same way the Report page will)
INSERT INTO complaints (reference_code, category, city_id, district_id, locality, description, citizen_id, impact_score, urgency_score, severity, status)
SELECT next_complaint_reference(), 'traffic', ci.id, ci.district_id, 'Kothrud', 'Pothole outside college gate',
       u.id, 8, 7, 'high', 'in_progress'
FROM cities ci, users u WHERE ci.name = 'Pune' AND u.email = 'aarav@example.com';

INSERT INTO complaints (reference_code, category, city_id, district_id, locality, description, citizen_id, impact_score, urgency_score, severity, status)
SELECT next_complaint_reference(), 'garbage', ci.id, ci.district_id, 'Wakad', 'Garbage not collected for 5 days',
       u.id, 6, 5, 'medium', 'assigned'
FROM cities ci, users u WHERE ci.name = 'Pune' AND u.email = 'meera@example.com';

INSERT INTO complaints (reference_code, category, city_id, district_id, locality, description, citizen_id, impact_score, urgency_score, severity, status)
SELECT next_complaint_reference(), 'water', ci.id, ci.district_id, 'Andheri', 'No water supply since morning',
       u.id, 7, 8, 'high', 'pending'
FROM cities ci, users u WHERE ci.name = 'Mumbai' AND u.email = 'rohit@example.com';

INSERT INTO complaints (reference_code, category, city_id, district_id, locality, description, citizen_id, impact_score, urgency_score, severity, status, reported_at, resolved_at)
SELECT next_complaint_reference(), 'electricity', ci.id, ci.district_id, 'College Road', 'Street light not working',
       u.id, 3, 2, 'low', 'resolved', now() - interval '1 day', now() - interval '2 hours'
FROM cities ci, users u WHERE ci.name = 'Nashik' AND u.email = 'aarav@example.com';

-- Assign the first complaint to the Road Department (mirrors
-- Department::operator+= in backend/Department.cpp)
UPDATE complaints SET department_id = (SELECT id FROM departments WHERE name = 'Road Department')
WHERE reference_code = (SELECT reference_code FROM complaints ORDER BY id LIMIT 1);



-- ================================================================
-- DEMO DATA FOR EVERY DISTRICT
-- ================================================================
-- Create one demo city for every district that does not already
-- have a city. Existing cities such as Pune, Mumbai, Nashik,
-- Bengaluru, Jaipur and New Delhi are preserved.
--
-- Then create one demo complaint for every district. The demo
-- complaint is skipped if that district already has a complaint
-- with locality = 'Demo Area', so this section is safe to run again.
-- ================================================================

INSERT INTO cities (state_id, district_id, name, latitude, longitude)
SELECT
    d.state_id,
    d.id,
    LEFT(d.name || ' Demo City', 100),
    d.latitude,
    d.longitude
FROM districts d
WHERE NOT EXISTS (
    SELECT 1
    FROM cities c
    WHERE c.district_id = d.id
)
AND NOT EXISTS (
    SELECT 1
    FROM cities c
    WHERE c.state_id = d.state_id
      AND c.name = LEFT(d.name || ' Demo City', 100)
);

-- One complaint per district.
-- Categories rotate so the dashboard demonstrates all four
-- complaint departments instead of showing only one category.
WITH district_demo AS (
    SELECT
        d.id AS district_id,
        d.state_id,
        d.name AS district_name,
        c.id AS city_id,
        ROW_NUMBER() OVER (ORDER BY d.id) AS n
    FROM districts d
    JOIN cities c
      ON c.district_id = d.id
    WHERE NOT EXISTS (
        SELECT 1
        FROM complaints existing
        WHERE existing.district_id = d.id
          AND existing.locality = 'Demo Area'
    )
),
classified AS (
    SELECT
        district_id,
        district_name,
        city_id,
        n,
        CASE ((n - 1) % 4)
            WHEN 0 THEN 'traffic'
            WHEN 1 THEN 'garbage'
            WHEN 2 THEN 'electricity'
            ELSE 'water'
        END::complaint_category AS category,
        CASE ((n - 1) % 4)
            WHEN 0 THEN 8
            WHEN 1 THEN 6
            WHEN 2 THEN 4
            ELSE 7
        END AS impact_score,
        CASE ((n - 1) % 4)
            WHEN 0 THEN 7
            WHEN 1 THEN 5
            WHEN 2 THEN 3
            ELSE 8
        END AS urgency_score
    FROM district_demo
)
INSERT INTO complaints (
    reference_code,
    category,
    city_id,
    district_id,
    locality,
    description,
    citizen_id,
    department_id,
    impact_score,
    urgency_score,
    severity,
    status
)
SELECT
    next_complaint_reference(),
    x.category,
    x.city_id,
    x.district_id,
    'Demo Area',
    CASE x.category
        WHEN 'traffic' THEN
            'Demo road and traffic infrastructure complaint for ' || x.district_name || '.'
        WHEN 'garbage' THEN
            'Demo garbage collection complaint for ' || x.district_name || '.'
        WHEN 'electricity' THEN
            'Demo street lighting and electricity complaint for ' || x.district_name || '.'
        ELSE
            'Demo water supply complaint for ' || x.district_name || '.'
    END,
    (
        SELECT u.id
        FROM users u
        WHERE u.role = 'citizen'
        ORDER BY u.id
        LIMIT 1
    ),
    (
        SELECT dpt.id
        FROM departments dpt
        WHERE dpt.category = x.category
        ORDER BY dpt.id
        LIMIT 1
    ),
    x.impact_score,
    x.urgency_score,
    CASE
        WHEN (x.impact_score + x.urgency_score) >= 14 THEN 'high'
        WHEN (x.impact_score + x.urgency_score) >= 8 THEN 'medium'
        ELSE 'low'
    END::severity_level,
    CASE ((x.n - 1) % 4)
        WHEN 0 THEN 'in_progress'
        WHEN 1 THEN 'assigned'
        WHEN 2 THEN 'pending'
        ELSE 'in_progress'
    END::complaint_status
FROM classified x;

COMMIT;
