# API Server

`backend/server_main.cpp` is the piece that was missing for the last few
sessions: a real HTTP server tying OOP, Assembly, and PostgreSQL together,
and serving the frontend itself so the whole app is one process on one
port.

```bash
make server-run
# or, with a specific port / connection string:
./bin/urban_insights_server 8080 "dbname=urban_insights user=postgres password=postgres host=localhost"
```

Then open `http://localhost:8080/` — that's the actual frontend, served by
this same server (`svr.set_mount_point("/", "../frontend")`), with the Map
page's WebGL now pulling live severity from the endpoints below instead of
only the offline fallback.

## Endpoints

| Method | Path | What it does |
|---|---|---|
| GET | `/api/health` | `{"status":"ok","database":true}` — quick check that the process is up and whether Postgres is reachable |
| GET | `/api/states` | Per-state severity summary (total/high/medium/low/resolved) — what the Map page's `loadLiveSeverity()` fetches |
| GET | `/api/rankings/cities?limit=20` | City leaderboard, straight from the `city_rankings` VIEW |
| GET | `/api/dashboard/summary` | total / resolved / pending / high-severity counts, for the Dashboard's stat cards |
| GET | `/api/complaints?limit=50` | Most recent complaints |
| GET | `/api/complaints/:id` | One complaint, 404 if it doesn't exist |
| POST | `/api/complaints/:id/resolve` | Marks a complaint resolved; requires an authenticated `admin` or `super_admin` session |
| GET | `/api/complaints/export` | All complaints as CSV (Plan.pdf's "download complaint data in form of excel file" — CSV opens natively in Excel) |
| POST | `/api/complaints` | Creates a complaint — see below, this is the one that touches every module |
| POST | `/api/ai/triage` | Authenticated, optional AI suggestion for complaint category, impact, and urgency; does not create or update a complaint |

### `POST /api/complaints`

```json
{
  "category": "Traffic",
  "city": "Pune",
  "locality": "Baner",
  "description": "Broken traffic signal causing jams",
  "citizenName": "Test User",
  "impactScore": 9,
  "urgencyScore": 8
}
```

What actually happens on this request, in order:

1. **OOP** — `makeComplaint()` (in `server_main.cpp`, the same pattern as
   `main.cpp`'s DSA demo) constructs the right `TrafficComplaint` /
   `GarbageComplaint` / `ElectricityComplaint` / `WaterComplaint`. An empty
   `description` throws `InvalidComplaintException` here, which the route
   catches and turns into a 400.
2. **Assembly** — `calculateSeverityAsm()` (`assembly/severity.asm`) is
   called directly with the category/impact/urgency, exactly like
   `Complaint::evaluateSeverity()` does internally.
3. **PostgreSQL** — `Database::createComplaint()` finds-or-creates the
   citizen and city rows, generates a reference code via the database's
   own `next_complaint_reference()` function, and inserts the row — which
   fires `schema.sql`'s status-history trigger automatically.
4. The created record (with its real `id`, `referenceCode`, and computed
   `severity`) comes back as the response, `201 Created`.

Tried with `impactScore: 9, urgencyScore: 8` on a Traffic complaint:
`(9*6 + 8*4) / 10 = 86 / 10 = 8`, and 8 > 7, so the response correctly came
back `"severity": "high"` — verified by hand, not just by the code running
without crashing.

## What's verified vs. what isn't yet

Tested end-to-end against a real, running PostgreSQL instance: every GET
endpoint against seeded data, a successful POST (checked the returned
severity by hand), a POST rejected for a missing field (400), a lookup for
a nonexistent id (404), and static file serving for the frontend itself.

**Not done yet:**
- The rest of the frontend (Dashboard's stat cards, Complaints list,
  Cities/rankings page, Report form) still uses its original hardcoded
  data — only the Map page's severity colours call this API so far.
- No authentication. `POST /api/complaints` accepts a citizen name as a
  plain string and finds-or-creates a matching user row; there's no
  login, so nothing here should be treated as a security boundary yet.
- The native OpenGL program (`opengl/native/`) still uses its own
  hardcoded fallback data — it doesn't call this API.

## Live geographic APIs (fixed)

- `GET /api/geography` — database-backed `states -> districts -> cities` master data used by the complaint form.
- `GET /api/states?category=all|traffic|water|garbage|electricity` — state totals, active/resolved counts and authoritative severity.
- `GET /api/map/districts?state=<state>&category=...` — real district aggregates; districts without active complaints return `severity: "none"`.
- `GET /api/rankings/cities?page=1&pageSize=25&state=&district=&severity=` — paginated city ranking with stable secondary city-name sorting.
- `POST /api/complaints` — requires `stateId`, `districtId`, `cityId`, category, locality, description, impact and urgency; the server validates the geographic relationship and calculates final severity through Assembly.

The browser never supplies a final severity value and the map never generates business metrics from geometry names.

`POST /api/ai/triage` accepts `{"description":"..."}` and returns a suggested category, impact score, urgency score, and reason. Configure `AI_API_KEY` on the Java server; `AI_API_URL` and `AI_MODEL` optionally select an OpenAI-compatible endpoint and model. The description is sent to that provider only after the user requests a suggestion. The browser never receives the provider key, and the values remain editable and are not submitted automatically.

The active Java backend also provides `POST /api/auth/login`, `GET /api/auth/me`, and `POST /api/auth/logout`. Admin resolution uses the `urban_session` cookie; unauthenticated or non-admin requests receive `403`. The database status trigger records the new status and resolution timestamp.
