# Computer Graphics Lab (2310218L) → Urban Insights Code Map

Course: **Computer Graphics Lab**, course code `2310218L` (matches the "OpenGL"
course in your Integrated Review slides exactly).

There are now **two** renderers of the same India severity map, on purpose:

| | Language | Where | Purpose |
|---|---|---|---|
| **`opengl/native/`** | **C++, real OpenGL (GL/GLU) + FreeGLUT** | a standalone desktop program | **the CG Lab course deliverable** - this is what to show a reviewer who wants to see OpenGL C++ code specifically |
| `opengl/webgl-india-map.js` | JavaScript, WebGL | the actual Map page in the running web app | the product feature - what a citizen using Urban Insights actually sees |

Both load the **same** boundary data and run the **same** ear-clipping
triangulation algorithm (`opengl/native/Triangulator.h` is a line-for-line
C++ port of the JS version) - loading the native program printed
`Loaded 34 states, 16842 triangles`, exactly matching the WebGL version's
triangle count, which is a good way to demonstrate the two are provably
doing the same geometric work, just through different graphics APIs.

Per your direction, none of this is split into six separate lab-exercise
files - the practicals define the boundary of what techniques are fair
game, and both renderers above are where those techniques actually get
used.

## The native C++ program (`opengl/native/`)

```bash
cd opengl/native
make run
```
Drag to pan, scroll wheel or `+`/`-` to zoom, click a state to print its
severity to the console and the window title, `R` to reset, `Esc` to quit.

| Course Outcome | Where in `opengl/native/main.cpp` | How |
|---|---|---|
| **CO1** primitives | `drawState()` | `glBegin(GL_TRIANGLES)` for fills, `glBegin(GL_LINE_LOOP)` for borders - real immediate-mode OpenGL calls, matching the style your practicals (triangle, color cube, etc.) already use. |
| **CO2** transformations | `mouseMotion()`, `mouseButton()`, `orthoBounds()` | Dragging and scrolling update `g_panX`/`g_panY`/`g_zoom`, which `orthoBounds()` turns into new `glOrtho` parameters every frame - the transformation is recomputed and reapplied each frame, not baked in once. |
| **CO3** 2D objects via algorithms | `Triangulator.h` | Ear-clipping triangulation (with a fan-triangulation fallback for near-degenerate input) - a direct C++ port of the same algorithm proven out in the WebGL version. |
| **CO4** projection & viewing | `display()`, `computeFitScale()` | `glOrtho(left, right, bottom, top, -1, 1)` with bounds computed from the pan/zoom state - a genuine orthographic projection, recomputed live. `screenToWorld()` is the same transform run backwards, for mouse picking. |
| **CO5** clipping | Handled by OpenGL itself | Geometry outside the current `glOrtho` bounds (e.g. panned off-screen) is clipped by the GL pipeline in hardware - the native equivalent of what `webgl-india-map.js` does by hand for its HTML labels. |
| **CO6** colour, light, texture | `colorFor()`, `drawState()`, `buildHatchStipple()` | Severity fill colour; a hover state blends 18% toward white as a simple "light" response; states with no data yet are filled through a hand-built 32×32 `glPolygonStipple` diagonal-hatch mask - classic legacy-OpenGL texturing, doing the same visual job as the WebGL version's fragment-shader hatch. |

**Toolchain note:** built against desktop OpenGL 1.x/GLU via FreeGLUT
(`-lGL -lGLU -lglut`), the same immediate-mode style (`glBegin`/`glVertex`/
`glColor3f`, `glOrtho`, `glPolygonStipple`) your practicals 1, 2, 4, and 6
already use - not the shader-based "core profile" OpenGL. Tested by
running under Xvfb with Mesa software rendering and capturing the actual
framebuffer output (loads all 34 states, triangulates and renders them
correctly, hatch pattern confirmed visible on no-data states).

## The WebGL version (`opengl/webgl-india-map.js`)

Unchanged from before - see the table below. As of this pass it also
fetches real severity data from `GET /api/states` (the new HTTP server,
`docs/API.md`) once that resolves, falling back to the same demo numbers
if the server isn't running - the map never breaks because the backend
happens to be off, it just doesn't show live data yet.

| Course Outcome | Where it lives | How |
|---|---|---|
| **CO1** — Apply OpenGL graphics primitives | `webgl-india-map.js`, `render()` | Every state fill is a `gl.TRIANGLES` draw call; every state border is a `gl.LINE_LOOP` draw call. |
| **CO2** — geometric transformations | `webgl-india-map.js`, `view` object + `uProjection` | Pan and zoom recombined into a 3×3 matrix and re-uploaded to the GPU on every interaction. |
| **CO3** — 2D objects via algorithms | `triangulateRing()` | Ear-clipping, same algorithm as the native port above. |
| **CO4** — projection and viewing | `project()` / `unproject()` / `currentMatrix()` | Longitude/latitude → clip space through a fitted equirectangular-style projection + the pan/zoom view transform. |
| **CO5** — clipping | `updateLabels()` | State-name labels explicitly tested against the visible viewport and hidden off-screen. |
| **CO6** — texture, light, colour | Fragment shader | Severity fill colour; hover brightens toward white; a procedural diagonal-hatch texture for no-data states, computed from `gl_FragCoord`. |

## City-level drill-down

Clicking a state and then "View city-level map" swaps the whole rendering
set from India's 34 states to that state's own districts - same
`buildFeatureBuffers()` pipeline (triangulate, upload to the GPU, colour
by severity), just fed different geometry and re-fit to that state's own
bounding box via `setBounds()`. District boundaries (594 districts across
all states, from the same public dataset as the state boundaries) are
split into one file per state under `opengl/districts/` and loaded
on-demand the first time a state is drilled into - Maharashtra's 34
districts are ~676KB, so nobody downloads data for states they never
click into. A "&larr; State Name" control appears to back out.

No real per-district complaint data exists yet (the database's `cities`
table covers 6 demo cities, not all ~600 districts), so each district's
severity is derived deterministically from its own name (same district
always gets the same colour, not random-per-reload) rather than pulled
from the API - clearly placeholder data, flagged as such in the code and
in `PROJECT_STATUS.md`, not something dressed up to look live.

Verified the same way as the rest of the map: drilled into Maharashtra in
a headless WebGL context, confirmed the centre pixel changed from
background to a real district fill colour, and rendered full screenshots
of both the drill-down view (34 individually-coloured districts, clean
triangulation) and the view after backing out (correctly restores the
full India map). Also caught and fixed a real bug this way: the district
script's `src` was initially relative to the map module itself instead of
the HTML document that loads it, which would have 404'd in a real
browser despite passing a test that pre-cached the data - confirmed the
fix by requesting the file through the actual running HTTP server instead
of trusting the relative-path reasoning alone.

## Data note

State boundaries come from a public, simplified GADM-derived dataset
(~34 states, ~17k boundary points, triangulated into ~16.8k GPU triangles
in both renderers). Two states carry pre-2011/pre-2007 names in the source
data (`Orissa`, `Uttaranchal`), relabelled to `Odisha`/`Uttarakhand` for
display in both `webgl-india-map.js` and `opengl/native/main.cpp`. The
boundary set also predates the 2014 Telangana/Andhra Pradesh split.

Severity numbers: the WebGL map now pulls these live from
`GET /api/states` (backed by `database/schema.sql`) with the old
`SEVERITY_DEMO` object as an offline fallback. The native C++ program
still uses the fallback numbers directly (`SEVERITY_DEMO` in
`opengl/native/main.cpp`) - wiring it to fetch from the same API would
mean adding an HTTP client to a GLUT app, which is possible but not done
in this pass; see `PROJECT_STATUS.md`.

## Verification

- **Native (C++):** built with `g++ -std=c++17 -Wall -Wextra` (zero
  warnings), run headlessly under Xvfb with Mesa software rendering, and
  the actual rendered framebuffer captured and visually inspected -
  correct state fills, correct borders, correct hatch texture on
  no-data states, matching the WebGL version's colours exactly.
- **WebGL:** flew the camera to Maharashtra, Kerala and Chhattisgarh in
  turn and read back the centre pixel each time via a headless WebGL
  context - confirmed exact RGB matches for high/low/no-data. Live-data
  upgrade path tested with a mocked `/api/states` response: confirmed the
  map starts with fallback data, then correctly overwrites it (including
  correctly *downgrading* a state to "no data" when the live total is
  zero) the moment the fetch resolves.

