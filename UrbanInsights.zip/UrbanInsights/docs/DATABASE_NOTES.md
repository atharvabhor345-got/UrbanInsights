# Database Notes

`database/schema.sql` is the persistent-storage design for the whole app.
It isn't tied to a single course's outcomes the way OOP/DSA/CG are (the
Integrated Review slides list PostgreSQL as a technology-stack choice, not
a course with its own practicals) - so this file is about the design
itself and how it was verified, not a concept-mapping table.

## How it mirrors the C++ model

| Database | C++ equivalent |
|---|---|
| `users` + `citizen_profiles` + `admin_profiles` (role-specific tables keyed on `user_id`) | `User` (abstract) → `Citizen`, `Admin`, `SuperAdmin` in `backend/User.h` |
| `complaints` | `Complaint` (abstract) + its 4 subclasses in `backend/Complaint.h` |
| `complaint_status_history` (append-only, trigger-populated) | `dsa/Stack.h`'s `StatusHistoryStack` - same idea, one lives in the database, one in the running process's memory |
| `city_category_summary` VIEW | `dsa/CityArray.h`'s `CityComplaintGrid` - same idea again |
| `city_rankings` VIEW (`RANK() OVER (...)`) | `dsa/Sorting.h`'s city-leaderboard sorts |
| Primary key lookups on `complaints.id` | `dsa/HashTable.h`'s O(1) id index |

The pattern throughout: every in-memory DSA structure has a relational
twin here. That's deliberate - it's the same underlying idea (fast lookup,
ranked summaries, an audit trail) implemented twice for two different
jobs, not two unrelated designs that happen to look similar.

## Automation

A trigger (`log_complaint_status_change`) fires on every `INSERT` and on
any `UPDATE` that actually changes `status`, writing a row to
`complaint_status_history` automatically - the application layer can never
forget to log a status change or log one inconsistently, because it isn't
the application's job to remember. The same trigger also stamps
`resolved_at` the moment status flips to `'resolved'`.

`next_complaint_reference()` generates the human-readable ids Plan.pdf's
Report page needs (`UI-2026-000123`-style) from a dedicated sequence.

## Verification

Actually run against a real PostgreSQL 16 instance while writing this, not
just checked for valid syntax by eye:

```
$ psql -d urbaninsights -f database/schema.sql
CREATE TYPE  (x5)   CREATE TABLE (x9)   CREATE INDEX (x10)
CREATE FUNCTION (x2)   CREATE TRIGGER (x2)   CREATE SEQUENCE
CREATE VIEW (x2)   COMMIT
```

`database/seed.sql` loads a small realistic dataset on top (4 states, 6
cities, 4 departments, 5 users across all three roles, 4 complaints) and
was used to exercise the schema for real:

- **Constraints actually reject bad data**: a duplicate email correctly
  hit `users_email_key`; an `impact_score` of 99 correctly hit the
  `impact_score BETWEEN 0 AND 10` check. (The first seed draft also caught
  a real bug in the *seed data itself* - a `resolved_at` earlier than its
  own `reported_at` - via the `resolved_at >= reported_at` CHECK
  constraint, which is exactly the kind of mistake a constraint like that
  exists to catch.)
- **The trigger fires on both paths**: status history correctly gained a
  row on initial `INSERT`, and a second row after an `UPDATE ... SET
  status = 'resolved'` - with `resolved_at` auto-populated by the same
  trigger.
- **Both views return correct, sensible results**: `city_rankings` ranked
  Pune first with 2 complaints, Mumbai and Nashik tied for second with 1
  each (ties handled correctly by `RANK()`, which skips a place rather
  than compressing it); `city_category_summary` broke totals down
  correctly per city per category.

## Not done yet

The C++ backend doesn't connect to this database yet - `main.cpp`'s DSA
demo manages complaints entirely in memory. Wiring that up needs a
PostgreSQL C++ client (`libpqxx` is the standard choice) and, more
importantly, the HTTP layer that doesn't exist yet either (see
`PROJECT_STATUS.md`) - the database is ready for that connection, not
plugged into it.
