# DSA Concepts → Urban Insights Code Map

Every structure below is built from scratch with raw pointers and arrays -
no `std::list`, `std::queue`, `std::stack`, or `std::unordered_map` anywhere
in `dsa/`. (The OOP module's `Department` class does use `std::vector` and
`std::list`, but that's deliberately scoped to the OOP course's STL
practical - see the note in `docs/OOP_PRACTICALS_MAP.md`. The two are kept
separate on purpose.)

All of it operates on the real `Complaint` hierarchy from `backend/Complaint.h`
- run `make run` and look at the "DSA :" banners in the output; every
structure below is exercised on the same six complaints, not toy integers.

| Concept | File | What it does | Ownership |
|---|---|---|---|
| **Doubly Linked List** | `DoublyLinkedList.h/.cpp` | `ComplaintList` is the master, ground-truth store for every complaint - insert at head/tail, remove by id, forward/backward traversal. | **Owns** every `Complaint*` inserted into it. Its destructor (and `removeById`) are the only places in `dsa/` that ever call `delete` on a `Complaint*`. |
| **Hashing** | `HashTable.h/.cpp` | `ComplaintHashTable` maps id → the linked list's node, giving O(1) average lookup instead of the list's O(n) scan. Division-method hash (`id % 101`, 101 chosen prime), separate chaining for collisions. | Non-owning index only - never deletes anything. |
| **Queue** | `Queue.h/.cpp` | `ComplaintQueue`, a fixed-capacity **circular array** (not a linked list) - the city-wide FIFO intake pipeline. `main.cpp` dequeues in arrival order to decide department routing. | Non-owning. |
| **Stack** | `Stack.h/.cpp` | `StatusHistoryStack`, array-based LIFO of `StatusChangeRecord` values - a system-wide, most-recent-first status audit trail (what a Status/Activity page would read from). | Stores records **by value** - no pointer ownership question at all. |
| **2D Array** | `CityArray.h/.cpp` | `CityComplaintGrid` - a genuine `int**` grid (individually allocated rows, not `vector<vector<int>>>`), city × category complaint counts, growable. Relational twin: `database/schema.sql`'s `city_category_summary` VIEW. | N/A (owns its own `int`s and city-name strings only). |
| **Searching** | `Searching.h/.cpp` | `linearSearchById` (O(n)) and `binarySearchById` (O(log n), requires sorted input) - both count comparisons so `main.cpp` can print real numbers side by side instead of just asserting one is faster. | Read-only over a borrowed `Complaint**` snapshot. |
| **Sorting** | `Sorting.h/.cpp` | `bubbleSortByCount` / `quickSortByCount` rank cities by complaint count (used for the leaderboard); `insertionSortById` prepares a `Complaint**` snapshot for `binarySearchById`. All three count comparisons and swaps. | Sorts arrays in place; never touches the linked list's own order. |

## Why the same `Complaint*` isn't double-owned

`ComplaintList` owns every complaint created in the DSA section of
`main.cpp`. The hash table, queue, and city grid all hold **non-owning**
pointers into that same set. When `main.cpp` shows the queue "routing"
complaints to departments, it deliberately logs the routing decision rather
than calling the OOP module's `Department::receiveComplaint()` on those
same objects - that method takes ownership, and handing the same pointer to
two owners is exactly how a double-free bug gets written. The whole
integrated program (OOP + DSA together) runs clean under valgrind: 152
allocs, 152 frees, 0 leaks, 0 errors.

## Verification

```
g++ -std=c++17 -Wall -Wextra -O2 -Ibackend -Idsa  ...   # zero warnings
valgrind --leak-check=full ./bin/urban_insights_oop_demo
  ==  HEAP SUMMARY: in use at exit: 0 bytes in 0 blocks
  ==  total heap usage: 152 allocs, 152 frees, 109,077 bytes allocated
  ==  ERROR SUMMARY: 0 errors from 0 contexts
```

A worked example worth pointing out live in review: the bubble-sort vs
quick-sort comparison in `main.cpp`'s output can show quick sort doing
*more* swap operations than bubble sort on the same small, already-ranked
city list. That's not a bug - the seed data happens to already be in
descending order, so bubble sort's early-exit check finds it sorted after
one pass with zero swaps, while quick sort's partitioning scheme still goes
through its full recursive break-down regardless of input order. It's a
genuinely good illustration of why Big-O describes worst-case/average
behaviour, not a guarantee for every input.
