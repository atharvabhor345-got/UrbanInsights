# OOP Practical / CO Mapping — Java

The active OOP implementation is now in `java-backend/src/main/java/com/urbaninsights/model/`. The old C++ OOP implementation is preserved under `legacy_cpp_oop/` only for reference.

## Core Java mapping
- Class & objects: `Complaint`, `User`, `Department`
- Constructors: complaint subclasses and user subclasses
- Encapsulation: private fields with public getters/setters
- Inheritance: `Complaint` → `TrafficComplaint`, `GarbageComplaint`, `ElectricityComplaint`, `WaterComplaint`; `User` → `Citizen`, `Admin` → `SuperAdmin`
- Abstraction: abstract `Complaint` and `User`
- Polymorphism: overridden `getCategory()` and `calculatePriorityScore()`
- Exception handling: `InvalidComplaintException`
- Static members: `Complaint.nextId` and `Complaint.totalCreated`

The C++ DSA module remains separate in `dsa/`.
