#include "CityArray.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

CityComplaintGrid::CityComplaintGrid(int initialCapacity)
    : cityNames(new std::string[initialCapacity]),
      grid(new int*[initialCapacity]),
      cityCount(0), capacity(initialCapacity) {
    for (int i = 0; i < capacity; i++) {
        grid[i] = new int[CATEGORY_COUNT];
        for (int j = 0; j < CATEGORY_COUNT; j++) grid[i][j] = 0;
    }
}

CityComplaintGrid::~CityComplaintGrid() {
    for (int i = 0; i < capacity; i++) delete[] grid[i];
    delete[] grid;
    delete[] cityNames;
}

int CityComplaintGrid::categoryIndex(const std::string& category) {
    if (category == "Traffic")     return 0;
    if (category == "Garbage")     return 1;
    if (category == "Electricity") return 2;
    if (category == "Water")       return 3;
    return -1;
}

int CityComplaintGrid::findCityIndex(const std::string& city) const {
    for (int i = 0; i < cityCount; i++) {
        if (cityNames[i] == city) return i;
    }
    return -1;
}

void CityComplaintGrid::grow() {
    int newCapacity = capacity * 2;
    std::string* newNames = new std::string[newCapacity];
    int** newGrid = new int*[newCapacity];

    for (int i = 0; i < capacity; i++) {
        newNames[i] = cityNames[i];
        newGrid[i] = grid[i]; // hand over ownership of each existing row as-is
    }
    for (int i = capacity; i < newCapacity; i++) {
        newGrid[i] = new int[CATEGORY_COUNT];
        for (int j = 0; j < CATEGORY_COUNT; j++) newGrid[i][j] = 0;
    }

    delete[] cityNames;
    delete[] grid; // only the array-of-pointers, the rows themselves were reused above

    cityNames = newNames;
    grid = newGrid;
    capacity = newCapacity;
}

void CityComplaintGrid::recordComplaint(const std::string& city, const std::string& category) {
    int catIdx = categoryIndex(category);
    if (catIdx == -1) return; // unknown category - ignore rather than corrupt the grid

    int cityIdx = findCityIndex(city);
    if (cityIdx == -1) {
        if (cityCount == capacity) grow();
        cityIdx = cityCount;
        cityNames[cityIdx] = city;
        cityCount++;
    }
    grid[cityIdx][catIdx]++;
}

int CityComplaintGrid::getCount(const std::string& city, const std::string& category) const {
    int cityIdx = findCityIndex(city);
    int catIdx = categoryIndex(category);
    if (cityIdx == -1 || catIdx == -1) return 0;
    return grid[cityIdx][catIdx];
}

int CityComplaintGrid::getCityTotal(const std::string& city) const {
    int cityIdx = findCityIndex(city);
    if (cityIdx == -1) return 0;
    int total = 0;
    for (int j = 0; j < CATEGORY_COUNT; j++) total += grid[cityIdx][j];
    return total;
}

int CityComplaintGrid::getCategoryTotal(const std::string& category) const {
    int catIdx = categoryIndex(category);
    if (catIdx == -1) return 0;
    int total = 0;
    for (int i = 0; i < cityCount; i++) total += grid[i][catIdx];
    return total;
}

std::string CityComplaintGrid::getBusiestCity() const {
    if (cityCount == 0) return "";
    int bestIdx = 0, bestTotal = getCityTotal(cityNames[0]);
    for (int i = 1; i < cityCount; i++) {
        int total = getCityTotal(cityNames[i]);
        if (total > bestTotal) { bestTotal = total; bestIdx = i; }
    }
    return cityNames[bestIdx];
}

void CityComplaintGrid::printTable() const {
    const char* categories[CATEGORY_COUNT] = { "Traffic", "Garbage", "Electricity", "Water" };
    std::cout << "  " << std::setw(14) << std::left << "City";
    for (int j = 0; j < CATEGORY_COUNT; j++) std::cout << std::setw(13) << categories[j];
    std::cout << std::setw(8) << "Total" << "\n";

    for (int i = 0; i < cityCount; i++) {
        std::cout << "  " << std::setw(14) << std::left << cityNames[i];
        for (int j = 0; j < CATEGORY_COUNT; j++) std::cout << std::setw(13) << grid[i][j];
        std::cout << std::setw(8) << getCityTotal(cityNames[i]) << "\n";
    }
}
