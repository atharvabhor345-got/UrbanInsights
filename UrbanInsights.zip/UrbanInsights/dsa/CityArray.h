#ifndef DSA_CITY_ARRAY_H
#define DSA_CITY_ARRAY_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/CityArray.h
    ================================================================
    DSA CONCEPT: 2D Array (city x problem-type summary)

    A genuine 2D array (int** grid, rows allocated individually - not
    a vector<vector<int>>) tallying complaint counts per city per
    category. Backs the dashboard's city-vs-category breakdown; the
    relational twin of this is database/schema.sql's
    city_category_summary VIEW - same idea, one lives in the running
    C++ process's memory, the other lives in the database.
    ================================================================
*/

#include <string>
using namespace std;
class CityComplaintGrid {
private:
    static const int CATEGORY_COUNT = 4; // Traffic, Garbage, Electricity, Water

    string* cityNames; // dynamically allocated array of city names (rows)
    int** grid;              // grid[city][category] -> count, a real 2D array
    int cityCount;
    int capacity;

    int findCityIndex(const  string& city) const;
    static int categoryIndex(const  string& category);
    void grow(); // doubles capacity when full

public:
    explicit CityComplaintGrid(int initialCapacity = 8);
    ~CityComplaintGrid();

    CityComplaintGrid(const CityComplaintGrid&) = delete;
    CityComplaintGrid& operator=(const CityComplaintGrid&) = delete;

    void recordComplaint(const  string& city, const  string& category);
    int getCount(const  string& city, const  string& category) const;
    int getCityTotal(const  string& city) const;
    int getCategoryTotal(const  string& category) const;
     string getBusiestCity() const;

    int getCityCount() const { return cityCount; }
    const  string& cityNameAt(int i) const { return cityNames[i]; }

    void printTable() const;
};

#endif // DSA_CITY_ARRAY_H
