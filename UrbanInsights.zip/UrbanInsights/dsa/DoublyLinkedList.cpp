#include "DoublyLinkedList.h"
#include <iostream>

ComplaintList::ComplaintList() : head(nullptr), tail(nullptr), count(0) {}

ComplaintList::~ComplaintList() {
    ComplaintNode* current = head;
    while (current != nullptr) {
        ComplaintNode* next = current->next;
        delete current->data;   // this list owns the Complaint objects
        delete current;
        current = next;
    }
}

ComplaintNode* ComplaintList::insertAtHead(Complaint* c) {
    ComplaintNode* node = new ComplaintNode(c);
    if (head == nullptr) {
        head = tail = node;
    } else {
        node->next = head;
        head->prev = node;
        head = node;
    }
    count++;
    return node;
}

ComplaintNode* ComplaintList::insertAtTail(Complaint* c) {
    ComplaintNode* node = new ComplaintNode(c);
    if (tail == nullptr) {
        head = tail = node;
    } else {
        node->prev = tail;
        tail->next = node;
        tail = node;
    }
    count++;
    return node;
}

bool ComplaintList::removeById(int id) {
    ComplaintNode* target = findById(id);
    if (target == nullptr) return false;

    if (target->prev != nullptr) target->prev->next = target->next;
    else head = target->next;

    if (target->next != nullptr) target->next->prev = target->prev;
    else tail = target->prev;

    delete target->data;
    delete target;
    count--;
    return true;
}

ComplaintNode* ComplaintList::findById(int id) const {
    ComplaintNode* current = head;
    while (current != nullptr) {
        if (current->data->getId() == id) return current;
        current = current->next;
    }
    return nullptr; // O(n) on purpose - dsa/HashTable.cpp is the O(1) alternative
}

void ComplaintList::traverseForward(void (*visit)(const Complaint*)) const {
    for (ComplaintNode* cur = head; cur != nullptr; cur = cur->next) {
        visit(cur->data);
    }
}

void ComplaintList::traverseBackward(void (*visit)(const Complaint*)) const {
    for (ComplaintNode* cur = tail; cur != nullptr; cur = cur->prev) {
        visit(cur->data);
    }
}

Complaint** ComplaintList::toArray() const {
    if (count == 0) return nullptr;
    Complaint** arr = new Complaint*[count];
    int i = 0;
    for (ComplaintNode* cur = head; cur != nullptr; cur = cur->next) {
        arr[i++] = cur->data;
    }
    return arr;
}
