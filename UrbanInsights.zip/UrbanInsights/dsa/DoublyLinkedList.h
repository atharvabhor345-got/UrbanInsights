#ifndef DSA_DOUBLY_LINKED_LIST_H
#define DSA_DOUBLY_LINKED_LIST_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/DoublyLinkedList.h
    ================================================================
    DSA CONCEPT: Doubly Linked List (complaint records)

    This is the master, ground-truth store for every Complaint in the
    running system - built from raw nodes and pointers, no std::list
    anywhere. It OWNS every Complaint* inserted into it: the destructor
    (and removeById) delete both the node and the Complaint it holds.

    Everything else in dsa/ that touches complaints - the hash table,
    the queue, the city grid - stores non-owning pointers that point
    INTO this list. This one list is the only thing that ever calls
    `delete` on a Complaint*, which keeps ownership unambiguous across
    the whole DSA module.
    ================================================================
*/

#include "Complaint.h"
#include <string>

struct ComplaintNode {
    Complaint* data;
    ComplaintNode* prev;
    ComplaintNode* next;
    explicit ComplaintNode(Complaint* c) : data(c), prev(nullptr), next(nullptr) {}
};

class ComplaintList {
private:
    ComplaintNode* head;
    ComplaintNode* tail;
    int count;

public:
    ComplaintList();
    ~ComplaintList(); // deletes every node AND every Complaint* it holds

    // Non-copyable: this list owns raw pointers, so a shallow copy
    // would double-delete. Deleting these is the from-scratch DSA
    // equivalent of what std::unique_ptr gives you automatically.
    ComplaintList(const ComplaintList&) = delete;
    ComplaintList& operator=(const ComplaintList&) = delete;

    ComplaintNode* insertAtHead(Complaint* c);
    ComplaintNode* insertAtTail(Complaint* c);

    bool removeById(int id);
    ComplaintNode* findById(int id) const;   // O(n) linear traversal

    void traverseForward(void (*visit)(const Complaint*)) const;
    void traverseBackward(void (*visit)(const Complaint*)) const;

    int size() const { return count; }
    bool isEmpty() const { return count == 0; }
    ComplaintNode* getHead() const { return head; }
    ComplaintNode* getTail() const { return tail; }

    // Snapshot every Complaint* into a freshly-allocated array (caller
    // deletes the array itself, but NOT the Complaint*s inside it -
    // this list still owns those). Used by Searching.cpp/Sorting.cpp,
    // which operate on plain arrays.
    Complaint** toArray() const;
};

#endif // DSA_DOUBLY_LINKED_LIST_H
