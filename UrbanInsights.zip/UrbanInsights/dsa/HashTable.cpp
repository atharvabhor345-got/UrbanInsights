#include "HashTable.h"
#include <iostream>

ComplaintHashTable::ComplaintHashTable() : entryCount(0) {
    for (int i = 0; i < TABLE_SIZE; i++) buckets[i] = nullptr;
}

ComplaintHashTable::~ComplaintHashTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        HashEntry* cur = buckets[i];
        while (cur != nullptr) {
            HashEntry* next = cur->next;
            delete cur;             // deletes the INDEX entry, never the ComplaintNode/Complaint
            cur = next;
        }
    }
}

int ComplaintHashTable::hashFunction(int key) const {
    // Division method: simple, and TABLE_SIZE being prime spreads
    // sequential complaint ids (1000, 1001, 1002, ...) evenly enough
    // in practice for this scale of data.
    int h = key % TABLE_SIZE;
    return h < 0 ? h + TABLE_SIZE : h; // guard against negative ids
}

void ComplaintHashTable::insert(int id, ComplaintNode* node) {
    int idx = hashFunction(id);
    HashEntry* entry = new HashEntry(id, node);
    entry->next = buckets[idx];   // insert at the head of the chain: O(1)
    buckets[idx] = entry;
    entryCount++;
}

ComplaintNode* ComplaintHashTable::search(int id) const {
    int idx = hashFunction(id);
    HashEntry* cur = buckets[idx];
    while (cur != nullptr) {
        if (cur->key == id) return cur->value;
        cur = cur->next;
    }
    return nullptr;
}

bool ComplaintHashTable::remove(int id) {
    int idx = hashFunction(id);
    HashEntry* cur = buckets[idx];
    HashEntry* prev = nullptr;
    while (cur != nullptr) {
        if (cur->key == id) {
            if (prev == nullptr) buckets[idx] = cur->next;
            else prev->next = cur->next;
            delete cur;
            entryCount--;
            return true;
        }
        prev = cur;
        cur = cur->next;
    }
    return false;
}

void ComplaintHashTable::displayStats() const {
    int usedBuckets = 0, longestChain = 0;
    for (int i = 0; i < TABLE_SIZE; i++) {
        int chainLen = 0;
        for (HashEntry* cur = buckets[i]; cur != nullptr; cur = cur->next) chainLen++;
        if (chainLen > 0) usedBuckets++;
        if (chainLen > longestChain) longestChain = chainLen;
    }
    std::cout << "  HashTable: " << entryCount << " entries across " << TABLE_SIZE
              << " buckets (" << usedBuckets << " used, longest chain " << longestChain
              << "), load factor " << loadFactor() << "\n";
}
