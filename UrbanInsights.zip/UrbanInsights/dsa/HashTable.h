#ifndef DSA_HASH_TABLE_H
#define DSA_HASH_TABLE_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/HashTable.h
    ================================================================
    DSA CONCEPT: Hashing (instant complaint ID lookup)

    Maps a complaint id -> the ComplaintNode* holding it inside
    dsa/DoublyLinkedList.h's ComplaintList, giving O(1) average-case
    lookup instead of ComplaintList::findById's O(n) scan.

    This table is a non-owning INDEX only: it never calls `delete` on
    a ComplaintNode or a Complaint. The ComplaintList remains the one
    place that owns that memory (see DoublyLinkedList.h's header
    comment) - if this table deleted things too, removing a complaint
    from one structure would leave the other with a dangling pointer.

    Collisions are handled with separate chaining (each bucket is a
    small linked list of entries) - no std::unordered_map involved.
    ================================================================
*/

#include "DoublyLinkedList.h"

struct HashEntry {
    int key;
    ComplaintNode* value;
    HashEntry* next;
    HashEntry(int k, ComplaintNode* v) : key(k), value(v), next(nullptr) {}
};

class ComplaintHashTable {
private:
    static const int TABLE_SIZE = 101; // prime -> fewer clustered collisions
    HashEntry* buckets[TABLE_SIZE];
    int entryCount;

    int hashFunction(int key) const;

public:
    ComplaintHashTable();
    ~ComplaintHashTable();

    ComplaintHashTable(const ComplaintHashTable&) = delete;
    ComplaintHashTable& operator=(const ComplaintHashTable&) = delete;

    void insert(int id, ComplaintNode* node);
    ComplaintNode* search(int id) const;   // nullptr if not found
    bool remove(int id);                   // removes the INDEX entry only

    int size() const { return entryCount; }
    double loadFactor() const { return static_cast<double>(entryCount) / TABLE_SIZE; }
    void displayStats() const;
};

#endif // DSA_HASH_TABLE_H
