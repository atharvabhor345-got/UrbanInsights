#include "Queue.h"
#include <iostream>

ComplaintQueue::ComplaintQueue(int cap)
    : items(new Complaint*[cap]), capacity(cap), frontIdx(0), rearIdx(-1), count(0) {}

ComplaintQueue::~ComplaintQueue() {
    delete[] items; // non-owning: never deletes the Complaint objects themselves
}

bool ComplaintQueue::enqueue(Complaint* c) {
    if (isFull()) return false;
    rearIdx = (rearIdx + 1) % capacity;   // wrap around - the "circular" part
    items[rearIdx] = c;
    count++;
    return true;
}

Complaint* ComplaintQueue::dequeue() {
    if (isEmpty()) return nullptr;
    Complaint* c = items[frontIdx];
    frontIdx = (frontIdx + 1) % capacity;
    count--;
    return c;
}

Complaint* ComplaintQueue::peekFront() const {
    if (isEmpty()) return nullptr;
    return items[frontIdx];
}

void ComplaintQueue::display() const {
    std::cout << "  Queue (" << count << "/" << capacity << ", front-to-rear): ";
    if (isEmpty()) { std::cout << "(empty)\n"; return; }
    int idx = frontIdx;
    for (int i = 0; i < count; i++) {
        std::cout << "#" << items[idx]->getId();
        if (i != count - 1) std::cout << " -> ";
        idx = (idx + 1) % capacity;
    }
    std::cout << "\n";
}
