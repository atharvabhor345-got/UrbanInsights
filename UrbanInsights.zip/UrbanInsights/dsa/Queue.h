#ifndef DSA_QUEUE_H
#define DSA_QUEUE_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/Queue.h
    ================================================================
    DSA CONCEPT: Queue (FIFO complaint processing)

    A fixed-capacity CIRCULAR array queue - the classic DSA-practical
    version, not a linked list wearing a queue's name. front/rear wrap
    around with modular arithmetic instead of shifting every element
    on dequeue.

    This is the city-wide intake pipeline: every new complaint is
    enqueued the instant it's filed, and a dispatcher (see main.cpp)
    dequeues them in the exact order they arrived to hand them to
    Department::operator+= (backend/Department.h). It stores
    non-owning Complaint* - dsa/DoublyLinkedList.h's ComplaintList is
    still the only owner.
    ================================================================
*/

#include "Complaint.h"

class ComplaintQueue {
private:
    Complaint** items;
    int capacity;
    int frontIdx;
    int rearIdx;
    int count;

public:
    explicit ComplaintQueue(int capacity = 64);
    ~ComplaintQueue();

    ComplaintQueue(const ComplaintQueue&) = delete;
    ComplaintQueue& operator=(const ComplaintQueue&) = delete;

    bool enqueue(Complaint* c);
    Complaint* dequeue();      // returns nullptr if empty
    Complaint* peekFront() const;

    bool isEmpty() const { return count == 0; }
    bool isFull() const { return count == capacity; }
    int size() const { return count; }

    void display() const;
};

#endif // DSA_QUEUE_H
