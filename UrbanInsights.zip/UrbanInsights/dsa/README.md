# DSA — C++ module

This remains C++ and is independent from the Java OOP layer. The existing implementations cover Queue, Stack, Hash Table, Linked List, 2D Array, Searching and Sorting.

The Java backend owns the OOP/database/API responsibilities. DSA remains a separate C++ course module so each subject has a clear language boundary.
