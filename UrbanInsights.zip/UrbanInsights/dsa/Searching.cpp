#include "Searching.h"
#include <algorithm>
#include <cctype>

int linearSearchById(Complaint** arr, int n, int targetId, long& comparisons) {
    comparisons = 0;
    for (int i = 0; i < n; i++) {
        comparisons++;
        if (arr[i]->getId() == targetId) return i;
    }
    return -1;
}

int binarySearchById(Complaint** sortedArr, int n, int targetId, long& comparisons) {
    comparisons = 0;
    int low = 0, high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        comparisons++;
        int midId = sortedArr[mid]->getId();
        if (midId == targetId) return mid;
        if (midId < targetId) low = mid + 1;
        else high = mid - 1;
    }
    return -1;
}

static std::string toLower(const std::string& s) {
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(),
                    [](unsigned char c) { return std::tolower(c); });
    return out;
}

int linearSearchByCityName(Complaint** arr, int n, const std::string& cityQuery, long& comparisons) {
    comparisons = 0;
    std::string query = toLower(cityQuery);
    for (int i = 0; i < n; i++) {
        comparisons++;
        if (toLower(arr[i]->getCity()).find(query) != std::string::npos) return i;
    }
    return -1;
}
