#ifndef DSA_SEARCHING_H
#define DSA_SEARCHING_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/Searching.h
    ================================================================
    DSA CONCEPT: Searching

    Two classic searches over a plain Complaint** array (as produced
    by ComplaintList::toArray()), each counting the comparisons it
    makes so the O(n) vs O(log n) difference isn't just asserted in a
    comment - main.cpp prints the actual counts side by side.

    binarySearchById requires the array to be sorted by id first (see
    Sorting.cpp's sortComplaintsById helper).
    ================================================================
*/

#include "Complaint.h"

// Returns the index of the complaint with the given id, or -1.
// `comparisons` is incremented once per id check, out parameter so
// callers can report exactly how much work each algorithm did.
int linearSearchById(Complaint** arr, int n, int targetId, long& comparisons);
int binarySearchById(Complaint** sortedArr, int n, int targetId, long& comparisons);

// Simple case-insensitive substring search over city names - the
// "search a city" box on the Map page is conceptually this, run
// against real complaint records instead of the state-boundary list.
int linearSearchByCityName(Complaint** arr, int n, const std::string& cityQuery, long& comparisons);

#endif // DSA_SEARCHING_H
