#include "Sorting.h"

static void swapCityStat(CityStat& a, CityStat& b) {
    CityStat tmp = a;
    a = b;
    b = tmp;
}

void bubbleSortByCount(CityStat* arr, int n, long& comparisons, long& swaps) {
    comparisons = 0;
    swaps = 0;
    for (int i = 0; i < n - 1; i++) {
        bool swappedThisPass = false;
        for (int j = 0; j < n - 1 - i; j++) {
            comparisons++;
            if (arr[j].count < arr[j + 1].count) { // descending order
                swapCityStat(arr[j], arr[j + 1]);
                swaps++;
                swappedThisPass = true;
            }
        }
        if (!swappedThisPass) break; // already sorted - classic bubble-sort early exit
    }
}

static int partition(CityStat* arr, int low, int high, long& comparisons, long& swaps) {
    int pivot = arr[high].count;
    int i = low - 1;
    for (int j = low; j < high; j++) {
        comparisons++;
        if (arr[j].count > pivot) { // descending order
            i++;
            swapCityStat(arr[i], arr[j]);
            swaps++;
        }
    }
    swapCityStat(arr[i + 1], arr[high]);
    swaps++;
    return i + 1;
}

void quickSortByCount(CityStat* arr, int low, int high, long& comparisons, long& swaps) {
    if (low >= high) return;
    int pivotIndex = partition(arr, low, high, comparisons, swaps);
    quickSortByCount(arr, low, pivotIndex - 1, comparisons, swaps);
    quickSortByCount(arr, pivotIndex + 1, high, comparisons, swaps);
}

void insertionSortById(Complaint** arr, int n, long& comparisons, long& swaps) {
    comparisons = 0;
    swaps = 0;
    for (int i = 1; i < n; i++) {
        Complaint* key = arr[i];
        int j = i - 1;
        while (j >= 0) {
            comparisons++;
            if (arr[j]->getId() <= key->getId()) break;
            arr[j + 1] = arr[j];
            swaps++;
            j--;
        }
        arr[j + 1] = key;
    }
}
