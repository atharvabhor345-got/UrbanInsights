#ifndef DSA_SORTING_H
#define DSA_SORTING_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/Sorting.h
    ================================================================
    DSA CONCEPT: Sorting (rank cities)

    Three sorts, each earning its place rather than piled on for
    variety: bubble sort as the simple O(n^2) baseline, quick sort as
    the efficient O(n log n) city-ranking algorithm (this is what
    actually powers the leaderboard in main.cpp), and insertion sort
    to prepare a Complaint** array by id, which
    dsa/Searching.h's binarySearchById needs as a precondition.

    Every sort counts its own comparisons and swaps so main.cpp can
    print bubble vs quick sort's work side by side on the same data,
    instead of just asserting one is faster.
    ================================================================
*/

#include "Complaint.h"
#include <string>

struct CityStat {
    std::string name;
    int count;
};

// Both sort descending by `count` - highest complaint count first,
// i.e. exactly the order a city leaderboard wants.
void bubbleSortByCount(CityStat* arr, int n, long& comparisons, long& swaps);
void quickSortByCount(CityStat* arr, int low, int high, long& comparisons, long& swaps);

// Ascending by id - a precondition for dsa/Searching.h's binarySearchById.
void insertionSortById(Complaint** arr, int n, long& comparisons, long& swaps);

#endif // DSA_SORTING_H
