#include "Stack.h"
#include <iostream>

StatusHistoryStack::StatusHistoryStack(int cap)
    : items(new StatusChangeRecord[cap]), capacity(cap), topIdx(-1) {}

StatusHistoryStack::~StatusHistoryStack() {
    delete[] items;
}

bool StatusHistoryStack::push(const StatusChangeRecord& record) {
    if (isFull()) return false;
    items[++topIdx] = record;
    return true;
}

bool StatusHistoryStack::pop(StatusChangeRecord& out) {
    if (isEmpty()) return false;
    out = items[topIdx--];
    return true;
}

bool StatusHistoryStack::peek(StatusChangeRecord& out) const {
    if (isEmpty()) return false;
    out = items[topIdx];
    return true;
}

void StatusHistoryStack::displayRecent(int n) const {
    std::cout << "  Status history, most recent first:\n";
    if (isEmpty()) { std::cout << "    (none yet)\n"; return; }
    int shown = 0;
    for (int i = topIdx; i >= 0 && shown < n; i--, shown++) {
        std::cout << "    #" << items[i].complaintId << " -> "
                  << statusToString(items[i].status);
        if (!items[i].note.empty()) std::cout << "  (" << items[i].note << ")";
        std::cout << "\n";
    }
}
