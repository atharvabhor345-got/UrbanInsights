#ifndef DSA_STACK_H
#define DSA_STACK_H

/*
    ================================================================
    URBAN INSIGHTS -- dsa/Stack.h
    ================================================================
    DSA CONCEPT: Stack (status history)

    A fixed-capacity array-based LIFO stack recording every status
    change across every complaint, system-wide - most recent change on
    top. This is what would power an "Activity" feed on the Status
    page (Plan.pdf's Status nav item): peek/pop naturally surface the
    newest change first, exactly what that page wants to show.

    Stores StatusChangeRecord by VALUE, not by pointer, so there is no
    ownership question here at all - each push copies a small struct.
    ================================================================
*/

#include "Complaint.h"
#include <string>

struct StatusChangeRecord {
    int complaintId;
    ComplaintStatus status;
    std::string note;

    StatusChangeRecord() : complaintId(-1), status(ComplaintStatus::PENDING), note("") {}
    StatusChangeRecord(int id, ComplaintStatus s, std::string n)
        : complaintId(id), status(s), note(std::move(n)) {}
};

class StatusHistoryStack {
private:
    StatusChangeRecord* items;
    int capacity;
    int topIdx; // -1 means empty

public:
    explicit StatusHistoryStack(int capacity = 256);
    ~StatusHistoryStack();

    StatusHistoryStack(const StatusHistoryStack&) = delete;
    StatusHistoryStack& operator=(const StatusHistoryStack&) = delete;

    bool push(const StatusChangeRecord& record);
    bool pop(StatusChangeRecord& out);
    bool peek(StatusChangeRecord& out) const;

    bool isEmpty() const { return topIdx == -1; }
    bool isFull() const { return topIdx == capacity - 1; }
    int size() const { return topIdx + 1; }

    void displayRecent(int n) const; // most-recent-first, like an activity feed
};

#endif // DSA_STACK_H
