import * as THREE from 'three';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/controls/OrbitControls.js';
import { CSS2DObject, CSS2DRenderer } from 'https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/renderers/CSS2DRenderer.js';

(function () {
  'use strict';

  const host = document.getElementById('analysisLineChart');
  const metricSelect = document.getElementById('analysisMetricFilter');
  const viewSelect = document.getElementById('analysisViewPreset');
  const resetButton = document.getElementById('analysisViewReset');
  const legend = document.getElementById('analysisChartLegend');
  const tooltip = document.getElementById('analysis3dTooltip');
  if (!host) return;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#f5f8fc');
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 300);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.className = 'analysis-3d-canvas';
  renderer.domElement.setAttribute('aria-label', 'Interactive 3D bar comparison of complaints by state');

  const labelRenderer = new CSS2DRenderer();
  labelRenderer.domElement.className = 'analysis-3d-label-layer';
  labelRenderer.domElement.setAttribute('aria-hidden', 'true');

  function mountRenderer() {
    const loading = host.querySelector('.ranking-empty');
    if (loading) loading.remove();
    if (tooltip && tooltip.parentElement !== host) host.appendChild(tooltip);
    const anchor = tooltip && tooltip.parentElement === host ? tooltip : null;
    if (renderer.domElement.parentElement !== host) host.insertBefore(renderer.domElement, anchor);
    if (labelRenderer.domElement.parentElement !== host) host.insertBefore(labelRenderer.domElement, anchor);
  }

  scene.add(new THREE.HemisphereLight(0xffffff, 0xcbd5e1, 2.1));
  const keyLight = new THREE.DirectionalLight(0xffffff, 1.25);
  keyLight.position.set(-8, 18, 14);
  scene.add(keyLight);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.075;
  controls.enablePan = true;
  controls.minDistance = 11;
  controls.maxDistance = 72;
  controls.maxPolarAngle = Math.PI * 0.49;
  const target = new THREE.Vector3(0, 1.8, 0);
  controls.target.copy(target);

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const barGroup = new THREE.Group();
  scene.add(barGroup);
  let bars = [];
  let rows = [];
  let maxHeight = 7;
  let plotWidth = 8;
  let lastCompactMode = null;
  let frameId = 0;

  const metricLabels = {
    total_complaints: 'Total complaints',
    active_complaints: 'Active complaints',
    high: 'High severity',
    medium: 'Medium severity',
    low: 'Low severity',
    resolved_count: 'Resolved complaints',
  };
  const stateCodes = {
    'Andaman and Nicobar': 'AN', 'Andhra Pradesh': 'AP', 'Arunachal Pradesh': 'AR',
    'Dadra and Nagar Haveli': 'DNH', 'Daman and Diu': 'DD', 'Himachal Pradesh': 'HP',
    'Jammu and Kashmir': 'JK', 'Madhya Pradesh': 'MP', 'Maharashtra': 'MH',
    'Uttar Pradesh': 'UP', 'Uttarakhand': 'UK', 'West Bengal': 'WB',
  };

  function riskScore(row) {
    const high = Number(row.high || 0);
    const medium = Number(row.medium || 0);
    const low = Number(row.low || 0);
    const classified = high + medium + low;
    return classified ? (3 * high + 2 * medium + low) / (3 * classified) : null;
  }

  function riskColor(row) {
    const score = riskScore(row);
    if (score === null) return new THREE.Color('#b7bfd0');
    const low = new THREE.Color('#55c899');
    const medium = new THREE.Color('#f2bd56');
    const high = new THREE.Color('#ef626d');
    if (score <= 2 / 3) return low.lerp(medium, THREE.MathUtils.clamp((score - 1 / 3) * 3, 0, 1));
    return medium.lerp(high, THREE.MathUtils.clamp((score - 2 / 3) * 3, 0, 1));
  }

  function shortName(name) {
    if (stateCodes[name]) return stateCodes[name];
    const parts = name.split(/\s+/);
    return parts.length === 1 ? name.slice(0, 3).toUpperCase() : parts.map(part => part[0]).join('').slice(0, 3).toUpperCase();
  }

  function metricValue(row) {
    return Number(row[metricSelect.value] || 0);
  }

  function clearBars() {
    barGroup.traverse(object => {
      if (object.geometry) object.geometry.dispose();
      if (object.material) {
        if (Array.isArray(object.material)) object.material.forEach(material => material.dispose());
        else object.material.dispose();
      }
      if (object.element) object.element.remove();
    });
    scene.remove(barGroup);
    while (barGroup.children.length) barGroup.remove(barGroup.children[0]);
    bars = [];
    scene.add(barGroup);
  }

  function addScale(width, depth, maxValue) {
    const gridColor = new THREE.LineBasicMaterial({ color: 0xd8e0ea, transparent: true, opacity: 0.8 });
    const labelX = -width / 2 - 0.65;
    const backZ = -depth / 2;
    for (let tick = 0; tick <= 4; tick++) {
      const ratio = tick / 4;
      const y = maxHeight * ratio;
      const points = [new THREE.Vector3(-width / 2, y, backZ), new THREE.Vector3(width / 2, y, backZ)];
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      barGroup.add(new THREE.Line(geometry, gridColor));
      const element = document.createElement('span');
      element.className = 'analysis-axis-value';
      element.textContent = Math.round(maxValue * ratio).toLocaleString();
      barGroup.add(new CSS2DObject(element));
      barGroup.children[barGroup.children.length - 1].position.set(labelX, y, backZ);
    }
  }

  function renderBars() {
    clearBars();
    const sorted = rows.slice().sort((a, b) => metricValue(b) - metricValue(a) || a.name.localeCompare(b.name));
    const maxValue = Math.max(1, ...sorted.map(metricValue));
    const spacing = 0.86;
    const compact = host.clientWidth < 700;
    const columns = compact ? Math.min(12, sorted.length) : sorted.length;
    const rowCount = Math.ceil(sorted.length / Math.max(1, columns));
    const width = Math.max(8, columns * spacing);
    const depth = Math.max(7, rowCount * 1.8);
    plotWidth = width;

    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(width + 2, depth + 2),
      new THREE.MeshStandardMaterial({ color: '#edf2f8', roughness: 0.94 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, -0.08, 0);
    barGroup.add(floor);

    const grid = new THREE.GridHelper(width + 2, Math.max(10, sorted.length), 0xcbd5e1, 0xe4eaf1);
    grid.position.y = -0.045;
    grid.material.transparent = true;
    grid.material.opacity = 0.55;
    barGroup.add(grid);
    addScale(width, depth, maxValue);

    sorted.forEach((row, index) => {
      const value = metricValue(row);
      const height = maxHeight * value / maxValue;
      const barHeight = Math.max(0.035, height);
      const column = index % columns;
      const rowIndex = Math.floor(index / columns);
      const x = (column - (Math.min(columns, sorted.length) - 1) / 2) * spacing;
      const z = (rowIndex - (rowCount - 1) / 2) * 1.8;
      const geometry = new THREE.BoxGeometry(0.54, barHeight, 0.68);
      const material = new THREE.MeshStandardMaterial({ color: riskColor(row), roughness: 0.62, metalness: 0.03 });
      const bar = new THREE.Mesh(geometry, material);
      bar.position.set(x, barHeight / 2, z);
      bar.userData = { name: row.name, value, score: riskScore(row) };
      barGroup.add(bar);
      bars.push(bar);

      const label = document.createElement('span');
      label.className = 'analysis-state-label';
      label.textContent = shortName(row.name);
      label.title = row.name;
      const labelObject = new CSS2DObject(label);
      labelObject.position.set(x, 0.02, z + 0.57);
      barGroup.add(labelObject);
    });

    target.set(0, maxHeight * 0.22, 0);
    controls.target.copy(target);
    positionCamera(viewSelect.value || 'orbit', width);
    if (legend) {
      legend.innerHTML = '<span class="analysis-risk-caption">Severity mix</span><span class="analysis-risk-scale"><span>Lower</span><i></i><span>Higher</span></span><span class="analysis-risk-empty"><i></i>No classified complaints</span>';
    }
  }

  function positionCamera(view, width) {
    camera.up.set(0, 1, 0);
    const horizontalHalfFov = Math.atan(Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * Math.max(camera.aspect, 0.65));
    const distance = Math.max(14, width * 0.52 / Math.tan(horizontalHalfFov));
    if (view === 'top') {
      camera.up.set(0, 0, -1);
      camera.position.set(0, distance * 1.08, 0.01);
    } else if (view === 'front') {
      camera.position.set(0, maxHeight * 1.15, distance * 1.3);
    } else if (view === 'side') {
      camera.position.set(width * 0.32, maxHeight * 1.15, distance * 1.05);
    } else {
      camera.position.set(0, maxHeight * 1.65, distance * 1.05);
    }
    camera.lookAt(controls.target);
    controls.update();
  }

  function resize() {
    const width = host.clientWidth;
    const height = host.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    labelRenderer.setSize(width, height);
    const compact = width < 700;
    if (lastCompactMode === null) lastCompactMode = compact;
    else if (lastCompactMode !== compact) {
      lastCompactMode = compact;
      if (rows.length) renderBars();
    }
  }

  function showTooltip(event) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hit = raycaster.intersectObjects(bars, false)[0];
    if (!hit || !tooltip) {
      if (tooltip) tooltip.hidden = true;
      renderer.domElement.style.cursor = 'grab';
      return;
    }
    const data = hit.object.userData;
    const risk = data.score === null ? 'No classified complaints' : 'Severity mix ' + Math.round(data.score * 100) + '%';
    tooltip.textContent = data.name + ' · ' + metricLabels[metricSelect.value] + ': ' + data.value.toLocaleString() + ' · ' + risk;
    tooltip.hidden = false;
    const hostRect = host.getBoundingClientRect();
    tooltip.style.left = Math.min(event.clientX - hostRect.left + 12, hostRect.width - 290) + 'px';
    tooltip.style.top = Math.max(8, event.clientY - hostRect.top - 34) + 'px';
    renderer.domElement.style.cursor = 'pointer';
  }

  function animate() {
    frameId = window.requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
    labelRenderer.render(scene, camera);
  }

  metricSelect.addEventListener('change', renderBars);
  viewSelect.addEventListener('change', () => positionCamera(viewSelect.value, plotWidth));
  resetButton.addEventListener('click', () => {
    viewSelect.value = 'orbit';
    positionCamera('orbit', plotWidth);
  });
  renderer.domElement.addEventListener('pointermove', showTooltip);
  renderer.domElement.addEventListener('pointerleave', () => { if (tooltip) tooltip.hidden = true; });
  new ResizeObserver(resize).observe(host);
  resize();
  animate();

  window.UrbanInsightsStateBars = {
    render(nextRows) {
      rows = Array.isArray(nextRows) ? nextRows : [];
      mountRenderer();
      renderBars();
      resize();
    },
    dispose() {
      window.cancelAnimationFrame(frameId);
      controls.dispose();
      renderer.dispose();
    },
  };
})();
