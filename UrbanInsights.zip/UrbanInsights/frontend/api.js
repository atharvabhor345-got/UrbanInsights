/*
    ================================================================
    URBAN INSIGHTS -- frontend/api.js
    ================================================================
    Thin fetch wrapper around the endpoints in backend/server_main.cpp
    (see docs/API.md). Every page that wants live data goes through
    this instead of calling fetch() directly, so there's one place
    that knows the base URL and one error-handling convention.

    Every method resolves to `null` on any failure (network error,
    non-2xx response, server not running) rather than rejecting - the
    pages that call these are all written to fall back to their
    original static content when they get `null`, the same
    progressive-enhancement pattern opengl/webgl-india-map.js already
    uses for the Map page. The app should never look broken just
    because the backend happens to be off.
    ================================================================
*/
(function () {
  'use strict';

  async function getJson(path) {
    try {
      const res = await fetch(path);
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      return null;
    }
  }

  async function postJson(path, body) {
    try {
      const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => null);
      return { ok: res.ok, status: res.status, data };
    } catch (err) {
      return { ok: false, status: 0, data: null, networkError: true };
    }
  }

  window.UrbanInsightsAPI = {
    register: (payload) => postJson('/api/auth/register', payload),
    login: (payload) => postJson('/api/auth/login', payload),
    getCurrentUser: () => getJson('/api/auth/me'),
    logout: () => postJson('/api/auth/logout', {}),
    getHealth: () => getJson('/api/health'),
    suggestComplaintTriage: (payload) => postJson('/api/ai/triage', payload),
    getDashboardSummary: () => getJson('/api/dashboard/summary'),
    getDepartments: () => getJson('/api/departments'),
    getComplaints: (limit) => getJson('/api/complaints?limit=' + (limit || 50)),
    getComplaintById: (id) => getJson('/api/complaints/' + id),
    resolveComplaint: (id) => postJson('/api/complaints/' + id + '/resolve', {}),
    getStates: (category) => getJson('/api/states?category=' + encodeURIComponent(category || 'all')),
    getDistricts: (state, category) => getJson('/api/map/districts?state=' + encodeURIComponent(state) + '&category=' + encodeURIComponent(category || 'all')),
    getGeography: () => getJson('/api/geography'),
    getCityRankings: (page, pageSize, state, district, severity) => {
      const params = new URLSearchParams({ page: page || 1, pageSize: pageSize || 25 });
      if (state) params.set('state', state);
      if (district) params.set('district', district);
      if (severity) params.set('severity', severity);
      return getJson('/api/rankings/cities?' + params.toString());
    },
    createComplaint: (payload) => postJson('/api/complaints', payload),
  };
})();
