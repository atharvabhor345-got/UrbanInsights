/*
    ================================================================
    URBAN INSIGHTS -- frontend/live-data.js
    ================================================================
    Wires the Dashboard's stat cards, the Complaints page (state/city
    grouped records, summary cards, search + filters), and the Cities
    page's ranking to the real API (frontend/api.js). Each loader falls
    back to whatever static content already exists on the page if the
    server isn't reachable - nothing here can leave a page looking
    broken, only less current than it could be.

    Complaints/Cities load lazily (first visit to that tab), same
    pattern as frontend/map-init.js uses for the Map page, and both get
    marked stale after a new complaint is filed (see script.js's
    complaintForm submit handler) so they don't quietly drift out of
    sync with what was just reported.
    ================================================================
*/
(function () {
  'use strict';

  let complaintsLoaded = false;
  let citiesLoaded = false;
  let allComplaintsData = []; // full fetch, cached - filters operate on this in memory
  let controlsWired = false;
  let dashboardComplaints = [];
  let analysisLoaded = false;

  function invalidate() {
    complaintsLoaded = false;
    citiesLoaded = false;
    analysisLoaded = false;
  }

  function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  }

  function escapeHtml(s) {
    const div = document.createElement('div');
    div.textContent = s == null ? '' : String(s);
    return div.innerHTML;
  }

  function truncateText(s, max) {
    if (!s) return '';
    return s.length > max ? s.slice(0, max - 1).trim() + '\u2026' : s;
  }

  function formatDate(iso) {
    if (!iso) return '';
    // Postgres sends e.g. "2026-09-19 12:49:05.094739+00" - a space
    // instead of "T", and a bare +00 offset instead of "+00:00"/"Z".
    // Date() parses the first fine but is unreliable on the second, so
    // normalize both before handing it off.
    let normalized = iso.replace(' ', 'T');
    normalized = normalized.replace(/([+-]\d{2})$/, '$1:00');
    const d = new Date(normalized);
    if (isNaN(d.getTime())) return iso;
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
  }

  function categoryIcon(category) {
    const map = {
      traffic: { icon: 'fa-road', cls: 'road' },
      garbage: { icon: 'fa-trash', cls: 'garbage' },
      electricity: { icon: 'fa-bolt', cls: 'electricity' },
      water: { icon: 'fa-droplet', cls: 'water' },
    };
    return map[category] || { icon: 'fa-file', cls: '' };
  }

  // "Issue" column labels/icons for the Complaints page table
  // (frontend/index.html's issue-road/issue-water/issue-garbage/issue-electricity classes)
  function categoryIssueInfo(category) {
    const map = {
      traffic: { icon: 'fa-road', cls: 'issue-road', label: 'Road Issue' },
      garbage: { icon: 'fa-trash', cls: 'issue-garbage', label: 'Garbage Issue' },
      electricity: { icon: 'fa-bolt', cls: 'issue-electricity', label: 'Electricity Issue' },
      water: { icon: 'fa-droplet', cls: 'issue-water', label: 'Water Issue' },
    };
    return map[category] || { icon: 'fa-file', cls: '', label: capitalize(category) };
  }

  // DB statuses (pending/assigned/in_progress/resolved) -> the three
  // status classes style.css actually defines, in each page's own vocabulary.
  function statusClassAndLabel(status) {
    if (status === 'resolved') return { cls: 'resolved', label: 'Resolved' };
    if (status === 'pending') return { cls: 'pending', label: 'Pending' };
    return { cls: 'processing', label: 'In Progress' }; // assigned | in_progress
  }

  function complaintStatusInfo(status) {
    if (status === 'resolved') return { cls: 'resolved', label: 'Resolved' };
    if (status === 'pending') return { cls: 'open', label: 'Open' };
    return { cls: 'progress', label: 'In Progress' }; // assigned | in_progress
  }

  function isAdminSession() {
    const role = window.UrbanInsightsCurrentUser && window.UrbanInsightsCurrentUser.role;
    return role === 'admin' || role === 'super_admin';
  }

  function severityInfo(sev) {
    if (sev === 'high' || sev === 'medium' || sev === 'low') return { cls: sev, label: capitalize(sev) };
    return { cls: 'low', label: 'Unrated' }; // 'unset' fallback
  }

  // ---- Dashboard stat cards ----
  function categoryLabel(category) {
    return ({ traffic: 'Road', water: 'Water', garbage: 'Garbage', electricity: 'Electricity' })[category] || capitalize(category);
  }

  function renderDashboardCategoryChart(list, selectedCity) {
    const bars = document.getElementById('dashboardCategoryBars');
    const yAxis = document.getElementById('dashboardChartYAxis');
    if (!bars || !yAxis) return;

    const filtered = selectedCity && selectedCity !== 'all'
      ? list.filter(c => String(c.city || '').toLowerCase() === String(selectedCity).toLowerCase())
      : list;
    const categories = [
      { key: 'traffic', cls: 'road' },
      { key: 'water', cls: 'water' },
      { key: 'garbage', cls: 'garbage' },
      { key: 'electricity', cls: 'electricity' }
    ];
    const counts = categories.map(x => filtered.filter(c => c.category === x.key).length);
    const max = Math.max(1, ...counts);
    yAxis.innerHTML = [1, .75, .5, .25, 0].map(v => '<span>' + Math.round(max * v) + '</span>').join('');

    if (!filtered.length) {
      bars.innerHTML = '<div class="ranking-empty">No live complaint data is available for this city.</div>';
      return;
    }

    bars.innerHTML = categories.map((cat, i) => {
      const height = counts[i] ? Math.max(4, Math.round((counts[i] / max) * 100)) : 0;
      return '<div class="bar-group">' +
        '<div class="bar ' + cat.cls + '" style="height:' + height + '%" title="' + categoryLabel(cat.key) + ': ' + counts[i] + '"></div>' +
        '<span>' + categoryLabel(cat.key) + '</span>' +
        '</div>';
    }).join('');
  }

  async function refreshDashboardStats() {
    const summary = await UrbanInsightsAPI.getDashboardSummary();
    const totalEl = document.getElementById('totalComplaints');
    const resolvedEl = document.getElementById('resolvedComplaints');
    const highEl = document.getElementById('highSeverityCount');
    const rateEl = document.getElementById('resolutionRate');
    const resolvedBar = document.getElementById('resolvedProgressBar');
    const rateBar = document.getElementById('resolutionProgressBar');

    if (!summary || summary.error) {
      [totalEl, resolvedEl, highEl, rateEl].forEach(el => { if (el) el.textContent = '—'; });
      if (resolvedBar) resolvedBar.style.width = '0%';
      if (rateBar) rateBar.style.width = '0%';
    } else {
      const total = Number(summary.total ?? summary.total_complaints ?? 0);
      const resolved = Number(summary.resolved ?? summary.resolved_count ?? 0);
      const highSeverity = Number(summary.highSeverity ?? summary.high_severity_count ?? 0);
      const rate = total > 0 ? Math.round((resolved / total) * 100) : 0;
      if (totalEl) totalEl.textContent = total;
      if (resolvedEl) resolvedEl.textContent = resolved;
      if (highEl) highEl.textContent = highSeverity;
      if (rateEl) rateEl.textContent = rate + '%';
      if (resolvedBar) resolvedBar.style.width = Math.min(100, rate) + '%';
      if (rateBar) rateBar.style.width = Math.min(100, rate) + '%';
    }

    const complaints = await UrbanInsightsAPI.getComplaints(5000);
    dashboardComplaints = Array.isArray(complaints) ? complaints : [];

    // Live severity distribution. No demo numbers are kept in the HTML.
    const severityCounts = { high: 0, medium: 0, low: 0 };
    dashboardComplaints.forEach(c => { if (Object.prototype.hasOwnProperty.call(severityCounts, c.severity)) severityCounts[c.severity]++; });
    const severityTotal = dashboardComplaints.length;
    const severityTotalEl = document.getElementById('severityTotal');
    const severityHighEl = document.getElementById('severityHigh');
    const severityMediumEl = document.getElementById('severityMedium');
    const severityLowEl = document.getElementById('severityLow');
    const severityDonut = document.getElementById('severityDonut');
    if (severityTotalEl) severityTotalEl.textContent = severityTotal;
    if (severityHighEl) severityHighEl.textContent = severityCounts.high;
    if (severityMediumEl) severityMediumEl.textContent = severityCounts.medium;
    if (severityLowEl) severityLowEl.textContent = severityCounts.low;
    if (severityDonut) {
      const highDeg = severityTotal ? severityCounts.high / severityTotal * 360 : 0;
      const medDeg = severityTotal ? severityCounts.medium / severityTotal * 360 : 0;
      const medEnd = highDeg + medDeg;
      severityDonut.style.background = severityTotal
        ? 'conic-gradient(#ef626d 0deg ' + highDeg + 'deg, #f2bd56 ' + highDeg + 'deg ' + medEnd + 'deg, #55c899 ' + medEnd + 'deg 360deg)'
        : 'conic-gradient(#dbe2ea 0deg 360deg)';
    }

    const recentList = document.getElementById('complaintList');
    if (recentList) {
      if (!dashboardComplaints.length) {
        recentList.innerHTML = '<div class="ranking-empty">No live complaints have been reported yet.</div>';
      } else {
        recentList.innerHTML = dashboardComplaints.slice(0, 4).map(c => {
          const info = categoryIcon(c.category);
          const status = complaintStatusInfo(c.status);
          return '<div class="complaint-item">' +
            '<div class="complaint-icon ' + info.cls + '"><i class="fa-solid ' + info.icon + '"></i></div>' +
            '<div class="complaint-details"><strong>' + escapeHtml(truncateText(c.description || categoryLabel(c.category), 42)) + '</strong>' +
            '<span>' + escapeHtml(c.locality ? c.locality + ', ' + c.city : c.city) + ' · ' + escapeHtml(formatDate(c.reportedAt || c.reported_at)) + '</span></div>' +
            '<span class="status ' + status.cls + '">' + status.label + '</span>' +
            '</div>';
        }).join('');
      }
    }

    const cityFilter = document.getElementById('cityFilter');
    if (cityFilter && dashboardComplaints.length) {
      const cities = Array.from(new Set(dashboardComplaints.map(c => c.city).filter(Boolean))).sort();
      const current = cityFilter.value || 'all';
      cityFilter.innerHTML = '<option value="all">All Cities</option>' +
        cities.map(city => '<option value="' + escapeHtml(city) + '">' + escapeHtml(city) + '</option>').join('');
      if (cities.indexOf(current) !== -1) cityFilter.value = current;
    }
    renderDashboardCategoryChart(dashboardComplaints, cityFilter ? cityFilter.value : 'all');
  }

  function renderAnalysisLineChart(states) {
    const container = document.getElementById('analysisLineChart');
    const legend = document.getElementById('analysisChartLegend');
    if (!container || !legend) return;
    if (!Array.isArray(states) || !states.length) {
      container.innerHTML = '<div class="ranking-empty">No state complaint data is available for analysis.</div>';
      legend.innerHTML = '';
      return;
    }
    if (!window.UrbanInsightsStateBars) {
      container.innerHTML = '<div class="ranking-empty">The 3D chart could not be loaded. Check your internet connection and reload.</div>';
      legend.innerHTML = '';
      return;
    }
    window.UrbanInsightsStateBars.render(states);
  }

  async function loadAnalysisPage(force) {
    if (analysisLoaded && !force) return;
    const container = document.getElementById('analysisLineChart');
    if (!container) return;
    container.innerHTML = '<div class="ranking-empty">Loading state comparison…</div>';
    const states = await UrbanInsightsAPI.getStates('all');
    if (!Array.isArray(states)) {
      container.innerHTML = '<div class="ranking-empty">Unable to load state analysis. Please check the backend and database.</div>';
      const legend = document.getElementById('analysisChartLegend'); if (legend) legend.innerHTML = '';
      return;
    }
    analysisLoaded = true;
    renderAnalysisLineChart(states);
  }

  // ---- Complaints page ----
  function updateComplaintsSummary(list) {
    // Deliberately summarises the FULL fetched set, not the filtered
    // view below it - these four cards are the "big picture" headline,
    // matching the "Across all cities" subtitle under Total.
    const total = list.length;
    const open = list.filter((c) => c.status === 'pending').length;
    const progress = list.filter((c) => c.status === 'assigned' || c.status === 'in_progress').length;
    const resolved = list.filter((c) => c.status === 'resolved').length;

    const totalEl = document.getElementById('complaintsTotalCount');
    const openEl = document.getElementById('complaintsOpenCount');
    const progressEl = document.getElementById('complaintsProcessingCount');
    const resolvedEl = document.getElementById('complaintsResolvedCount');
    if (totalEl) totalEl.textContent = total;
    if (openEl) openEl.textContent = open;
    if (progressEl) progressEl.textContent = progress;
    if (resolvedEl) resolvedEl.textContent = resolved;
  }

  function populateFilterOptions(list) {
    const stateSel = document.getElementById('complaintStateFilter');
    const citySel = document.getElementById('complaintCityFilter');
    if (!stateSel || !citySel) return;

    const states = Array.from(new Set(list.map((c) => c.state).filter(Boolean))).sort();
    const cities = Array.from(new Set(list.map((c) => c.city).filter(Boolean))).sort();
    const currentState = stateSel.value, currentCity = citySel.value;

    stateSel.innerHTML = '<option value="all">All States</option>' +
      states.map((s) => '<option value="' + escapeHtml(s) + '">' + escapeHtml(s) + '</option>').join('');
    citySel.innerHTML = '<option value="all">All Cities</option>' +
      cities.map((c) => '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>').join('');

    if (states.indexOf(currentState) !== -1) stateSel.value = currentState;
    if (cities.indexOf(currentCity) !== -1) citySel.value = currentCity;
  }

  function groupComplaints(list) {
    const byState = new Map();
    list.forEach((c) => {
      const state = c.state || 'Unspecified';
      const city = c.city || 'Unspecified';
      if (!byState.has(state)) byState.set(state, new Map());
      const cities = byState.get(state);
      if (!cities.has(city)) cities.set(city, []);
      cities.get(city).push(c);
    });
    return byState;
  }

  function buildComplaintRow(c) {
    const issue = categoryIssueInfo(c.category);
    const sev = severityInfo(c.severity);
    const st = complaintStatusInfo(c.status);
    const tr = document.createElement('tr');
    tr.innerHTML =
      '<td><b class="complaint-code">' + escapeHtml(c.referenceCode || ('#' + c.id)) + '</b></td>' +
      '<td><span class="issue-name"><i class="fa-solid ' + issue.icon + ' ' + issue.cls + '"></i> ' +
        escapeHtml(truncateText(c.description, 34)) + '</span></td>' +
      '<td>' + escapeHtml(c.locality ? c.locality + ', ' + c.city : c.city) + '</td>' +
      '<td>' + escapeHtml(c.citizenName || 'Anonymous') + '</td>' +
      '<td><span class="severity ' + sev.cls + '">' + sev.label + '</span></td>' +
      '<td><span class="complaint-status ' + st.cls + '">' + st.label + '</span></td>' +
      '<td>' + escapeHtml(formatDate(c.reportedAt)) + '</td>';
    if (isAdminSession()) {
      const actionCell = document.createElement('td');
      if (c.status === 'resolved') {
        actionCell.textContent = 'Resolved';
      } else {
        const button = document.createElement('button');
        button.className = 'resolve-complaint-button';
        button.type = 'button';
        button.textContent = 'Mark resolved';
        button.addEventListener('click', () => resolveComplaint(c.id, button));
        actionCell.appendChild(button);
      }
      tr.appendChild(actionCell);
    }
    return tr;
  }

  async function resolveComplaint(id, button) {
    button.disabled = true;
    button.textContent = 'Saving...';
    const result = await UrbanInsightsAPI.resolveComplaint(id);
    if (!result || !result.ok) {
      button.disabled = false;
      button.textContent = 'Retry';
      button.title = result && result.data && result.data.error ? result.data.error : 'Could not update complaint status';
      return;
    }
    await Promise.all([loadComplaintsPage(true), refreshDashboardStats()]);
  }

  function renderComplaintsRecords(list) {
    const card = document.querySelector('#complaintsPage .complaint-records-card');
    if (!card) return;
    const footer = card.querySelector('.complaint-records-footer');

    card.querySelectorAll('.state-block, .complaints-empty-note').forEach((el) => el.remove());

    if (!list.length) {
      const empty = document.createElement('p');
      empty.className = 'complaints-empty-note';
      empty.style.padding = '20px';
      empty.style.color = 'var(--muted)';
      empty.style.fontSize = '12px';
      empty.textContent = 'No complaints match these filters.';
      if (footer) card.insertBefore(empty, footer); else card.appendChild(empty);
      return;
    }

    const grouped = groupComplaints(list);
    const stateEntries = Array.from(grouped.entries()).sort((a, b) => {
      const totalA = Array.from(a[1].values()).reduce((s, arr) => s + arr.length, 0);
      const totalB = Array.from(b[1].values()).reduce((s, arr) => s + arr.length, 0);
      return totalB - totalA;
    });

    stateEntries.forEach(([stateName, cities]) => {
      const stateTotal = Array.from(cities.values()).reduce((s, arr) => s + arr.length, 0);

      const stateBlock = document.createElement('div');
      stateBlock.className = 'state-block';

      const header = document.createElement('div');
      header.className = 'state-block-header';
      header.innerHTML =
        '<div class="state-heading">' +
          '<div class="state-heading-icon"><i class="fa-solid fa-location-dot"></i></div>' +
          '<div><h3>' + escapeHtml(stateName) + '</h3><span>' + stateTotal +
            ' complaint' + (stateTotal === 1 ? '' : 's') + '</span></div>' +
        '</div>' +
        '<button class="state-collapse" type="button"><i class="fa-solid fa-chevron-up"></i></button>';
      stateBlock.appendChild(header);

      const cityEntries = Array.from(cities.entries()).sort((a, b) => b[1].length - a[1].length);
      cityEntries.forEach(([cityName, complaints]) => {
        const cityBlock = document.createElement('div');
        cityBlock.className = 'city-block';
        const letter = cityName.charAt(0).toUpperCase();
        cityBlock.innerHTML =
          '<div class="city-block-header">' +
            '<div class="city-heading"><div class="city-letter">' + escapeHtml(letter) + '</div>' +
              '<div><strong>' + escapeHtml(cityName) + '</strong><span>' + complaints.length +
              ' complaint' + (complaints.length === 1 ? '' : 's') + '</span></div></div>' +
            '<span class="city-count">' + complaints.length + '</span>' +
          '</div>' +
          '<div class="complaints-table-wrap">' +
            '<table class="complaints-table">' +
              '<thead><tr><th>ID</th><th>Issue</th><th>Location</th><th>Citizen</th>' +
              '<th>Severity</th><th>Status</th><th>Date</th>' + (isAdminSession() ? '<th>Action</th>' : '') + '</tr></thead>' +
              '<tbody></tbody>' +
            '</table>' +
          '</div>';
        const tbody = cityBlock.querySelector('tbody');
        complaints.forEach((c) => tbody.appendChild(buildComplaintRow(c)));
        stateBlock.appendChild(cityBlock);
      });

      if (footer) card.insertBefore(stateBlock, footer); else card.appendChild(stateBlock);
    });

    card.querySelectorAll('.state-collapse').forEach((btn) => {
      btn.addEventListener('click', function () {
        const block = btn.closest('.state-block');
        const collapsed = block.classList.toggle('is-collapsed');
        const icon = btn.querySelector('i');
        if (icon) icon.className = 'fa-solid ' + (collapsed ? 'fa-chevron-down' : 'fa-chevron-up');
        block.querySelectorAll('.city-block').forEach((cb) => { cb.style.display = collapsed ? 'none' : ''; });
      });
    });
  }

  function applyComplaintFilters() {
    const searchEl = document.getElementById('complaintSearch');
    const stateSel = document.getElementById('complaintStateFilter');
    const citySel = document.getElementById('complaintCityFilter');
    const typeSel = document.getElementById('complaintTypeFilter');
    const sevSel = document.getElementById('complaintSeverityFilter');

    const query = ((searchEl && searchEl.value) || '').trim().toLowerCase();
    const stateVal = stateSel ? stateSel.value : 'all';
    const cityVal = citySel ? citySel.value : 'all';
    const typeVal = typeSel ? typeSel.value : 'all';
    const sevVal = sevSel ? sevSel.value : 'all';
    const typeToCategory = { Road: 'traffic', Water: 'water', Garbage: 'garbage', Electricity: 'electricity' };

    const filtered = allComplaintsData.filter((c) => {
      if (stateVal !== 'all' && c.state !== stateVal) return false;
      if (cityVal !== 'all' && c.city !== cityVal) return false;
      if (typeVal !== 'all' && c.category !== typeToCategory[typeVal]) return false;
      if (sevVal !== 'all' && c.severity !== sevVal.toLowerCase()) return false;
      if (query) {
        const haystack = [c.referenceCode, c.citizenName, c.locality, c.city, c.description]
          .filter(Boolean).join(' ').toLowerCase();
        if (haystack.indexOf(query) === -1) return false;
      }
      return true;
    });

    renderComplaintsRecords(filtered);
  }

  function wireComplaintsControlsOnce() {
    if (controlsWired) return;
    controlsWired = true;

    const searchEl = document.getElementById('complaintSearch');
    const stateSel = document.getElementById('complaintStateFilter');
    const citySel = document.getElementById('complaintCityFilter');
    const typeSel = document.getElementById('complaintTypeFilter');
    const sevSel = document.getElementById('complaintSeverityFilter');
    const resetBtn = document.getElementById('clearComplaintFilters');

    if (searchEl) searchEl.addEventListener('input', applyComplaintFilters);
    [stateSel, citySel, typeSel, sevSel].forEach((el) => {
      if (el) el.addEventListener('change', applyComplaintFilters);
    });
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        if (searchEl) searchEl.value = '';
        if (stateSel) stateSel.value = 'all';
        if (citySel) citySel.value = 'all';
        if (typeSel) typeSel.value = 'all';
        if (sevSel) sevSel.value = 'all';
        renderComplaintsRecords(allComplaintsData);
      });
    }
  }

  async function loadComplaintsPage(force) {
    if (complaintsLoaded && !force) return;
    const card = document.querySelector('#complaintsPage .complaint-records-card');
    if (!card) return;

    const list = card.querySelector('#complaintList');
    if (list) list.innerHTML = '<div class="ranking-empty">Loading complaints…</div>';
    const complaints = await UrbanInsightsAPI.getComplaints(5000);
    if (!complaints) { if (list) list.innerHTML = '<div class="ranking-empty">Unable to load complaints. Please start the backend and try again.</div>'; return; }
    if (!complaints.length) { if (list) list.innerHTML = '<div class="ranking-empty">No complaints have been reported yet.</div>'; return; }

    complaintsLoaded = true;
    allComplaintsData = complaints;
    updateComplaintsSummary(complaints);
    populateFilterOptions(complaints);
    renderComplaintsRecords(complaints);
    wireComplaintsControlsOnce();
  }

  async function loadDashboardCityRanking() {
    const card = document.querySelector('#dashboardPage .ranking-card .ranking-list');
    if (!card) return;
    const response = await UrbanInsightsAPI.getCityRankings(1, 5);
    if (!response || response.error) {
      card.innerHTML = '<div class="ranking-empty">Unable to load live city ranking.</div>';
      return;
    }
    const rankings = response.items || [];
    if (!rankings.length) {
      card.innerHTML = '<div class="ranking-empty">No city ranking data is available.</div>';
      return;
    }
    card.innerHTML = rankings.map(r =>
      '<div class="ranking-item' + (r.rank === 1 ? ' first' : '') + '">' +
        '<div class="rank">' + String(r.rank).padStart(2, '0') + '</div>' +
        '<div class="city-avatar">' + escapeHtml((r.city || '?').charAt(0)) + '</div>' +
        '<div class="city-info"><strong>' + escapeHtml(r.city) + '</strong><span>' + escapeHtml(r.district) + ' · ' + escapeHtml(r.state) + '</span></div>' +
        '<div class="rank-score" title="Total complaints">' + Number(r.totalComplaints || 0) + '</div>' +
      '</div>'
    ).join('');
  }


    // ---- Departments page ----
  let departmentsLoaded = false;

  async function loadDepartmentsPage(force) {
    if (departmentsLoaded && !force) return;

    const container = document.getElementById('departmentsList');
    if (!container) return;

    container.innerHTML =
      '<div class="complaint-item">' +
        '<div class="complaint-details">' +
          '<strong>Loading departments...</strong>' +
          '<span>Fetching live department data.</span>' +
        '</div>' +
      '</div>';

    const departments = await UrbanInsightsAPI.getDepartments();

    if (!Array.isArray(departments)) {
      container.innerHTML =
        '<div class="complaint-item">' +
          '<div class="complaint-details">' +
            '<strong>Unable to load departments</strong>' +
            '<span>Please check the backend and database connection.</span>' +
          '</div>' +
        '</div>';
      return;
    }

    if (!departments.length) {
      container.innerHTML =
        '<div class="complaint-item">' +
          '<div class="complaint-details">' +
            '<strong>No departments found</strong>' +
            '<span>No department records are currently available.</span>' +
          '</div>' +
        '</div>';
      return;
    }

    departmentsLoaded = true;

    const icons = {
      traffic: { icon: 'fa-road', cls: 'road' },
      water: { icon: 'fa-droplet', cls: 'water' },
      garbage: { icon: 'fa-trash', cls: 'garbage' },
      electricity: { icon: 'fa-bolt', cls: 'electricity' }
    };

    container.innerHTML = departments.map(function (department) {

      const category = String(department.category || '').toLowerCase();
      const info = icons[category] || {
        icon: 'fa-building',
        cls: ''
      };

      return (
        '<div class="complaint-item">' +

          '<div class="complaint-icon ' + info.cls + '">' +
            '<i class="fa-solid ' + info.icon + '"></i>' +
          '</div>' +

          '<div class="complaint-details">' +

            '<strong>' +
              escapeHtml(department.name) +
            '</strong>' +

            '<span>' +
              escapeHtml(capitalize(category)) +
              ' · ' +
              Number(department.staffCount || 0) +
              ' staff members' +
            '</span>' +

          '</div>' +

        '</div>'
      );

    }).join('');
  }



// ---- Reports page ----
let reportsLoaded = false;

async function loadReportsPage(force) {
  if (reportsLoaded && !force) return;

  const container = document.getElementById('reportsList');
  if (!container) return;

  container.innerHTML =
    '<div class="complaint-item">' +
      '<div class="complaint-details">' +
        '<strong>Loading reports...</strong>' +
        '<span>Fetching live complaint data.</span>' +
      '</div>' +
    '</div>';

  const complaints = await UrbanInsightsAPI.getComplaints(5000);

  if (!Array.isArray(complaints)) {
    container.innerHTML =
      '<div class="complaint-item">' +
        '<div class="complaint-details">' +
          '<strong>Unable to load reports</strong>' +
          '<span>Please check the backend and database connection.</span>' +
        '</div>' +
      '</div>';
    return;
  }

  if (!complaints.length) {
    container.innerHTML =
      '<div class="complaint-item">' +
        '<div class="complaint-details">' +
          '<strong>No complaint data available</strong>' +
          '<span>There are currently no complaints to include in reports.</span>' +
        '</div>' +
      '</div>';
    return;
  }

  reportsLoaded = true;

  // -----------------------------
  // City report
  // -----------------------------
  const cityCounts = {};

  complaints.forEach(function (complaint) {
    const city = complaint.city || 'Unknown';

    if (!cityCounts[city]) {
      cityCounts[city] = 0;
    }

    cityCounts[city]++;
  });

  const cityReport = Object.entries(cityCounts)
    .sort(function (a, b) {
      return b[1] - a[1];
    })
    .slice(0, 10)
    .map(function (entry) {
      return entry[0] + ' — ' + entry[1] + ' complaint' +
        (entry[1] === 1 ? '' : 's');
    })
    .join(', ');

  // -----------------------------
  // Severity report
  // -----------------------------
  const severityCounts = {
    high: 0,
    medium: 0,
    low: 0,
    none: 0
  };

  complaints.forEach(function (complaint) {
    const severity = String(
      complaint.severity || 'none'
    ).toLowerCase();

    if (Object.prototype.hasOwnProperty.call(severityCounts, severity)) {
      severityCounts[severity]++;
    }
  });

  const severityReport =
    'High: ' + severityCounts.high +
    ' · Medium: ' + severityCounts.medium +
    ' · Low: ' + severityCounts.low;

  container.innerHTML =
    '<div class="complaint-item">' +

      '<div class="complaint-icon road">' +
        '<i class="fa-solid fa-file-lines"></i>' +
      '</div>' +

      '<div class="complaint-details">' +

        '<strong>' +
          'City Complaint Report' +
        '</strong>' +

        '<span>' +
          escapeHtml(cityReport) +
        '</span>' +

      '</div>' +

      '<span class="status-badge">' +
        complaints.length + ' total' +
      '</span>' +

    '</div>' +

    '<div class="complaint-item">' +

      '<div class="complaint-icon water">' +
        '<i class="fa-solid fa-chart-column"></i>' +
      '</div>' +

      '<div class="complaint-details">' +

        '<strong>' +
          'Severity Report' +
        '</strong>' +

        '<span>' +
          escapeHtml(severityReport) +
        '</span>' +

      '</div>' +

    '</div>';
}




  // ---- Notifications page ----
let notificationsLoaded = false;

async function loadNotificationsPage(force) {
  if (notificationsLoaded && !force) return;

  const container = document.getElementById('notificationsList');
  if (!container) return;

  container.innerHTML =
    '<div class="notification-item">' +
      '<div>' +
        '<strong>Loading notifications...</strong>' +
        '<p>Fetching live complaint updates.</p>' +
      '</div>' +
    '</div>';

  const complaints = await UrbanInsightsAPI.getComplaints(50);

  if (!Array.isArray(complaints)) {
    container.innerHTML =
      '<div class="notification-item">' +
        '<div>' +
          '<strong>Unable to load notifications</strong>' +
          '<p>Please check the backend and database connection.</p>' +
        '</div>' +
      '</div>';
    return;
  }

  if (!complaints.length) {
    container.innerHTML =
      '<div class="notification-item">' +
        '<div>' +
          '<strong>No notifications</strong>' +
          '<p>There are currently no complaint updates.</p>' +
        '</div>' +
      '</div>';
    return;
  }

  notificationsLoaded = true;

  const recentComplaints = complaints.slice(0, 10);

  container.innerHTML = recentComplaints.map(function (complaint) {

    const severity = String(
      complaint.severity || 'low'
    ).toLowerCase();

    const status = String(
      complaint.status || 'active'
    ).toLowerCase();

    const city = complaint.city || 'Unknown city';
    const category = categoryLabel(
      String(complaint.category || 'complaint')
    );

    let title;
    let message;
    let icon;
    let notificationClass = '';

    if (status === 'resolved') {

      title = 'Complaint resolved';
      message =
        category + ' complaint has been resolved in ' +
        city + '.';
      icon = 'fa-check';

    } else if (severity === 'high') {

      title = 'High severity complaint';
      message =
        category + ' issue reported in ' +
        city + '.';
      icon = 'fa-triangle-exclamation';
      notificationClass = 'high';

    } else {

      title = 'New complaint reported';
      message =
        category + ' complaint reported in ' +
        city + '.';
      icon = 'fa-bell';

    }

    return (
      '<div class="notification-item">' +

        '<div class="notification-icon ' +
          notificationClass +
        '">' +

          '<i class="fa-solid ' +
            icon +
          '"></i>' +

        '</div>' +

        '<div>' +

          '<strong>' +
            escapeHtml(title) +
          '</strong>' +

          '<p>' +
            escapeHtml(message) +
          '</p>' +

          '<small>' +
            escapeHtml(formatDate(complaint.reportedAt)) +
          '</small>' +

        '</div>' +

      '</div>'
    );

  }).join('');
}

async function loadNotificationPanel() {
  const container =
    document.getElementById('notificationPanelList');

  const countElement =
    document.getElementById('notificationCount');

  if (!container) return;

  container.innerHTML =
    '<div class="notification-item">' +
      '<div class="notification-icon">' +
        '<i class="fa-solid fa-spinner fa-spin"></i>' +
      '</div>' +
      '<div>' +
        '<strong>Loading notifications...</strong>' +
        '<p>Fetching live complaint updates.</p>' +
        '<small>Please wait</small>' +
      '</div>' +
    '</div>';

  const complaints =
    await UrbanInsightsAPI.getComplaints(50);

  if (!Array.isArray(complaints)) {

    if (countElement) {
      countElement.textContent = 'Unavailable';
    }

    container.innerHTML =
      '<div class="notification-item">' +
        '<div class="notification-icon high">' +
          '<i class="fa-solid fa-triangle-exclamation"></i>' +
        '</div>' +
        '<div>' +
          '<strong>Unable to load notifications</strong>' +
          '<p>Could not connect to the complaint service.</p>' +
          '<small>Check the backend connection</small>' +
        '</div>' +
      '</div>';

    return;
  }


  /*
   * =========================================================
   * REMEMBER WHICH COMPLAINTS THE USER HAS ALREADY SEEN
   * =========================================================
   */

  const seenKey =
    'urbanInsightsSeenNotificationIds';

  let seenIds = [];

  try {
    seenIds =
      JSON.parse(
        localStorage.getItem(seenKey) || '[]'
      );

    if (!Array.isArray(seenIds)) {
      seenIds = [];
    }

  } catch (error) {
    seenIds = [];
  }


  const seenIdSet =
    new Set(
      seenIds.map(function (id) {
        return String(id);
      })
    );


  /*
   * =========================================================
   * FIND UNSEEN COMPLAINTS
   * =========================================================
   */

  const unseenComplaints =
    complaints.filter(function (complaint) {

      return (
        complaint.id !== undefined &&
        complaint.id !== null &&
        !seenIdSet.has(String(complaint.id))
      );

    });


  /*
   * =========================================================
   * UPDATE BADGE
   * =========================================================
   */

  if (countElement) {

    if (unseenComplaints.length > 0) {

      countElement.textContent =
        unseenComplaints.length +
        (
          unseenComplaints.length === 1
            ? ' new update'
            : ' new updates'
        );

    } else {

      countElement.textContent =
        'No new updates';

    }
  }


  /*
   * =========================================================
   * NO COMPLAINTS
   * =========================================================
   */

  if (!complaints.length) {

    container.innerHTML =
      '<div class="notification-item">' +
        '<div class="notification-icon">' +
          '<i class="fa-solid fa-circle-info"></i>' +
        '</div>' +
        '<div>' +
          '<strong>No notifications</strong>' +
          '<p>There are currently no complaint updates.</p>' +
          '<small>Nothing new</small>' +
        '</div>' +
      '</div>';

    return;
  }


  /*
   * =========================================================
   * DISPLAY LATEST 5 COMPLAINTS
   * =========================================================
   */

  const recentComplaints =
    complaints.slice(0, 5);


  container.innerHTML =
    recentComplaints.map(function (complaint) {

      const severity =
        String(
          complaint.severity || 'low'
        ).toLowerCase();

      const status =
        String(
          complaint.status || 'active'
        ).toLowerCase();

      const city =
        complaint.city || 'Unknown city';

      const category =
        categoryLabel(
          String(
            complaint.category || 'complaint'
          )
        );

      let title;
      let message;
      let icon;
      let notificationClass = '';

      if (status === 'resolved') {

        title = 'Complaint resolved';

        message =
          category +
          ' complaint has been resolved in ' +
          city +
          '.';

        icon = 'fa-check';

      } else if (severity === 'high') {

        title = 'High severity complaint';

        message =
          category +
          ' issue reported in ' +
          city +
          '.';

        icon =
          'fa-triangle-exclamation';

        notificationClass = 'high';

      } else {

        title =
          'New complaint reported';

        message =
          category +
          ' complaint reported in ' +
          city +
          '.';

        icon = 'fa-bell';
      }


      return (
        '<div class="notification-item">' +

          '<div class="notification-icon ' +
            notificationClass +
          '">' +

            '<i class="fa-solid ' +
              icon +
            '"></i>' +

          '</div>' +

          '<div>' +

            '<strong>' +
              escapeHtml(title) +
            '</strong>' +

            '<p>' +
              escapeHtml(message) +
            '</p>' +

            '<small>' +
              escapeHtml(
                formatDate(
                  complaint.reportedAt
                )
              ) +
            '</small>' +

          '</div>' +

        '</div>'
      );

    }).join('');
}

  let settingsLoaded = false;

async function loadSettingsPage(force) {
  if (settingsLoaded && !force) return;

  const statusList = document.getElementById('settingsStatusList');
  const liveDataStatus =
    document.getElementById('settingsLiveDataStatus');
  const databaseStatus =
    document.getElementById('settingsDatabaseStatus');

  if (!statusList) return;

  statusList.innerHTML =
    '<div class="complaint-item">' +
      '<div class="complaint-details">' +
        '<strong>Checking backend status...</strong>' +
        '<span>Connecting to Urban Insights server.</span>' +
      '</div>' +
      '<span class="status">Checking</span>' +
    '</div>';

  const health = await UrbanInsightsAPI.getHealth();

  if (!health || health.status !== 'ok') {

    statusList.innerHTML =
      '<div class="complaint-item">' +
        '<div class="complaint-details">' +
          '<strong>Backend unavailable</strong>' +
          '<span>Urban Insights server could not be reached.</span>' +
        '</div>' +
        '<span class="status high">Offline</span>' +
      '</div>';

    if (liveDataStatus) {
      liveDataStatus.textContent = 'Unavailable';
      liveDataStatus.className = 'status high';
    }

    if (databaseStatus) {
      databaseStatus.textContent = 'Unavailable';
      databaseStatus.className = 'status high';
    }

    return;
  }

  const databaseOnline = health.database === true;

  statusList.innerHTML =
    '<div class="complaint-item">' +
      '<div class="complaint-details">' +
        '<strong>Backend API</strong>' +
        '<span>Urban Insights server is responding normally.</span>' +
      '</div>' +
      '<span class="status resolved">Online</span>' +
    '</div>' +

    '<div class="complaint-item">' +
      '<div class="complaint-details">' +
        '<strong>PostgreSQL Database</strong>' +
        '<span>Database connection status reported by the backend.</span>' +
      '</div>' +
      '<span class="status ' +
        (databaseOnline ? 'resolved' : 'high') +
      '">' +
        (databaseOnline ? 'Connected' : 'Unavailable') +
      '</span>' +
    '</div>';

  if (liveDataStatus) {
    liveDataStatus.textContent =
      databaseOnline ? 'Available' : 'Unavailable';

    liveDataStatus.className =
      databaseOnline ? 'status resolved' : 'status high';
  }

  if (databaseStatus) {
    databaseStatus.textContent =
      databaseOnline ? 'Connected' : 'Unavailable';

    databaseStatus.className =
      databaseOnline ? 'status resolved' : 'status high';
  }

  settingsLoaded = true;
}

  // ---- Cities page ----
  let cityRankingPage = 1;
  async function loadCitiesPage(force) {
    if (citiesLoaded && !force && cityRankingPage === 1) return;
    const container = document.querySelector('#citiesPage .ranking-list');
    if (!container) return;
    container.innerHTML = '<div class="ranking-empty">Loading city rankings…</div>';
    const response = await UrbanInsightsAPI.getCityRankings(cityRankingPage, 25);
    if (!response) { container.innerHTML = '<div class="ranking-empty">Unable to load city rankings. Please start the backend and try again.</div>'; return; }
    if (response.error) { container.innerHTML = '<div class="ranking-empty">City ranking API error: ' + escapeHtml(response.error) + '</div>'; return; }
    const rankings = response.items || [];
    if (!rankings.length) { container.innerHTML = '<div class="ranking-empty">No city ranking data is available.</div>'; return; }
    citiesLoaded = true; container.innerHTML = '';
    rankings.forEach((r) => {
      const item = document.createElement('div'); item.className = 'ranking-item' + (r.rank === 1 ? ' first' : '');
      item.innerHTML = '<div class="rank">' + String(r.rank).padStart(2, '0') + '</div>' + '<div class="city-avatar">' + escapeHtml(r.city.charAt(0)) + '</div>' + '<div class="city-info"><strong>' + escapeHtml(r.city) + '</strong><span>' + escapeHtml(r.district) + ' · ' + escapeHtml(r.state) + ' · ' + r.totalComplaints + ' complaints</span></div>' + '<div class="rank-score" title="Resolution rate">' + Number(r.resolutionRate).toFixed(0) + '%</div>';
      container.appendChild(item);
    });
    const oldPager = container.parentElement.querySelector('.city-ranking-pager'); if (oldPager) oldPager.remove();
    const pager = document.createElement('div'); pager.className='city-ranking-pager'; pager.style.display='flex'; pager.style.justifyContent='space-between'; pager.style.marginTop='12px';
    const totalPages=Math.max(1,Math.ceil((response.total||0)/(response.pageSize||25)));
    pager.innerHTML='<button type="button" class="secondary-button" '+(cityRankingPage<=1?'disabled':'')+'>Previous</button><span>Page '+cityRankingPage+' of '+totalPages+'</span><button type="button" class="secondary-button" '+(cityRankingPage>=totalPages?'disabled':'')+'>Next</button>';
    const buttons=pager.querySelectorAll('button'); buttons[0].addEventListener('click',()=>{if(cityRankingPage>1){cityRankingPage--;loadCitiesPage(true);}}); buttons[1].addEventListener('click',()=>{if(cityRankingPage<totalPages){cityRankingPage++;loadCitiesPage(true);}});
    container.parentElement.appendChild(pager);
  }

  document.addEventListener('DOMContentLoaded', function () {
    const staticComplaintList = document.getElementById('complaintList');
    if (staticComplaintList) staticComplaintList.innerHTML = '<div class="ranking-empty">Loading complaints…</div>';

    refreshDashboardStats();
    loadDashboardCityRanking();

    const cityFilter = document.getElementById('cityFilter');
    if (cityFilter) cityFilter.addEventListener('change', function () {
      renderDashboardCategoryChart(dashboardComplaints, cityFilter.value);
    });

    const analysisNav = document.querySelector('.nav-item[data-section="analysis"]');
    if (analysisNav) analysisNav.addEventListener('click', function () { loadAnalysisPage(false); });
    const analysisPageEl = document.getElementById('analysisPage');
    if (analysisPageEl && analysisPageEl.classList.contains('active-page')) loadAnalysisPage(false);

    const complaintsNav = document.querySelector('.nav-item[data-section="complaints"]');
    if (complaintsNav) complaintsNav.addEventListener('click', function () { loadComplaintsPage(false); });

    const citiesNav = document.querySelector('.nav-item[data-section="cities"]');
    if (citiesNav) citiesNav.addEventListener('click', function () { loadCitiesPage(false); });

    const complaintsPageEl = document.getElementById('complaintsPage');
    if (complaintsPageEl && complaintsPageEl.classList.contains('active-page')) loadComplaintsPage(false);
    const citiesPageEl = document.getElementById('citiesPage');
    if (citiesPageEl && citiesPageEl.classList.contains('active-page')) loadCitiesPage(false);

    const departmentsNav = document.querySelector('.nav-item[data-section="departments"]');
    if (departmentsNav) {
      departmentsNav.addEventListener('click', function () {
        loadDepartmentsPage(false);
      });
    }

    const departmentsPageEl = document.getElementById('departmentsPage');
    if (departmentsPageEl && departmentsPageEl.classList.contains('active-page')) {
      loadDepartmentsPage(false);
    }
      });

    const reportsNav = document.querySelector('.nav-item[data-section="reports"]');

    if (reportsNav) {
      reportsNav.addEventListener('click', function () {
        loadReportsPage(false);
      });
    }

    const reportsPageEl = document.getElementById('reportsPage');

    if (reportsPageEl && reportsPageEl.classList.contains('active-page')) {
      loadReportsPage(false);
    }
    loadNotificationPanel();
    const notificationsNav = document.querySelector('.nav-item[data-section="notifications"]');

    if (notificationsNav) {
      notificationsNav.addEventListener('click', function () {
        loadNotificationsPage(false);
      });
    }

    const notificationsPageEl = document.getElementById('notificationsPage');

    if (notificationsPageEl && notificationsPageEl.classList.contains('active-page')) {
      loadNotificationsPage(false);
    }

    const settingsNav = document.querySelector(
  '.nav-item[data-section="settings"]'
);

    if (settingsNav) {
      settingsNav.addEventListener('click', function () {
        loadSettingsPage(false);
      });
    }

    const settingsPageEl =
      document.getElementById('settingsPage');

    if (
      settingsPageEl &&
      settingsPageEl.classList.contains('active-page')
    ) {
      loadSettingsPage(false);
    }

  window.UrbanInsightsLiveData = { invalidate, refreshDashboardStats, loadComplaintsPage, loadCitiesPage, loadAnalysisPage };
})();
