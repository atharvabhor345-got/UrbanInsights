/*
    ================================================================
    URBAN INSIGHTS -- frontend/map-init.js
    ================================================================
    Wires the WebGL India map (opengl/webgl-india-map.js) into the
    existing single-page app. Kept as its own small file rather than
    editing script.js directly, so the two stay easy to tell apart.

    The map is initialised lazily, the first time the person actually
    opens the Map tab - its canvas sits inside a `.page` that starts
    hidden (`display:none` until `.active-page` is added), and a
    hidden canvas reports 0 width/height, which would break the
    WebGL viewport math if we tried to set it up any earlier.
    ================================================================
*/
(function () {
  'use strict';

  let mapApi = null;
  let mapInitialized = false;

  function initMapOnce() {
    if (mapInitialized) return;
    const canvas = document.getElementById('indiaMapCanvas');
    if (!canvas) return;

    if (canvas.clientWidth === 0 || canvas.clientHeight === 0) {
      // Page hasn't finished laying out yet - try again next frame
      // instead of initialising against a zero-sized canvas.
      requestAnimationFrame(initMapOnce);
      return;
    }
    mapInitialized = true;

    mapApi = window.UrbanInsightsIndiaMap.init({
      canvas: canvas,
      labelLayer: document.getElementById('indiaMapLabels'),
      tooltipEl: document.getElementById('indiaMapTooltip'),
      infoPanel: {
        root: document.getElementById('indiaMapInfo'),
        name: document.getElementById('indiaMapInfoName'),
        severity: document.getElementById('indiaMapInfoSeverity'),
        complaints: document.getElementById('indiaMapInfoComplaints'),
        breakdown: document.getElementById('indiaMapInfoBreakdown'),
      },
      searchInput: document.getElementById('indiaMapSearch'),
      searchResults: document.getElementById('indiaMapSearchResults'),
    });

    const zoomInBtn = document.getElementById('indiaMapZoomIn');
    const zoomOutBtn = document.getElementById('indiaMapZoomOut');
    const resetBtn = document.getElementById('indiaMapReset');
    if (zoomInBtn) zoomInBtn.addEventListener('click', function () { mapApi.zoomBy(1.35); });
    if (zoomOutBtn) zoomOutBtn.addEventListener('click', function () { mapApi.zoomBy(1 / 1.35); });
    if (resetBtn) resetBtn.addEventListener('click', function () {
      mapApi.resetView();
      const search = document.getElementById('indiaMapSearch');
      if (search) search.value = '';
    });
  }

  // Category filters: visually functional today; once the backend
  // returns per-category severity, flip the map's colouring inside
  // this same click handler instead of only toggling `.active`.
  function wireCategoryFilters() {
    const filters = document.querySelectorAll('#mapPage .map-filter');
    filters.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filters.forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        if (mapApi && mapApi.refreshLiveSeverity) mapApi.refreshLiveSeverity(btn.dataset.category || 'all');
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    wireCategoryFilters();

    const mapNavItem = document.querySelector('.nav-item[data-section="map"]');
    if (mapNavItem) {
      mapNavItem.addEventListener('click', initMapOnce);
    }

    // If the Map tab is already the active page on load (e.g. a future
    // deep link), initialise right away instead of waiting for a click.
    const mapPage = document.getElementById('mapPage');
    if (mapPage && mapPage.classList.contains('active-page')) {
      initMapOnce();
    }
  });
})();
