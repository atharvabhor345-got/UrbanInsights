/* =========================================
   URBAN INSIGHTS
   FRONTEND INTERACTION
========================================= */


/* =========================================
   ELEMENTS
========================================= */

const sidebar = document.getElementById("sidebar");
const menuButton = document.getElementById("menuButton");
const closeMenu = document.getElementById("closeMenu");
const sidebarOverlay = document.getElementById("sidebarOverlay");

const navItems = document.querySelectorAll(".nav-item");

const pageTitle = document.getElementById("pageTitle");

const searchButton = document.getElementById("searchButton");
const searchOverlay = document.getElementById("searchOverlay");
const closeSearch = document.getElementById("closeSearch");
const globalSearch = document.getElementById("globalSearch");

const notificationButton =
    document.getElementById("notificationButton");

const notificationPanel =
    document.getElementById("notificationPanel");

const closeNotifications =
    document.getElementById("closeNotifications");

const reportButton =
    document.getElementById("reportButton");

const reportModal =
    document.getElementById("reportModal");

const closeReport =
    document.getElementById("closeReport");

const complaintForm =
    document.getElementById("complaintForm");
const aiTriageButton = document.getElementById("aiTriageButton");
const aiTriageMessage = document.getElementById("aiTriageMessage");

const complaintList =
    document.getElementById("complaintList");

const totalComplaints =
    document.getElementById("totalComplaints");

const cityFilter =
    document.getElementById("cityFilter");

const viewAllButton =
    document.getElementById("viewAllButton");

const authModal=document.getElementById("authModal");
const closeAuth=document.getElementById("closeAuth");
const loginTab=document.getElementById("loginTab");
const registerTab=document.getElementById("registerTab");
const loginForm=document.getElementById("loginForm");
const registerForm=document.getElementById("registerForm");
const profileButton=document.getElementById("profileButton");
const profileMenu=document.getElementById("profileMenu");
const profileSignIn=document.getElementById("profileSignIn");
const profileAdminSignIn=document.getElementById("profileAdminSignIn");
const profileLogout=document.getElementById("profileLogout");


/* =========================================
   SIDEBAR
========================================= */

function openSidebar() {

    sidebar.classList.add("open");

    sidebarOverlay.classList.add("active");

}


function closeSidebar() {

    sidebar.classList.remove("open");

    sidebarOverlay.classList.remove("active");

}


/* OPEN */

menuButton.addEventListener("click", function () {

    openSidebar();

});


/* CLOSE */

closeMenu.addEventListener("click", function () {

    closeSidebar();

});


/* CLOSE BY CLICKING OUTSIDE */

sidebarOverlay.addEventListener("click", function () {

    closeSidebar();

});


/* =========================================
   NAVIGATION
========================================= */

navItems.forEach(function (item) {

    item.addEventListener("click", function () {

        /* Remove active from all */

        navItems.forEach(function (nav) {

            nav.classList.remove("active");

        });


        /* Activate clicked item */

        item.classList.add("active");


        /* Change heading */

        const section =
            item.dataset.section;


        const titles = {

            dashboard: "City Overview",

            complaints: "Complaint Management",

            cities: "City Ranking",

            analysis: "Complaint Analysis",

            departments: "Departments",

            reports: "Reports",

            notifications: "Notifications",

            settings: "Settings"

        };


        pageTitle.textContent =
            titles[section] || "Urban Insights";


        /* Close sidebar on mobile */

        if (window.innerWidth <= 850) {

            closeSidebar();

        }

    });

});


/* =========================================
   SEARCH
========================================= */

searchButton.addEventListener("click", function () {

    searchOverlay.classList.add("active");

    setTimeout(function () {

        globalSearch.focus();

    }, 200);

});


closeSearch.addEventListener("click", function () {

    searchOverlay.classList.remove("active");

});


searchOverlay.addEventListener("click", function (event) {

    if (event.target === searchOverlay) {

        searchOverlay.classList.remove("active");

    }

});


/* ESC KEY */

document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {

        closeSidebar();

        searchOverlay.classList.remove("active");

        notificationPanel.classList.remove("active");

        reportModal.classList.remove("active");
        authModal.classList.remove("active");

    }

});


/* =========================================
   NOTIFICATIONS
========================================= */

notificationButton.addEventListener("click", function (event) {

    event.stopPropagation();

    notificationPanel.classList.toggle("active");

});


closeNotifications.addEventListener("click", function () {

    notificationPanel.classList.remove("active");

});


document.addEventListener("click", function (event) {

    if (
        !notificationPanel.contains(event.target) &&
        event.target !== notificationButton
    ) {

        notificationPanel.classList.remove("active");

    }

});

let currentUser=null;
let authMode="login";

function initials(name){
    return name.split(/\s+/).filter(Boolean).slice(0,2).map(part=>part[0]).join("").toUpperCase() || "UI";
}

function updateProfile(user){
    const previousRole=currentUser?.role;
    currentUser=user;
    window.UrbanInsightsCurrentUser=user;
    document.getElementById("profileName").textContent=user?user.name:"Guest";
    document.getElementById("profileRole").textContent=user?(user.role==="citizen"?"Citizen":user.role==="super_admin"?"Super Admin":"Administrator"):"Sign in";
    document.getElementById("profileAvatar").textContent=user?initials(user.name):"UI";
    profileSignIn.hidden=!!user;
    profileAdminSignIn.hidden=!!user;
    profileLogout.hidden=!user;
    if(previousRole!==user?.role&&window.UrbanInsightsLiveData){
        window.UrbanInsightsLiveData.invalidate();
        window.UrbanInsightsLiveData.loadComplaintsPage(true);
        window.UrbanInsightsLiveData.refreshDashboardStats();
    }
}

async function refreshSession(){
    const user=await UrbanInsightsAPI.getCurrentUser();
    updateProfile(user);
}

function openAuth(mode){
    authModal.classList.add("active");
    setAuthMode(mode==="register"?"register":mode==="admin"?"admin":"login");
}

function setAuthMode(mode){
    authMode=mode;
    const register=mode==="register";
    const admin=mode==="admin";
    loginTab.classList.toggle("active",!register);
    registerTab.classList.toggle("active",register);
    loginTab.textContent=admin?"Admin Sign In":"Sign In";
    registerTab.hidden=admin;
    document.querySelector(".auth-tabs").classList.toggle("admin-auth-mode",admin);
    loginForm.hidden=register;
    registerForm.hidden=!register;
    document.getElementById("authSubtitle").textContent=register?"Create a citizen account":admin?"Administrator access":"Sign in to your account";
    document.getElementById("loginSubmitLabel").textContent=admin?"Admin Sign In":"Sign In";
}

profileButton.addEventListener("click",(event)=>{event.stopPropagation();profileMenu.hidden=!profileMenu.hidden;});
profileSignIn.addEventListener("click",()=>{profileMenu.hidden=true;openAuth("login");});
profileAdminSignIn.addEventListener("click",()=>{profileMenu.hidden=true;openAuth("admin");});
profileLogout.addEventListener("click",async()=>{await UrbanInsightsAPI.logout();updateProfile(null);profileMenu.hidden=true;});
closeAuth.addEventListener("click",()=>authModal.classList.remove("active"));
authModal.addEventListener("click",(event)=>{if(event.target===authModal)authModal.classList.remove("active");});
loginTab.addEventListener("click",()=>setAuthMode("login"));
registerTab.addEventListener("click",()=>setAuthMode("register"));
document.addEventListener("click",(event)=>{if(!profileMenu.contains(event.target)&&event.target!==profileButton&&!profileButton.contains(event.target))profileMenu.hidden=true;});

loginForm.addEventListener("submit",async(event)=>{
    event.preventDefault();
    const error=document.getElementById("loginError");
    const result=await UrbanInsightsAPI.login({email:document.getElementById("loginEmail").value,password:document.getElementById("loginPassword").value});
    if(!result.ok){error.textContent=result.data?.error||"Unable to sign in.";return;}
    if(authMode==="admin"&&!['admin','super_admin'].includes(result.data?.role)){await UrbanInsightsAPI.logout();error.textContent="This account does not have administrator access.";return;}
    error.textContent="";
    updateProfile(result.data);
    authModal.classList.remove("active");
});

registerForm.addEventListener("submit",async(event)=>{
    event.preventDefault();
    const error=document.getElementById("registerError");
    const result=await UrbanInsightsAPI.register({name:document.getElementById("registerName").value,email:document.getElementById("registerEmail").value,password:document.getElementById("registerPassword").value});
    if(!result.ok){error.textContent=result.data?.error||"Unable to create account.";return;}
    error.textContent="";
    updateProfile(result.data);
    authModal.classList.remove("active");
});

refreshSession();


/* =========================================
   REPORT COMPLAINT MODAL
========================================= */

reportButton.addEventListener("click", function () {
    if(!currentUser){openAuth("login");return;}
    reportModal.classList.add("active");

});


closeReport.addEventListener("click", function () {

    reportModal.classList.remove("active");

});


reportModal.addEventListener("click", function (event) {

    if (event.target === reportModal) {

        reportModal.classList.remove("active");

    }

});

aiTriageButton.addEventListener("click", async function () {
    const description = document.getElementById("complaintDescription").value.trim();
    aiTriageMessage.hidden = false;
    aiTriageMessage.className = "ai-triage-message is-error";

    if (description.length < 8 || description.length > 3000) {
        aiTriageMessage.textContent = "Enter a description between 8 and 3000 characters first.";
        return;
    }

    const originalLabel = aiTriageButton.innerHTML;
    aiTriageButton.disabled = true;
    aiTriageButton.textContent = "Getting suggestion...";
    const result = await UrbanInsightsAPI.suggestComplaintTriage({ description });
    aiTriageButton.disabled = false;
    aiTriageButton.innerHTML = originalLabel;

    if (!result || !result.ok) {
        aiTriageMessage.textContent = result?.data?.error || "Could not get an AI suggestion. Check the server and try again.";
        return;
    }

    const suggestion = result.data;
    const allowedCategories = ["Traffic", "Water", "Garbage", "Electricity"];
    if (!allowedCategories.includes(suggestion?.category) || !Number.isInteger(suggestion?.impactScore) || !Number.isInteger(suggestion?.urgencyScore)) {
        aiTriageMessage.textContent = "The AI returned an invalid suggestion. Your form has not been changed.";
        return;
    }

    document.getElementById("complaintType").value = suggestion.category;
    document.getElementById("complaintImpact").value = suggestion.impactScore;
    document.getElementById("complaintUrgency").value = suggestion.urgencyScore;
    aiTriageMessage.className = "ai-triage-message is-success";
    aiTriageMessage.textContent = suggestion.reason + " Review or change these suggestions before submitting.";
});


/* =========================================
   ADD NEW COMPLAINT
========================================= */

complaintForm.addEventListener("submit", async function (event) {

    event.preventDefault();


    const type =
        document.getElementById("complaintType").value;

    const stateId = Number(document.getElementById("complaintState").value);
    const districtId = Number(document.getElementById("complaintDistrict").value);
    const cityId = Number(document.getElementById("complaintCity").value);
    const city = document.getElementById("complaintCity").selectedOptions[0]?.textContent || "";
    const impactScore = Number(document.getElementById("complaintImpact").value);
    const urgencyScore = Number(document.getElementById("complaintUrgency").value);

    const locality =
        document.getElementById("complaintLocality").value;

   const description =
    document.getElementById("complaintDescription").value.trim();


        if (
            !type ||
            !stateId ||
            !districtId ||
            !cityId ||
            !description ||
            !locality
        ) {
            alert("Please fill in all required complaint fields.");
            return;
        }


    const submitBtn = complaintForm.querySelector(".submit-button");
    const originalBtnHTML = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = "Submitting…";

    // Real submission: OOP builds the object, assembly classifies its
    // severity, Postgres stores it - see docs/API.md. Falls back to the
    // old purely-decorative behaviour below if the server isn't running,
    // so the form still "works" for anyone previewing the static file.
    const result = await UrbanInsightsAPI.createComplaint({
        category: type,
        stateId: stateId,
        districtId: districtId,
        cityId: cityId,
        locality: locality,
        description: description,
        citizenName: currentUser ? currentUser.name : "Anonymous",
        impactScore: impactScore,
        urgencyScore: urgencyScore,
    });

    submitBtn.disabled = false;
    submitBtn.innerHTML = originalBtnHTML;

    let referenceLabel = "";
    const complaintCreated =
    result &&
    result.ok &&
    result.status === 201 &&
    result.data &&
    Number.isInteger(result.data.id) &&
    result.data.id > 0 &&
    result.data.referenceCode;

    if (complaintCreated) {
    referenceLabel = result.data.referenceCode;

    if (window.UrbanInsightsLiveData) {
        window.UrbanInsightsLiveData.invalidate();
        window.UrbanInsightsLiveData.refreshDashboardStats();
        }
    }

    if (!complaintCreated) {
        const message =
            result &&
            result.data &&
            result.data.error
                ? result.data.error
                : "Could not submit complaint. Check the server connection.";

        alert(message);
        return;
    }

    /* Create new complaint element */

    const complaint =
        document.createElement("div");

    complaint.className =
        "complaint-item";


    let icon = "fa-file";

    let iconClass = "";


    if (type === "Traffic") {

        icon = "fa-road";
        iconClass = "road";

    }

    else if (type === "Water") {

        icon = "fa-droplet";
        iconClass = "water";

    }

    else if (type === "Garbage") {

        icon = "fa-trash";
        iconClass = "garbage";

    }

    else if (type === "Electricity") {

        icon = "fa-bolt";
        iconClass = "electricity";

    }


    complaint.innerHTML = `

        <div class="complaint-icon ${iconClass}">

            <i class="fa-solid ${icon}"></i>

        </div>


        <div class="complaint-details">

            <strong>
                ${type} Complaint
            </strong>

            <span>
                ${city} · Just now${referenceLabel ? " · " + referenceLabel : ""}
            </span>

        </div>


        <span class="status pending">
            Pending
        </span>

    `;


    /* Add to beginning */

    complaintList.prepend(complaint);


    /* Update total */

    let currentTotal =
        parseInt(totalComplaints.textContent);


    totalComplaints.textContent =
        currentTotal + 1;


    /* Close modal */

    reportModal.classList.remove("active");


    /* Reset form */

    complaintForm.reset();


    /* Notification */

    showNotification(
        referenceLabel
            ? `Complaint ${referenceLabel} submitted successfully`
            : "Complaint submitted successfully (offline - not saved to the server)"
    );

});


/* =========================================
   TOAST NOTIFICATION
========================================= */

function showNotification(message) {

    const toast =
        document.createElement("div");


    toast.style.position = "fixed";
    toast.style.bottom = "25px";
    toast.style.right = "25px";
    toast.style.padding = "13px 17px";
    toast.style.background = "rgba(255,255,255,0.95)";
    toast.style.backdropFilter = "blur(20px)";
    toast.style.borderRadius = "12px";
    toast.style.boxShadow =
        "0 15px 40px rgba(20,40,70,0.15)";
    toast.style.fontSize = "10px";
    toast.style.fontWeight = "700";
    toast.style.zIndex = "5000";


    toast.innerHTML = `

        <i class="fa-solid fa-circle-check"
           style="color:#20a976;margin-right:7px">
        </i>

        ${message}

    `;


    document.body.appendChild(toast);


    setTimeout(function () {

        toast.remove();

    }, 3000);

}


/* =========================================
   CITY FILTER
========================================= */

cityFilter.addEventListener("change", function () {

    const selectedCity =
        cityFilter.value;


    console.log(
        "Selected city:",
        selectedCity
    );


    /*
        Later this will request
        live data from C++ backend.
    */

});


/* =========================================
   VIEW ALL
========================================= */

viewAllButton.addEventListener("click", function () {

    const complaintsNav =
        document.querySelector(
            '[data-section="complaints"]'
        );


    complaintsNav.click();

});


/* =========================================
   RESPONSIVE SIDEBAR
========================================= */

window.addEventListener("resize", function () {

    if (window.innerWidth > 850) {

        sidebar.classList.remove("open");

        sidebarOverlay.classList.remove("active");

    }

});


/* =========================================
   LIVE DATA SIMULATION
========================================= */

let liveTotal =
    parseInt(totalComplaints.textContent);


/*
    This is temporary.

    Later:

    C++ Backend
         ↓
    API / JSON
         ↓
    JavaScript
         ↓
    Dashboard

    The interval will then be replaced
    by real backend data.
*/

setInterval(function () {

    /*
        Small visual live update simulation.
        No real data is generated here.
    */

    console.log(
        "Urban Insights: waiting for live backend data..."
    );

}, 5000);

/* =========================================
   PAGE NAVIGATION
========================================= */

const pages = document.querySelectorAll(".page");

const pageTitles = {

    dashboard: "City Overview",

    complaints: "Complaint Management",

    map: "City Severity Map",

    cities: "City Ranking",

    analysis: "Complaint Analysis",

    departments: "Departments",

    reports: "Reports",

    notifications: "Notifications",

    settings: "Settings"

};


navItems.forEach(function (item) {

    item.addEventListener("click", function () {

        const section = item.dataset.section;


        /* Remove active from navigation */

        navItems.forEach(function (nav) {

            nav.classList.remove("active");

        });


        /* Activate selected navigation */

        item.classList.add("active");


        /* Hide every page */

        pages.forEach(function (page) {

            page.classList.remove("active-page");

        });


        /* Show selected page */

        const selectedPage =
            document.getElementById(section + "Page");


        if (selectedPage) {

            selectedPage.classList.add("active-page");

        }


        /* Change heading */

        pageTitle.textContent =
            pageTitles[section] || "Urban Insights";


        /* Close mobile sidebar */

        if (window.innerWidth <= 850) {

            closeSidebar();

        }

    });

});

// Load database-backed geography for the complaint form.
document.addEventListener("DOMContentLoaded", async function () {
  if (!window.UrbanInsightsAPI || !document.getElementById("complaintState")) return;
  const rows = await UrbanInsightsAPI.getGeography();
  if (!Array.isArray(rows)) return;
  const stateSel=document.getElementById("complaintState"), districtSel=document.getElementById("complaintDistrict"), citySel=document.getElementById("complaintCity");
  const fill=(el, rows, valueKey, labelKey, placeholder)=>{el.innerHTML='<option value="">'+placeholder+'</option>'; rows.forEach(r=>{const o=document.createElement('option');o.value=r[valueKey];o.textContent=r[labelKey];el.appendChild(o);});};
  const data = [];
  const states = new Map();
  rows.forEach(row => {
    let state = states.get(row.state_id);
    if (!state) {
      state = { id: row.state_id, name: row.state, districts: [] };
      states.set(row.state_id, state);
      data.push(state);
    }
    let district = state.districts.find(item => item.id === row.district_id);
    if (!district) {
      district = { id: row.district_id, name: row.district, cities: [] };
      state.districts.push(district);
    }
    district.cities.push({ id: row.city_id, name: row.city });
  });
  fill(stateSel,data,'id','name','Select state');
  stateSel.addEventListener('change',()=>{const st=data.find(x=>String(x.id)===stateSel.value); fill(districtSel,st?st.districts:[],'id','name','Select district'); fill(citySel,[],'id','name','Select city');});
  districtSel.addEventListener('change',()=>{const st=data.find(x=>String(x.id)===stateSel.value); const d=st?.districts.find(x=>String(x.id)===districtSel.value); fill(citySel,d?d.cities:[],'id','name','Select city');});
});




/* =========================================================
   GLOBAL SEARCH
========================================================= */

const globalSearchResults =
    document.getElementById("globalSearchResults");

let globalSearchTimer = null;

globalSearch.addEventListener("input", function () {

    const query = globalSearch.value.trim().toLowerCase();

    clearTimeout(globalSearchTimer);

    if (!query) {
        globalSearchResults.innerHTML = `
            <div class="search-empty">
                Type something to search...
            </div>
        `;
        return;
    }

    globalSearchTimer = setTimeout(async function () {

        globalSearchResults.innerHTML = `
            <div class="search-loading">
                Searching...
            </div>
        `;

        try {

            const complaints =
                await UrbanInsightsAPI.getComplaints(5000);

            if (!Array.isArray(complaints)) {
                globalSearchResults.innerHTML = `
                    <div class="search-empty">
                        Unable to load search data.
                    </div>
                `;
                return;
            }

            const results = complaints.filter(function (complaint) {

                const searchableText = [

                    complaint.id,
                    complaint.referenceCode,
                    complaint.category,
                    complaint.description,
                    complaint.locality,
                    complaint.citizenName,
                    complaint.stateName,
                    complaint.districtName,
                    complaint.cityName

                ]
                    .filter(Boolean)
                    .join(" ")
                    .toLowerCase();

                return searchableText.includes(query);
            });

            if (results.length === 0) {

                globalSearchResults.innerHTML = `
                    <div class="search-empty">
                        No results found for
                        "<strong>${query}</strong>"
                    </div>
                `;

                return;
            }

            globalSearchResults.innerHTML = "";

            results.slice(0, 10).forEach(function (complaint) {

                const item =
                    document.createElement("div");

                item.className =
                    "global-search-result";

                const title =
                    document.createElement("strong");

                title.textContent =
                    complaint.referenceCode ||
                    "Complaint #" + complaint.id;

                const description =
                    document.createElement("p");

                description.textContent =
                    complaint.description ||
                    complaint.category ||
                    "Complaint";

                const location =
                    document.createElement("small");

                location.textContent =
                    [
                        complaint.cityName,
                        complaint.districtName,
                        complaint.stateName
                    ]
                        .filter(Boolean)
                        .join(", ");

                item.appendChild(title);
                item.appendChild(description);

                if (location.textContent) {
                    item.appendChild(location);
                }

                item.addEventListener("click", function () {

                    searchOverlay.classList.remove("active");

                    globalSearch.value = "";

                    /*
                     * Open complaint section
                     */
                    const complaintsNav =
                        document.querySelector(
                            '[data-section="complaints"]'
                        );

                    if (complaintsNav) {
                        complaintsNav.click();
                    }

                    /*
                     * If complaint ID exists,
                     * try to open its details.
                     */
                    if (complaint.id) {

                        setTimeout(function () {

                            const complaintRow =
                                document.querySelector(
                                    `[data-complaint-id="${complaint.id}"]`
                                );

                            if (complaintRow) {
                                complaintRow.click();
                            }

                        }, 300);
                    }

                });

                globalSearchResults.appendChild(item);

            });

        } catch (error) {

            console.error(
                "Global search error:",
                error
            );

            globalSearchResults.innerHTML = `
                <div class="search-empty">
                    Search failed. Please try again.
                </div>
            `;
        }

    }, 250);

});
