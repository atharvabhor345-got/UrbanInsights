# Java OOP Backend

This is the ACTIVE OOP/backend module of Urban Insights. The previous C++ OOP backend is kept in `legacy_cpp_oop/` only as reference.

## Course mapping
- Java: OOP — abstraction, encapsulation, inheritance, polymorphism, constructors, exception handling.
- C++: DSA — the existing `dsa/` module remains C++.
- NASM: COA — `assembly/severity.asm`; the Java backend can call the compiled `severity_runner` bridge.
- PostgreSQL: persistent data layer through JDBC.
- HTML/CSS/JS + WebGL: frontend/visualization.

## Run
1. Install JDK 17+ and Maven.
2. Install PostgreSQL and load `database/schema.sql`, `database/seed.sql`, and optionally `database/demo_data.sql`.
3. Configure `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, and `DB_PASSWORD` in the environment used to launch Java. Defaults are `localhost:5432`, database `urbaninsights`, user `postgres`, and an empty password; set `DB_PASSWORD` to your PostgreSQL password when password authentication is enabled. Do not put database passwords in source files.
4. Optional complaint triage: set `AI_API_KEY` in the Java server environment. `AI_API_URL` defaults to `https://api.openai.com/v1/chat/completions` and `AI_MODEL` defaults to `gpt-4o-mini`; other OpenAI-compatible providers can be configured with these variables. Never put the provider key in frontend code or commit it.
5. From this directory run `mvn clean package`.
6. Run the jar with `java -jar target/urban-insights-backend-1.0.0.jar`.
7. Open `http://localhost:8080/`.

The Java server uses only JDK HTTP-server classes plus the PostgreSQL JDBC driver. No Spring framework is required.

## Swing complaint form

After building the project, start the backend as above, then open a second terminal in `java-backend` and run:

```powershell
java -cp target\urban-insights-backend-1.0.0.jar com.urbaninsights.client.ComplaintSwingApp
```

The Swing form loads states, districts, and cities from the running backend and submits complaints through `POST /api/complaints`. It uses the same PostgreSQL database as the website; no separate database configuration is needed. As with the website form, submissions are recorded as `Anonymous`. The API defaults to `http://localhost:8080`. To use another server URL, set the `urbaninsights.api` Java system property, for example:

The form also has a **Save complaint to file** option to export the current form contents to a local UTF-8 text file. This does not submit the complaint to the server.

```powershell
java -Durbaninsights.api=http://localhost:8081 -cp target\urban-insights-backend-1.0.0.jar com.urbaninsights.client.ComplaintSwingApp
```
