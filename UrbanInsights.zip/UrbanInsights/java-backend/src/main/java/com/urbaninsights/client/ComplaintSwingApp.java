package com.urbaninsights.client;

import com.urbaninsights.util.Json;
import com.urbaninsights.util.TextFileHandler;
import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public final class ComplaintSwingApp {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final URI apiBase;
    private final JFrame frame = new JFrame("Urban Insights - Report a Complaint");
    private final JComboBox<String> category = new JComboBox<>(new String[]{"Traffic", "Water", "Garbage", "Electricity"});
    private final JComboBox<GeoOption> state = new JComboBox<>();
    private final JComboBox<GeoOption> district = new JComboBox<>();
    private final JComboBox<GeoOption> city = new JComboBox<>();
    private final JSpinner impact = new JSpinner(new SpinnerNumberModel(5, 0, 10, 1));
    private final JSpinner urgency = new JSpinner(new SpinnerNumberModel(5, 0, 10, 1));
    private final JTextField locality = new JTextField();
    private final JTextArea description = new JTextArea(5, 30);
    private final JButton submit = new JButton("Submit complaint");
    private final JButton saveToFile = new JButton("Save complaint to file");
    private final JLabel status = new JLabel("Connecting to the Urban Insights server...");
    private final TextFileHandler<ComplaintFileData> fileHandler = new TextFileHandler<>();
    private List<GeographyRow> geography = List.of();

    private ComplaintSwingApp(URI apiBase) {
        this.apiBase = apiBase;
        buildWindow();
        loadGeography();
    }

    public static void main(String[] args) {
        String base = System.getProperty("urbaninsights.api", "http://localhost:8080");
        final URI apiBase;
        try {
            apiBase = URI.create(base.endsWith("/") ? base : base + "/");
            if (!("http".equalsIgnoreCase(apiBase.getScheme()) || "https".equalsIgnoreCase(apiBase.getScheme()))
                    || apiBase.getHost() == null) {
                throw new IllegalArgumentException("Use an http:// or https:// API URL.");
            }
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Invalid API URL: " + e.getMessage(), "Urban Insights",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        SwingUtilities.invokeLater(() -> new ComplaintSwingApp(apiBase).frame.setVisible(true));
    }

    private void buildWindow() {
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(520, 620));
        frame.setSize(600, 720);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(20, 24, 20, 24));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 5, 0);

        int row = 0;
        addField(form, c, row++, "Complaint type", category);
        addField(form, c, row++, "State", state);
        addField(form, c, row++, "District", district);
        addField(form, c, row++, "City", city);
        addField(form, c, row++, "Impact (0-10)", impact);
        addField(form, c, row++, "Urgency (0-10)", urgency);
        locality.setToolTipText("For example: Near City Hospital, MG Road");
        addField(form, c, row++, "Locality / Landmark", locality);
        description.setLineWrap(true);
        description.setWrapStyleWord(true);
        addField(form, c, row++, "Description", new JScrollPane(description));
        status.setForeground(new Color(80, 80, 80));
        addField(form, c, row++, "Status", status);
        submit.setEnabled(false);
        submit.addActionListener(event -> submitComplaint());
        saveToFile.addActionListener(event -> saveComplaintToFile());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.add(saveToFile);
        actions.add(submit);
        c.gridy = row * 2;
        c.insets = new Insets(14, 0, 0, 0);
        form.add(actions, c);

        state.addActionListener(event -> updateDistricts());
        district.addActionListener(event -> updateCities());
        frame.setContentPane(new JScrollPane(form));
        frame.setLocationRelativeTo(null);
    }

    private void saveComplaintToFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save complaint details");
        chooser.setSelectedFile(new java.io.File("urban-insights-complaint.txt"));
        chooser.setFileFilter(new FileNameExtensionFilter("Text files (*.txt)", "txt"));
        if (chooser.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) return;

        Path path = chooser.getSelectedFile().toPath();
        if (Files.exists(path) && JOptionPane.showConfirmDialog(frame,
                "The selected file already exists. Replace it?", "Confirm overwrite",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            fileHandler.write(path, currentComplaintFileData(), ComplaintSwingApp::formatComplaintFile);
            status.setText("Complaint details saved to " + path.getFileName() + ".");
            JOptionPane.showMessageDialog(frame, "Complaint details saved successfully.",
                    "Saved to file", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | SecurityException e) {
            showError("Could not save complaint details: " + rootMessage(e));
        }
    }

    private ComplaintFileData currentComplaintFileData() {
        return new ComplaintFileData(
                category.getSelectedItem().toString(),
                selectedName(state),
                selectedName(district),
                selectedName(city),
                impact.getValue().toString(),
                urgency.getValue().toString(),
                locality.getText().trim(),
                description.getText().trim());
    }

    private static String selectedName(JComboBox<GeoOption> selector) {
        GeoOption selected = (GeoOption) selector.getSelectedItem();
        return selected == null ? "Not selected" : selected.name();
    }

    private static String formatComplaintFile(ComplaintFileData data) {
        return String.join(System.lineSeparator(),
                "Urban Insights complaint",
                "Complaint type: " + data.category(),
                "State: " + data.state(),
                "District: " + data.district(),
                "City: " + data.city(),
                "Impact: " + data.impact(),
                "Urgency: " + data.urgency(),
                "Locality / Landmark: " + data.locality(),
                "Description:",
                data.description(),
                "");
    }

    private static void addField(JPanel panel, GridBagConstraints constraints, int row, String label, Component field) {
        constraints.gridy = row * 2;
        constraints.insets = new Insets(5, 0, 0, 0);
        panel.add(new JLabel(label), constraints);
        constraints.gridy++;
        constraints.insets = new Insets(3, 0, 7, 0);
        panel.add(field, constraints);
    }

    private void loadGeography() {
        new SwingWorker<List<GeographyRow>, Void>() {
            @Override
            protected List<GeographyRow> doInBackground() throws Exception {
                HttpResponse<String> health = requestGet("api/health");
                if (health.statusCode() != 200) {
                    throw new IOException("Server health check returned HTTP " + health.statusCode() + ".");
                }
                Map<?, ?> healthData = object(Json.parse(health.body()), "health response");
                if (!Boolean.TRUE.equals(healthData.get("database"))) {
                    throw new IOException("The server is running, but PostgreSQL is unavailable.");
                }
                HttpResponse<String> response = requestGet("api/geography");
                if (response.statusCode() != 200) {
                    throw new IOException("Geography request returned HTTP " + response.statusCode() + ".");
                }
                Object parsed = Json.parse(response.body());
                if (!(parsed instanceof List<?> rows)) {
                    throw new IOException("The geography response was not a list.");
                }
                List<GeographyRow> result = new ArrayList<>();
                for (Object item : rows) {
                    Map<?, ?> row = object(item, "geography row");
                    result.add(new GeographyRow(
                            integer(row.get("state_id"), "state_id"), text(row.get("state"), "state"),
                            integer(row.get("district_id"), "district_id"), text(row.get("district"), "district"),
                            integer(row.get("city_id"), "city_id"), text(row.get("city"), "city")));
                }
                if (result.isEmpty()) {
                    throw new IOException("No states, districts, or cities were returned by the database.");
                }
                return result;
            }

            @Override
            protected void done() {
                try {
                    geography = get();
                    populateStates();
                    submit.setEnabled(true);
                    status.setText("Connected to PostgreSQL.");
                } catch (Exception e) {
                    status.setText("Could not load complaint locations.");
                    showError("Could not connect to the complaint API: " + rootMessage(e));
                }
            }
        }.execute();
    }

    private void populateStates() {
        state.removeAllItems();
        geography.stream()
                .map(row -> new GeoOption(row.stateId(), row.stateName()))
                .distinct()
                .sorted(Comparator.comparing(GeoOption::name))
                .forEach(state::addItem);
        updateDistricts();
    }

    private void updateDistricts() {
        district.removeAllItems();
        city.removeAllItems();
        GeoOption selectedState = (GeoOption) state.getSelectedItem();
        if (selectedState == null) return;
        geography.stream()
                .filter(row -> row.stateId() == selectedState.id())
                .map(row -> new GeoOption(row.districtId(), row.districtName()))
                .distinct()
                .sorted(Comparator.comparing(GeoOption::name))
                .forEach(district::addItem);
    }

    private void updateCities() {
        city.removeAllItems();
        GeoOption selectedDistrict = (GeoOption) district.getSelectedItem();
        if (selectedDistrict == null) return;
        geography.stream()
                .filter(row -> row.districtId() == selectedDistrict.id())
                .map(row -> new GeoOption(row.cityId(), row.cityName()))
                .distinct()
                .sorted(Comparator.comparing(GeoOption::name))
                .forEach(city::addItem);
    }

    private void submitComplaint() {
        GeoOption selectedState = (GeoOption) state.getSelectedItem();
        GeoOption selectedDistrict = (GeoOption) district.getSelectedItem();
        GeoOption selectedCity = (GeoOption) city.getSelectedItem();
        String localityValue = locality.getText().trim();
        String descriptionValue = description.getText().trim();
        if (selectedState == null || selectedDistrict == null || selectedCity == null
                || localityValue.isEmpty() || descriptionValue.isEmpty()) {
            showError("Choose a complaint type and location, and enter a locality and description.");
            return;
        }

        String body = Json.obj(
                "category", category.getSelectedItem().toString().toLowerCase(Locale.ROOT),
                "stateId", selectedState.id(),
                "districtId", selectedDistrict.id(),
                "cityId", selectedCity.id(),
                "impactScore", impact.getValue(),
                "urgencyScore", urgency.getValue(),
                "locality", localityValue,
                "description", descriptionValue,
                "citizenName", "Anonymous");
        submit.setEnabled(false);
        status.setText("Submitting complaint...");
        new SwingWorker<HttpResponse<String>, Void>() {
            @Override
            protected HttpResponse<String> doInBackground() throws Exception {
                HttpRequest request = HttpRequest.newBuilder(apiBase.resolve("api/complaints"))
                        .timeout(Duration.ofSeconds(20))
                        .header("Content-Type", "application/json; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(body))
                        .build();
                return http.send(request, HttpResponse.BodyHandlers.ofString());
            }

            @Override
            protected void done() {
                submit.setEnabled(true);
                try {
                    HttpResponse<String> response = get();
                    Map<?, ?> result = object(Json.parse(response.body()), "complaint response");
                    if (response.statusCode() != 201) {
                        throw new IOException(text(result.get("error"), "The server rejected the complaint."));
                    }
                    String reference = text(result.get("referenceCode"), "Complaint saved");
                    status.setText("Complaint saved to PostgreSQL: " + reference);
                    JOptionPane.showMessageDialog(frame,
                            "Complaint saved successfully.\nReference: " + reference,
                            "Complaint submitted", JOptionPane.INFORMATION_MESSAGE);
                    locality.setText("");
                    description.setText("");
                    impact.setValue(5);
                    urgency.setValue(5);
                } catch (Exception e) {
                    String message = rootMessage(e);
                    status.setText("Submission failed.");
                    showError("Complaint was not confirmed as saved: " + message);
                }
            }
        }.execute();
    }

    private HttpResponse<String> requestGet(String path) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(apiBase.resolve(path))
                .timeout(Duration.ofSeconds(20))
                .GET()
                .build();
        return http.send(request, HttpResponse.BodyHandlers.ofString());
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Urban Insights", JOptionPane.ERROR_MESSAGE);
    }

    private static String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null ? current.getClass().getSimpleName() : current.getMessage();
    }

    private static Map<?, ?> object(Object value, String label) throws IOException {
        if (value instanceof Map<?, ?> object) return object;
        throw new IOException("Invalid " + label + ".");
    }

    private static int integer(Object value, String label) throws IOException {
        if (value instanceof Number number && number.longValue() >= Integer.MIN_VALUE
                && number.longValue() <= Integer.MAX_VALUE && number.doubleValue() == number.longValue()) {
            return number.intValue();
        }
        throw new IOException("Invalid " + label + " in geography response.");
    }

    private static String text(Object value, String label) throws IOException {
        if (value instanceof String text && !text.isBlank()) return text;
        throw new IOException("Invalid or missing " + label + ".");
    }

    private record GeographyRow(int stateId, String stateName, int districtId, String districtName,
                                int cityId, String cityName) {}

    private record ComplaintFileData(String category, String state, String district, String city,
                                     String impact, String urgency, String locality, String description) {}

    private record GeoOption(int id, String name) {
        @Override public String toString() { return name; }
    }
}
