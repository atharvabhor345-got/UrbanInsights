package com.urbaninsights.db;

import com.urbaninsights.util.Json;
import java.sql.*;
import java.util.*;

public class DatabaseManager implements AutoCloseable {
    private final Connection connection;
    public DatabaseManager() throws SQLException {
        String host=env("DB_HOST","localhost"), port=env("DB_PORT","5432"), db=env("DB_NAME","urbaninsights"), user=env("DB_USER","postgres"), pass=env("DB_PASSWORD","");
        try { Class.forName("org.postgresql.Driver"); } catch (ClassNotFoundException e) { throw new SQLException("PostgreSQL JDBC driver not found. Run Maven first.",e); }
        connection=DriverManager.getConnection("jdbc:postgresql://"+host+":"+port+"/"+db,user,pass);
    }
    private static String env(String k,String d){String v=System.getenv(k);return v==null?d:v;}
    public boolean ok(){try{return connection!=null&&!connection.isClosed();}catch(SQLException e){return false;}}
    private String rows(String sql,Object... args)throws SQLException{return rows(false,sql,args);}
    private String rowsCamel(String sql,Object... args)throws SQLException{return rows(true,sql,args);}
    private String rows(boolean camelCase,String sql,Object... args)throws SQLException{
        try(PreparedStatement ps=connection.prepareStatement(sql)){for(int i=0;i<args.length;i++)ps.setObject(i+1,args[i]); try(ResultSet rs=ps.executeQuery()){List<String> out=new ArrayList<>(); ResultSetMetaData m=rs.getMetaData(); while(rs.next()){List<Object> vals=new ArrayList<>(); for(int i=1;i<=m.getColumnCount();i++){Object x=rs.getObject(i); vals.add(x);} StringBuilder b=new StringBuilder("{"); for(int i=1;i<=m.getColumnCount();i++){if(i>1)b.append(','); String label=m.getColumnLabel(i); b.append(Json.quote(camelCase?camelCase(label):label)).append(':'); Object x=vals.get(i-1); if(x==null)b.append("null"); else if(x instanceof Number||x instanceof Boolean)b.append(x); else b.append(Json.quote(x.toString()));} out.add(b.append('}').toString());} return Json.arr(out);}}
    }
    private static String camelCase(String name){StringBuilder result=new StringBuilder();boolean uppercase=false;for(char c:name.toCharArray()){if(c=='_'){uppercase=true;}else{result.append(uppercase?Character.toUpperCase(c):c);uppercase=false;}}return result.toString();}
    private long scalarLong(String sql,Object... args)throws SQLException{try(PreparedStatement ps=connection.prepareStatement(sql)){for(int i=0;i<args.length;i++)ps.setObject(i+1,args[i]);try(ResultSet rs=ps.executeQuery()){rs.next();return rs.getLong(1);}}}
    // Marker interface avoids depending on PostgreSQL-specific Java types at compile time.
    private interface PGobjectLike {}
    public String health(){return Json.obj("status","ok","database",ok());}
    public String authenticateUser(String email)throws SQLException{
        return rowsCamel("select id,name,email,password_hash,role::text role from users where lower(email)=lower(?)",email.trim()).replaceFirst("^\\[","").replaceFirst("\\]$","");
    }
    public synchronized String registerCitizen(String name,String email,String passwordHash)throws SQLException{
        connection.setAutoCommit(false);
        try(PreparedStatement u=connection.prepareStatement("insert into users(name,email,password_hash,role) values(?,?,?,'citizen') returning id,name,email,role::text role")){
            u.setString(1,name);u.setString(2,email.toLowerCase());u.setString(3,passwordHash);
            try(ResultSet r=u.executeQuery()){r.next();int id=r.getInt(1);
                try(PreparedStatement c=connection.prepareStatement("insert into citizen_profiles(user_id) values(?) on conflict do nothing")){
                    c.setInt(1,id);c.executeUpdate();
                }
                String result=Json.obj("id",id,"name",r.getString(2),"email",r.getString(3),"role",r.getString(4));
                connection.commit();connection.setAutoCommit(true);return result;
            }
        }catch(SQLException e){connection.rollback();connection.setAutoCommit(true);throw e;}
    }
    public String departments()throws SQLException{return rowsCamel("select id,name,category,staff_count from departments order by name");}
    public String complaints(int limit)throws SQLException{return rowsCamel("select co.id,co.reference_code,co.category::text category,ci.name city,ci.name \"cityName\",di.name district,di.name \"districtName\",st.name state,st.name \"stateName\",co.locality,co.description,co.severity::text severity,co.status::text status,co.impact_score,co.urgency_score,co.reported_at,co.resolved_at,u.name citizen_name from complaints co join cities ci on ci.id=co.city_id join districts di on di.id=co.district_id join states st on st.id=di.state_id join users u on u.id=co.citizen_id order by co.reported_at desc limit ?", Math.max(1,Math.min(limit,5000)));
    }
    public String complaint(int id)throws SQLException{return rowsCamel("select co.id,co.reference_code,co.category::text category,ci.name city,ci.name \"cityName\",di.name district,di.name \"districtName\",st.name state,st.name \"stateName\",co.locality,co.description,co.severity::text severity,co.status::text status,co.impact_score,co.urgency_score,co.reported_at,co.resolved_at,u.name citizen_name from complaints co join cities ci on ci.id=co.city_id join districts di on di.id=co.district_id join states st on st.id=di.state_id join users u on u.id=co.citizen_id where co.id=?",id).replaceFirst("^\\[","").replaceFirst("\\]$","");}
    public String summary()throws SQLException{return rows("select count(*) total_complaints,count(*) filter(where status<>'resolved') active_complaints,count(*) filter(where severity='high') high_severity_count,count(*) filter(where status='resolved') resolved_count from complaints").replaceFirst("^\\[","").replaceFirst("\\]$","");}
    public String rankings(int page,int pageSize,String state,String district,String severity)throws SQLException{
        page=Math.max(1,page);pageSize=Math.max(1,Math.min(pageSize,100));int offset=(page-1)*pageSize;
        String filters=" where (?='' or state_name=?) and (?='' or district_name=?) and (?='' or ?='high' and high_severity_count>0 or ?='medium' and medium_severity_count>0 or ?='low' and low_severity_count>0)";
        Object[] filterArgs={state,state,district,district,severity,severity,severity,severity};
        String items=rowsCamel("select row_number() over(order by total_complaints desc,city_name) rank,city_name city,district_name district,state_name state,total_complaints,resolution_rate from city_rankings"+filters+" order by total_complaints desc,city_name limit ? offset ?",state,state,district,district,severity,severity,severity,severity,pageSize,offset);
        long total=scalarLong("select count(*) from city_rankings"+filters,filterArgs);
        return "{\"items\":"+items+",\"total\":"+total+",\"page\":"+page+",\"pageSize\":"+pageSize+"}";
    }
    public String states(String category)throws SQLException{String filter=category.equals("all")?"":" and co.category=?::complaint_category"; String sql="select st.name,count(co.id) total_complaints,count(co.id) filter(where co.status<>'resolved') active_complaints,count(co.id) filter(where co.status='resolved') resolved_count,count(co.id) filter(where co.severity='high') high,count(co.id) filter(where co.severity='medium') medium,count(co.id) filter(where co.severity='low') low from states st left join cities ci on ci.state_id=st.id left join complaints co on co.city_id=ci.id"+filter+" group by st.id,st.name order by st.name"; return category.equals("all")?rows(sql):rows(sql,category);}
    public String districts(String state,String category)throws SQLException{String filter=category.equals("all")?"":" and co.category=?::complaint_category"; String sql="select di.name district,st.name state,count(co.id) total_complaints,count(co.id) filter(where co.status<>'resolved') active_complaints,count(co.id) filter(where co.status='resolved') resolved_count,count(co.id) filter(where co.severity='high') high,count(co.id) filter(where co.severity='medium') medium,count(co.id) filter(where co.severity='low') low from districts di join states st on st.id=di.state_id left join complaints co on co.district_id=di.id where st.name=?"+filter+" group by di.id,di.name,st.name order by di.name"; return category.equals("all")?rows(sql,state):rows(sql,state,category);}
    public String geography()throws SQLException{return rows("select st.id state_id,st.name state,di.id district_id,di.name district,ci.id city_id,ci.name city from cities ci join districts di on di.id=ci.district_id join states st on st.id=di.state_id order by st.name,di.name,ci.name");}
    public synchronized String createComplaint(String category,int stateId,int districtId,int cityId,String locality,String description,String citizen,int impact,int urgency,int severityCode)throws SQLException{
        connection.setAutoCommit(false); try{
            int userId; try(PreparedStatement u=connection.prepareStatement("insert into users(name,email,password_hash,role) values(?,?,?,'citizen') on conflict(email) do update set name=excluded.name returning id")){u.setString(1,citizen);u.setString(2,"demo."+citizen.toLowerCase().replaceAll("[^a-z0-9]","_")+"@urban.local");u.setString(3,"demo");try(ResultSet r=u.executeQuery()){r.next();userId=r.getInt(1);}}
            try(PreparedStatement cp=connection.prepareStatement("insert into citizen_profiles(user_id) values(?) on conflict do nothing")){cp.setInt(1,userId);cp.executeUpdate();}
            String sev=severityCode>=2?"high":severityCode==1?"medium":"low";
            try(PreparedStatement p=connection.prepareStatement("insert into complaints(reference_code,category,city_id,district_id,locality,description,citizen_id,severity,impact_score,urgency_score) values(next_complaint_reference(),?::complaint_category,?,?,?,?,?,?::severity_level,?,?) returning id,reference_code,severity::text severity,status::text status")){p.setString(1,category);p.setInt(2,cityId);p.setInt(3,districtId);p.setString(4,locality);p.setString(5,description);p.setInt(6,userId);p.setString(7,sev);p.setInt(8,impact);p.setInt(9,urgency);try(ResultSet r=p.executeQuery()){r.next();String result=Json.obj("id",r.getInt(1),"referenceCode",r.getString(2),"severity",r.getString(3),"status",r.getString(4));connection.commit();connection.setAutoCommit(true);return result;}}
        }catch(SQLException e){connection.rollback();connection.setAutoCommit(true);throw e;}
    }
    public synchronized String resolveComplaint(int id)throws SQLException{return rowsCamel("update complaints set status='resolved' where id=? returning id,status::text status,resolved_at",id).replaceFirst("^\\[","").replaceFirst("\\]$","");}
    @Override public void close(){try{connection.close();}catch(Exception ignored){}}
}
