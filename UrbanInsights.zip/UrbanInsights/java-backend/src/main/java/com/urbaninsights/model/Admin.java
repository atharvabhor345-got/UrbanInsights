package com.urbaninsights.model;
public class Admin extends User {
    protected final String department;
    public Admin(int id,String name,String email,String department){super(id,name,email);this.department=department;}
    @Override public String getRole(){return "admin";}
    public String getDepartment(){return department;}
}
