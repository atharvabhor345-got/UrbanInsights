package com.urbaninsights.model;
public class Citizen extends User {
    public Citizen(int id,String name,String email){super(id,name,email);}
    @Override public String getRole(){return "citizen";}
}
