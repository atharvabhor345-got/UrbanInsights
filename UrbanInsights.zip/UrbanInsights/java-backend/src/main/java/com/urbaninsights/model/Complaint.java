package com.urbaninsights.model;

import java.time.LocalDateTime;

/** Abstract base class for real-world civic complaints. */
public abstract class Complaint {
    private static int nextId = 1000;
    private static int totalCreated = 0;

    protected final int complaintId;
    protected final String city;
    protected final String locality;
    protected String description;
    protected final String citizenName;
    protected final int impactScore;
    protected final int urgencyScore;
    protected Severity severity = Severity.UNSET;
    protected ComplaintStatus status = ComplaintStatus.PENDING;
    protected final LocalDateTime reportedAt;

    protected Complaint(String city, String locality, String description, String citizenName,
                        int impactScore, int urgencyScore) {
        if (description == null || description.isBlank())
            throw new InvalidComplaintException("Complaint description cannot be empty");
        if (impactScore < 0 || impactScore > 10 || urgencyScore < 0 || urgencyScore > 10)
            throw new InvalidComplaintException("Impact and urgency must be between 0 and 10");
        this.complaintId = nextId++;
        this.city = city;
        this.locality = locality;
        this.description = description;
        this.citizenName = citizenName == null || citizenName.isBlank() ? "Anonymous" : citizenName;
        this.impactScore = impactScore;
        this.urgencyScore = urgencyScore;
        this.reportedAt = LocalDateTime.now();
        totalCreated++;
    }

    public abstract String getCategory();
    public abstract double calculatePriorityScore();

    public final void evaluateSeverity() {
        double score = calculatePriorityScore();
        severity = score > 7 ? Severity.HIGH : score >= 4 ? Severity.MEDIUM : Severity.LOW;
    }

    public Complaint setDescription(String value) {
        if (value == null || value.isBlank()) throw new InvalidComplaintException("Description cannot be empty");
        this.description = value; return this;
    }
    public Complaint setStatus(ComplaintStatus value) { this.status = value; return this; }
    public Complaint setSeverity(Severity value) { this.severity = value; return this; }

    public int getId() { return complaintId; }
    public String getCity() { return city; }
    public String getLocality() { return locality; }
    public String getDescription() { return description; }
    public String getCitizenName() { return citizenName; }
    public int getImpactScore() { return impactScore; }
    public int getUrgencyScore() { return urgencyScore; }
    public Severity getSeverity() { return severity; }
    public ComplaintStatus getStatus() { return status; }
    public static int getTotalComplaints() { return totalCreated; }

    @Override public String toString() {
        return "Complaint{id=" + complaintId + ", category=" + getCategory() + ", city=" + city +
                ", severity=" + severity + ", status=" + status + "}";
    }

    public enum Severity { LOW, MEDIUM, HIGH, UNSET }
    public enum ComplaintStatus { PENDING, ASSIGNED, IN_PROGRESS, RESOLVED }
}
