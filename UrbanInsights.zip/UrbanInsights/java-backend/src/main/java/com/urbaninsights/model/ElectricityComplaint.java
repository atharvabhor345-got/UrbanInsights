package com.urbaninsights.model;

public class ElectricityComplaint extends Complaint {
    public ElectricityComplaint(String city, String locality, String description, String citizenName, int impact, int urgency) {
        super(city, locality, description, citizenName, impact, urgency);
    }
    @Override public String getCategory() { return "Electricity"; }
    @Override public double calculatePriorityScore() {
        return (impactScore * 7.0 + urgencyScore * 3.0) / 10.0;
    }
}
