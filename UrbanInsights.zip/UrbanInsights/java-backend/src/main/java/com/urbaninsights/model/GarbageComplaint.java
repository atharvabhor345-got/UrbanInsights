package com.urbaninsights.model;

public class GarbageComplaint extends Complaint {
    public GarbageComplaint(String city, String locality, String description, String citizenName, int impact, int urgency) {
        super(city, locality, description, citizenName, impact, urgency);
    }
    @Override public String getCategory() { return "Garbage"; }
    @Override public double calculatePriorityScore() {
        return (impactScore * 5.0 + urgencyScore * 5.0) / 10.0;
    }
}
