package com.urbaninsights.model;
public class InvalidComplaintException extends RuntimeException {
    public InvalidComplaintException(String message) { super(message); }
}
