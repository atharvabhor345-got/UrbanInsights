package com.urbaninsights.model;
public class SuperAdmin extends Admin {
    public SuperAdmin(int id,String name,String email){super(id,name,email,"All Departments");}
    @Override public String getRole(){return "super_admin";}
}
