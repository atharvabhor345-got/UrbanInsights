package com.urbaninsights.model;

public class TrafficComplaint extends Complaint {
    public TrafficComplaint(String city, String locality, String description, String citizenName, int impact, int urgency) {
        super(city, locality, description, citizenName, impact, urgency);
    }
    @Override public String getCategory() { return "Traffic"; }
    @Override public double calculatePriorityScore() {
        return (impactScore * 6.0 + urgencyScore * 4.0) / 10.0;
    }
}
