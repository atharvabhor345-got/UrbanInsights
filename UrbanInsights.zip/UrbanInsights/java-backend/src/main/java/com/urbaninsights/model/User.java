package com.urbaninsights.model;
public abstract class User {
    protected final int id; protected final String name; protected final String email;
    protected User(int id, String name, String email) { this.id=id; this.name=name; this.email=email; }
    public abstract String getRole();
    public int getId(){return id;} public String getName(){return name;} public String getEmail(){return email;}
}
