package com.urbaninsights.model;

public class WaterComplaint extends Complaint {
    public WaterComplaint(String city, String locality, String description, String citizenName, int impact, int urgency) {
        super(city, locality, description, citizenName, impact, urgency);
    }
    @Override public String getCategory() { return "Water"; }
    @Override public double calculatePriorityScore() {
        return (impactScore * 65.0 + urgencyScore * 35.0) / 100.0;
    }
}
