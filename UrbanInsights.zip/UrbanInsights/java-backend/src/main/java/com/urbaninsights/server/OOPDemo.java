package com.urbaninsights.server;
import com.urbaninsights.model.*;
public class OOPDemo { public static void main(String[] a){ Complaint[] c={new TrafficComplaint("Pune","Alandi Road","Pothole","Atharva",8,7),new WaterComplaint("Pune","Akurdi","Leakage","Atharva",6,8)}; for(Complaint x:c){x.evaluateSeverity();System.out.println(x);System.out.println("Priority="+x.calculatePriorityScore());} System.out.println("Total objects="+Complaint.getTotalComplaints()); } }
