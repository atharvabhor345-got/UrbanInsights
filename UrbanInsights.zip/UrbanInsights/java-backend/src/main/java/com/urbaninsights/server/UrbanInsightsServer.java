package com.urbaninsights.server;

import com.sun.net.httpserver.*;
import com.urbaninsights.db.DatabaseManager;
import com.urbaninsights.model.*;
import com.urbaninsights.util.Json;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.nio.file.*; import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.security.MessageDigest;

public class UrbanInsightsServer {
  private static DatabaseManager db;
  private static final Map<String,Map<String,Object>> sessions=new HashMap<>();
  private static final ComplaintTriageService complaintTriage=new ComplaintTriageService();
  private static final int PASSWORD_ITERATIONS=120000;
  public static void main(String[] args) throws Exception {
    int port=Integer.parseInt(System.getenv().getOrDefault("PORT","8080"));
    try { db=new DatabaseManager(); System.out.println("PostgreSQL: connected"); } catch(Exception e){ System.out.println("PostgreSQL: unavailable - "+e.getMessage()); db=null; }
    HttpServer s=HttpServer.create(new InetSocketAddress("0.0.0.0",port),0); s.createContext("/api/",UrbanInsightsServer::api); s.createContext("/",UrbanInsightsServer::staticFiles); s.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(8)); s.start();
    System.out.println("Urban Insights Java server: http://localhost:"+port);
  }
  static void api(HttpExchange ex) throws IOException {
    ex.getResponseHeaders().set("Access-Control-Allow-Headers","Content-Type");
    ex.getResponseHeaders().set("Access-Control-Allow-Methods","GET, POST, OPTIONS");
    if("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())){ex.sendResponseHeaders(204,-1);ex.getResponseBody().close();return;}
    String p=ex.getRequestURI().getPath(); try {
      if(p.equals("/api/health")){send(ex,200,db==null?Json.obj("status","ok","database",false):db.health());return;}
      if(db==null){send(ex,503,Json.obj("error","database unavailable"));return;}
      if(p.equals("/api/auth/register")){register(ex);return;}
      if(p.equals("/api/auth/login")){login(ex);return;}
      if(p.equals("/api/auth/me")){me(ex);return;}
      if(p.equals("/api/auth/logout")){logout(ex);return;}
      if(p.equals("/api/ai/triage")){
        if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){send(ex,405,Json.obj("error","method not allowed"));return;}
        if(sessionUser(ex)==null){send(ex,401,Json.obj("error","Sign in to get an AI suggestion"));return;}
        if(!complaintTriage.isConfigured()){send(ex,503,Json.obj("error","AI suggestions are not configured on this server"));return;}
        byte[] body=ex.getRequestBody().readNBytes(5001);
        if(body.length>5000){send(ex,413,Json.obj("error","Complaint description is too long"));return;}
        Map<String,String> input=parseFlatJson(new String(body,StandardCharsets.UTF_8));
        String description=input.getOrDefault("description","").trim();
        if(description.length()<8||description.length()>3000){send(ex,400,Json.obj("error","Enter a description between 8 and 3000 characters"));return;}
        ComplaintTriageService.Suggestion suggestion=complaintTriage.suggest(description);
        send(ex,200,Json.obj("category",suggestion.category(),"impactScore",suggestion.impactScore(),"urgencyScore",suggestion.urgencyScore(),"reason",suggestion.reason()));
        return;
      }
      if(p.equals("/api/departments")){send(ex,200,db.departments());return;}
      if(p.equals("/api/complaints")){ if("POST".equalsIgnoreCase(ex.getRequestMethod())){create(ex);return;} send(ex,200,db.complaints(Integer.parseInt(query(ex,"limit","50"))));return; }
      if(p.matches("/api/complaints/\\d+/resolve")){
        if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){send(ex,405,Json.obj("error","method not allowed"));return;}
        Map<String,Object> user=sessionUser(ex);
        String role=user==null?"":String.valueOf(user.get("role"));
        if(!role.equals("admin")&&!role.equals("super_admin")){send(ex,403,Json.obj("error","Administrator access required"));return;}
        int id=Integer.parseInt(p.substring("/api/complaints/".length(),p.length()-"/resolve".length()));
        String result=db.resolveComplaint(id);
        send(ex,result.isEmpty()?404:200,result.isEmpty()?Json.obj("error","not found"):result);
        return;
      }
      if(p.matches("/api/complaints/\\d+")){int id=Integer.parseInt(p.substring(p.lastIndexOf('/')+1));String v=db.complaint(id);send(ex,v.equals("")?404:200,v.equals("")?Json.obj("error","not found"):v);return;}
      if(p.equals("/api/dashboard/summary")){send(ex,200,db.summary());return;}
      if(p.equals("/api/states")){send(ex,200,db.states(query(ex,"category","all")));return;}
      if(p.equals("/api/map/districts")){send(ex,200,db.districts(query(ex,"state",""),query(ex,"category","all")));return;}
      if(p.equals("/api/geography")){send(ex,200,db.geography());return;}
      if(p.equals("/api/rankings/cities")){send(ex,200,db.rankings(Integer.parseInt(query(ex,"page","1")),Integer.parseInt(query(ex,"pageSize","25")),query(ex,"state",""),query(ex,"district",""),query(ex,"severity","")));return;}
      if(p.equals("/api/complaints/export")){send(ex,200,"id,reference_code,category,city,severity,status\n", "text/csv");return;}
      send(ex,404,Json.obj("error","not found"));
    } catch(Exception e){send(ex,500,Json.obj("error",e.getMessage()));}
  }
  static void register(HttpExchange ex)throws Exception{
    if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){send(ex,405,Json.obj("error","method not allowed"));return;}
    Map<String,String> m=parseFlatJson(new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));
    String name=m.getOrDefault("name","").trim(),email=m.getOrDefault("email","").trim().toLowerCase(),password=m.getOrDefault("password","");
    if(name.length()<2||email.length()<3||password.length()<8){send(ex,400,Json.obj("error","Name, email and a password of at least 8 characters are required"));return;}
    try{
      String user=db.registerCitizen(name,email,hashPassword(password));
      send(ex,201,user);
    }catch(java.sql.SQLException e){
      if(e.getMessage()!=null&&e.getMessage().toLowerCase().contains("duplicate"))send(ex,409,Json.obj("error","An account with this email already exists"));
      else throw e;
    }
  }
  static void login(HttpExchange ex)throws Exception{
    if(!"POST".equalsIgnoreCase(ex.getRequestMethod())){send(ex,405,Json.obj("error","method not allowed"));return;}
    Map<String,String> m=parseFlatJson(new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8));
    String email=m.getOrDefault("email","").trim(),password=m.getOrDefault("password","");
    String record=db.authenticateUser(email);
    if(record.isEmpty()){send(ex,401,Json.obj("error","Invalid email or password"));return;}
    Object parsed=Json.parse(record);
    if(!(parsed instanceof Map<?,?> u)){send(ex,401,Json.obj("error","Invalid email or password"));return;}
    String stored=String.valueOf(u.get("passwordHash"));
    if(!verifyPassword(password,stored)){send(ex,401,Json.obj("error","Invalid email or password"));return;}
    String token=UUID.randomUUID().toString();
    Map<String,Object> session=new HashMap<>();
    session.put("id",u.get("id"));session.put("name",u.get("name"));session.put("email",u.get("email"));session.put("role",u.get("role"));
    sessions.put(token,session);
    ex.getResponseHeaders().set("Set-Cookie","urban_session="+token+"; Path=/; HttpOnly; SameSite=Lax");
    send(ex,200,Json.obj("id",((Number)u.get("id")).intValue(),"name",String.valueOf(u.get("name")),"email",String.valueOf(u.get("email")),"role",String.valueOf(u.get("role"))));
  }
  static void me(HttpExchange ex)throws Exception{
    Map<String,Object> user=sessionUser(ex);
    if(user==null){send(ex,401,Json.obj("error","Not logged in"));return;}
    send(ex,200,Json.obj("id",((Number)user.get("id")).intValue(),"name",String.valueOf(user.get("name")),"email",String.valueOf(user.get("email")),"role",String.valueOf(user.get("role"))));
  }
  static void logout(HttpExchange ex)throws Exception{
    String token=cookie(ex,"urban_session");if(token!=null)sessions.remove(token);
    ex.getResponseHeaders().set("Set-Cookie","urban_session=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax");
    send(ex,200,Json.obj("ok",true));
  }
  static Map<String,Object> sessionUser(HttpExchange ex){
    String token=cookie(ex,"urban_session");return token==null?null:sessions.get(token);
  }
  static String cookie(HttpExchange ex,String name){
    List<String> cookies=ex.getRequestHeaders().get("Cookie");if(cookies==null)return null;
    for(String header:cookies)for(String part:header.split(";")){String[] kv=part.trim().split("=",2);if(kv.length==2&&kv[0].equals(name))return kv[1];}return null;
  }
  static String hashPassword(String password)throws Exception{
    byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);
    byte[] hash=pbkdf2(password,salt,PASSWORD_ITERATIONS);
    return "pbkdf2_sha256$"+PASSWORD_ITERATIONS+"$"+hex(salt)+"$"+hex(hash);
  }
  static boolean verifyPassword(String password,String stored){
    try{
      String[] p=stored.split("\\$");
      if(p.length==3&&p[0].equals("pbkdf2_sha256"))return MessageDigest.isEqual(pbkdf2(password,hexBytes(p[1]),120000),hexBytes(p[2]));
      if(p.length==4&&p[0].equals("pbkdf2_sha256"))return MessageDigest.isEqual(pbkdf2(password,hexBytes(p[2]),Integer.parseInt(p[1])),hexBytes(p[3]));
    }catch(Exception ignored){}
    return false;
  }
  static byte[] pbkdf2(String password,byte[] salt,int iterations)throws Exception{
    PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,iterations,256);
    return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
  }
  static String hex(byte[] data){StringBuilder b=new StringBuilder();for(byte v:data)b.append(String.format("%02x",v));return b.toString();}
  static byte[] hexBytes(String s){byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b;}
  static void create(HttpExchange ex)throws Exception{
    String body=new String(ex.getRequestBody().readAllBytes(),StandardCharsets.UTF_8); Map<String,String> m=parseFlatJson(body);
    String category=m.getOrDefault("category","").toLowerCase(); if(category.equals("road"))category="traffic";
    int state=Integer.parseInt(m.getOrDefault("stateId","0")),district=Integer.parseInt(m.getOrDefault("districtId","0")),city=Integer.parseInt(m.getOrDefault("cityId","0"));
    int impact=Integer.parseInt(m.getOrDefault("impactScore","5")),urgency=Integer.parseInt(m.getOrDefault("urgencyScore","5")); String locality=m.getOrDefault("locality","");String desc=m.getOrDefault("description","");String citizen=m.getOrDefault("citizenName","Anonymous");
    Complaint c=switch(category){case "traffic"->new TrafficComplaint("",locality,desc,citizen,impact,urgency);case "garbage"->new GarbageComplaint("",locality,desc,citizen,impact,urgency);case "electricity"->new ElectricityComplaint("",locality,desc,citizen,impact,urgency);case "water"->new WaterComplaint("",locality,desc,citizen,impact,urgency);default->throw new InvalidComplaintException("Invalid category");}; c.evaluateSeverity(); int sev=c.getSeverity()==Complaint.Severity.HIGH?2:c.getSeverity()==Complaint.Severity.MEDIUM?1:0;
    send(ex,201,db.createComplaint(category,state,district,city,locality,desc,citizen,impact,urgency,sev));
  }
  static Map<String,String> parseFlatJson(String s){Object value=Json.parse(s);if(!(value instanceof Map<?,?> object))throw new IllegalArgumentException("Expected a JSON object");Map<String,String> result=new HashMap<>();for(Map.Entry<?,?> entry:object.entrySet()){if(!(entry.getKey() instanceof String key))throw new IllegalArgumentException("Invalid JSON object key");Object item=entry.getValue();if(item==null)result.put(key,"");else if(item instanceof String||item instanceof Number||item instanceof Boolean)result.put(key,String.valueOf(item));else throw new IllegalArgumentException("Complaint fields must be scalar values");}return result;}
  static String query(HttpExchange e,String k,String d){String q=e.getRequestURI().getRawQuery();if(q==null)return d;for(String a:q.split("&")){String[] z=a.split("=",2);if(z.length==2&&URLDecoder.decode(z[0],StandardCharsets.UTF_8).equals(k))return URLDecoder.decode(z[1],StandardCharsets.UTF_8);}return d;}
  static void send(HttpExchange e,int code,String body)throws IOException{send(e,code,body,"application/json; charset=utf-8");}
  static void send(HttpExchange e,int code,String body,String type)throws IOException{byte[] b=body.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type",type);e.getResponseHeaders().set("Access-Control-Allow-Origin",System.getenv().getOrDefault("URBAN_INSIGHTS_ORIGIN","http://localhost:8080"));e.sendResponseHeaders(code,b.length);try(OutputStream o=e.getResponseBody()){o.write(b);}}
  static void staticFiles(HttpExchange e)throws IOException{String p=e.getRequestURI().getPath();if(p.equals("/"))p="/index.html";Path projectRoot=Paths.get("").toAbsolutePath().normalize();if(!Files.isDirectory(projectRoot.resolve("frontend")))projectRoot=projectRoot.getParent();Path root=p.startsWith("/opengl/")?projectRoot.resolve("opengl"):projectRoot.resolve("frontend");String relative=p.startsWith("/opengl/")?p.substring("/opengl/".length()):p.substring(1);Path f=root.resolve(relative).normalize();if(!f.startsWith(root)||!Files.exists(f)||Files.isDirectory(f)){send(e,404,"Not found","text/plain");return;}String ct=Files.probeContentType(f);if(ct==null)ct="application/octet-stream";byte[] b=Files.readAllBytes(f);e.getResponseHeaders().set("Content-Type",ct);e.sendResponseHeaders(200,b.length);try(OutputStream o=e.getResponseBody()){o.write(b);}}
}
