package com.urbaninsights.util;
import java.util.*;
public final class Json {
    private Json(){}
    public static String quote(String s){
        if(s==null)return "null"; StringBuilder b=new StringBuilder("\"");
        for(char c:s.toCharArray()){ switch(c){case '\\'->b.append("\\\\");case '"'->b.append("\\\"");case '\b'->b.append("\\b");case '\f'->b.append("\\f");case '\n'->b.append("\\n");case '\r'->b.append("\\r");case '\t'->b.append("\\t");default->{if(c<0x20)b.append(String.format("\\u%04x",(int)c));else b.append(c);}} } return b.append('"').toString();
    }
    public static String obj(Object... kv){StringBuilder b=new StringBuilder("{"); for(int i=0;i<kv.length;i+=2){if(i>0)b.append(','); b.append(quote(String.valueOf(kv[i]))).append(':').append(value(kv[i+1]));} return b.append('}').toString();}
    public static String arr(List<String> items){return "["+String.join(",",items)+"]";}
    public static String value(Object v){if(v==null)return "null"; if(v instanceof Number||v instanceof Boolean)return v.toString(); return quote(String.valueOf(v));}
    public static Object parse(String json){Parser parser=new Parser(json);Object value=parser.value();parser.whitespace();if(!parser.finished())throw parser.error("Unexpected trailing content");return value;}

    private static final class Parser {
        private final String input;
        private int index;
        private Parser(String input){this.input=Objects.requireNonNull(input);}
        private boolean finished(){return index==input.length();}
        private void whitespace(){while(index<input.length()&&Character.isWhitespace(input.charAt(index)))index++;}
        private IllegalArgumentException error(String message){return new IllegalArgumentException(message+" at character "+index);}
        private char take(){if(finished())throw error("Unexpected end of JSON");return input.charAt(index++);}
        private boolean consume(char expected){if(!finished()&&input.charAt(index)==expected){index++;return true;}return false;}
        private Object value(){
            whitespace();if(finished())throw error("Expected a JSON value");
            return switch(input.charAt(index)){
                case '{'->object();
                case '['->array();
                case '"'->string();
                case 't'->{literal("true");yield Boolean.TRUE;}
                case 'f'->{literal("false");yield Boolean.FALSE;}
                case 'n'->{literal("null");yield null;}
                default->number();
            };
        }
        private Map<String,Object> object(){
            take();whitespace();Map<String,Object> result=new LinkedHashMap<>();if(consume('}'))return result;
            while(true){whitespace();if(finished()||input.charAt(index)!='"')throw error("Expected an object key");String key=string();whitespace();if(!consume(':'))throw error("Expected ':'");result.put(key,value());whitespace();if(consume('}'))return result;if(!consume(','))throw error("Expected ',' or '}'");}
        }
        private List<Object> array(){
            take();whitespace();List<Object> result=new ArrayList<>();if(consume(']'))return result;
            while(true){result.add(value());whitespace();if(consume(']'))return result;if(!consume(','))throw error("Expected ',' or ']'");}
        }
        private String string(){
            if(take()!='"')throw error("Expected a string");StringBuilder result=new StringBuilder();
            while(!finished()){char c=take();if(c=='"')return result.toString();if(c<0x20)throw error("Unescaped control character");if(c!='\\'){result.append(c);continue;}char escaped=take();switch(escaped){case '"','\\','/'->result.append(escaped);case 'b'->result.append('\b');case 'f'->result.append('\f');case 'n'->result.append('\n');case 'r'->result.append('\r');case 't'->result.append('\t');case 'u'->{if(index+4>input.length())throw error("Incomplete Unicode escape");try{result.append((char)Integer.parseInt(input.substring(index,index+4),16));}catch(NumberFormatException e){throw error("Invalid Unicode escape");}index+=4;}default->throw error("Invalid escape sequence");}}
            throw error("Unterminated string");
        }
        private void literal(String expected){if(!input.startsWith(expected,index))throw error("Invalid JSON value");index+=expected.length();}
        private Number number(){
            int start=index;if(consume('-')&&finished())throw error("Invalid number");
            if(consume('0')){if(!finished()&&Character.isDigit(input.charAt(index)))throw error("Leading zero in number");}
            else{if(finished()||input.charAt(index)<'1'||input.charAt(index)>'9')throw error("Invalid JSON value");while(!finished()&&Character.isDigit(input.charAt(index)))index++;}
            boolean decimal=false;if(consume('.')){decimal=true;if(finished()||!Character.isDigit(input.charAt(index)))throw error("Invalid fraction");while(!finished()&&Character.isDigit(input.charAt(index)))index++;}
            if(!finished()&&(input.charAt(index)=='e'||input.charAt(index)=='E')){decimal=true;index++;if(!finished()&&(input.charAt(index)=='+'||input.charAt(index)=='-'))index++;if(finished()||!Character.isDigit(input.charAt(index)))throw error("Invalid exponent");while(!finished()&&Character.isDigit(input.charAt(index)))index++;}
            String token=input.substring(start,index);try{if(decimal)return Double.valueOf(token);return Long.valueOf(token);}catch(NumberFormatException e){throw error("Invalid number");}
        }
    }
}
