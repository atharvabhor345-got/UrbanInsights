#include "Complaint.h"
#include "Exceptions.h"

#include <utility>
#include <ctime>
#include <sstream>
#include <iomanip>
using namespace std;
// The real severity classifier now lives in assembly/severity.asm -
// see docs/ASSEMBLY_CONCEPTS_MAP.md for the full writeup. This is a
// deliberately tiny surface: one function, ints in, an int out.
extern "C" int calculateSeverityAsm(int category, int impactScore, int urgencyScore);

// Maps a category string to the integer code severity.asm expects.
// Kept here (not in the header) since it's an implementation detail
// of how Complaint talks to the assembly module, not part of the
// public interface.
static int categoryToAsmCode(const  string& category) {
    if (category == "Traffic")     return 0;
    if (category == "Garbage")     return 1;
    if (category == "Electricity") return 2;
    return 3; // "Water", and the default for anything unrecognised
}

int Complaint::nextId = 1000;
int Complaint::totalCreated = 0;

// ---------------------------------------------------------------
// helpers
// ---------------------------------------------------------------

 string severityToString(Severity s) {
    switch (s) {
        case Severity::LOW:    return "Low";
        case Severity::MEDIUM: return "Medium";
        case Severity::HIGH:   return "High";
        default:                return "Unset";
    }
}

 string statusToString(ComplaintStatus s) {
    switch (s) {
        case ComplaintStatus::PENDING:     return "Pending";
        case ComplaintStatus::ASSIGNED:    return "Assigned";
        case ComplaintStatus::IN_PROGRESS: return "In Progress";
        case ComplaintStatus::RESOLVED:    return "Resolved";
    }
    return "Unknown";
}

static  string currentTimestamp() {
     time_t t =  time(nullptr);
     tm tmBuf{};
#if defined(_WIN32)
    localtime_s(&tmBuf, &t);
#else
    localtime_r(&t, &tmBuf);
#endif
     ostringstream oss;
    oss <<  put_time(&tmBuf, "%Y-%m-%d %H:%M");
    return oss.str();
}

// ---------------------------------------------------------------
// Practical 02: constructors, copy/move assignment, destructor
// ---------------------------------------------------------------

Complaint::Complaint()
    : complaintId(nextId++), category("Unspecified"), city("Unspecified"),
      locality(""), description(""), citizenName("Anonymous"),
      reportedAt(currentTimestamp()), assignedDepartment(""),
      severity(Severity::UNSET), status(ComplaintStatus::PENDING),
      impactScore(0), urgencyScore(0) {
    totalCreated++;
}

Complaint::Complaint( string category,  string city,  string locality,
                       string description,  string citizenName,
                      int impactScore, int urgencyScore)
    : complaintId(nextId++), category( move(category)), city( move(city)),
      locality( move(locality)), description( move(description)),
      citizenName( move(citizenName)), reportedAt(currentTimestamp()),
      assignedDepartment(""), severity(Severity::UNSET), status(ComplaintStatus::PENDING),
      impactScore(impactScore), urgencyScore(urgencyScore) {

    if (this->description.empty()) {
        throw InvalidComplaintException(
            "Complaint description cannot be empty (id " +  to_string(complaintId) + ")");
    }
    totalCreated++;
}

Complaint::Complaint(const Complaint& other)
    : complaintId(nextId++),   // a copy is still a distinct report -> gets a fresh id
      category(other.category), city(other.city), locality(other.locality),
      description(other.description), citizenName(other.citizenName),
      reportedAt(other.reportedAt), assignedDepartment(other.assignedDepartment),
      severity(other.severity), status(other.status),
      impactScore(other.impactScore), urgencyScore(other.urgencyScore) {
    totalCreated++;
}

Complaint::Complaint(Complaint&& other) noexcept
    : complaintId(other.complaintId),
      category( move(other.category)), city( move(other.city)),
      locality( move(other.locality)), description( move(other.description)),
      citizenName( move(other.citizenName)), reportedAt( move(other.reportedAt)),
      assignedDepartment( move(other.assignedDepartment)),
      severity(other.severity), status(other.status),
      impactScore(other.impactScore), urgencyScore(other.urgencyScore) {
    other.complaintId = -1; // leave the moved-from object in a valid, empty state
}

Complaint& Complaint::operator=(const Complaint& other) {
    if (this == &other) return *this;
    category = other.category;
    city = other.city;
    locality = other.locality;
    description = other.description;
    citizenName = other.citizenName;
    reportedAt = other.reportedAt;
    assignedDepartment = other.assignedDepartment;
    severity = other.severity;
    status = other.status;
    impactScore = other.impactScore;
    urgencyScore = other.urgencyScore;
    return *this;
}

Complaint& Complaint::operator=(Complaint&& other) noexcept {
    if (this == &other) return *this;
    category =  move(other.category);
    city =  move(other.city);
    locality =  move(other.locality);
    description =  move(other.description);
    citizenName =  move(other.citizenName);
    reportedAt =  move(other.reportedAt);
    assignedDepartment =  move(other.assignedDepartment);
    severity = other.severity;
    status = other.status;
    impactScore = other.impactScore;
    urgencyScore = other.urgencyScore;
    other.complaintId = -1;
    return *this;
}

Complaint::~Complaint() {
    //  string cleans up after itself; this destructor still needs to
    // exist (and be virtual) so that `delete` through a Complaint* runs
    // the correct derived-class teardown - Practical 01.
}

// ---------------------------------------------------------------
// Practical 05: this pointer, static member function
// ---------------------------------------------------------------

Complaint& Complaint::setDescription(const  string& desc) {
    this->description = desc;
    return *this;
}

Complaint& Complaint::setStatus(ComplaintStatus s) {
    this->status = s;
    return *this;
}

Complaint& Complaint::setSeverity(Severity s) {
    this->severity = s;
    return *this;
}

int Complaint::getTotalComplaints() {
    return totalCreated;
}

// ---------------------------------------------------------------
// Practical 07: polymorphism support
// ---------------------------------------------------------------

void Complaint::displayDetails() const {
     cout << *this;
}

void Complaint::evaluateSeverity() {
    // calculatePriorityScore() (virtual, per-category) still exists for
    // fine-grained ranking/sorting - see operator< and dsa/Sorting.cpp.
    // The authoritative Low/Medium/High classification now comes from
    // the real assembly module instead of a C++ threshold check:
    int code = calculateSeverityAsm(categoryToAsmCode(category), impactScore, urgencyScore);
    switch (code) {
        case 2:  severity = Severity::HIGH;   break;
        case 1:  severity = Severity::MEDIUM; break;
        default: severity = Severity::LOW;    break;
    }
}

// ---------------------------------------------------------------
// Practical 03: operator overloading
// ---------------------------------------------------------------

bool Complaint::operator==(const Complaint& other) const {
    return complaintId == other.complaintId;
}

bool Complaint::operator<(const Complaint& other) const {
    return calculatePriorityScore() < other.calculatePriorityScore();
}

 ostream& operator<<( ostream& os, const Complaint& c) {
    os << "[#" << c.complaintId << "] " << c.getCategoryLabel()
       << " - " << c.description
       << " | " << c.locality << ", " << c.city
       << " | severity: " << severityToString(c.severity)
       << " | status: " << statusToString(c.status);
    return os;
}

// ---------------------------------------------------------------
// Practical 06 + 07: derived issue types (hierarchical inheritance)
// ---------------------------------------------------------------

TrafficComplaint::TrafficComplaint( string city,  string locality,  string description,
                                     string citizenName, int impactScore, int urgencyScore)
    : Complaint("Traffic",  move(city),  move(locality),  move(description),
                 move(citizenName), impactScore, urgencyScore) {}

double TrafficComplaint::calculatePriorityScore() const {
    // A continuous priority score for fine-grained ranking/sorting
    // (operator<, dsa/Sorting.cpp) - kept in floating point on purpose,
    // separate from the discrete Low/Medium/High classification, which
    // is computed with integer arithmetic over in assembly/severity.asm.
    return impactScore * 0.6 + urgencyScore * 0.4;
}

 string TrafficComplaint::getCategoryLabel() const { return "Traffic / Road"; }


GarbageComplaint::GarbageComplaint( string city,  string locality,  string description,
                                     string citizenName, int impactScore, int urgencyScore)
    : Complaint("Garbage",  move(city),  move(locality),  move(description),
                 move(citizenName), impactScore, urgencyScore) {}

double GarbageComplaint::calculatePriorityScore() const {
    return impactScore * 0.5 + urgencyScore * 0.5;
}

 string GarbageComplaint::getCategoryLabel() const { return "Garbage"; }


ElectricityComplaint::ElectricityComplaint( string city,  string locality,  string description,
                                             string citizenName, int impactScore, int urgencyScore)
    : Complaint("Electricity",  move(city),  move(locality),  move(description),
                 move(citizenName), impactScore, urgencyScore) {}

double ElectricityComplaint::calculatePriorityScore() const {
    return impactScore * 0.7 + urgencyScore * 0.3;
}

 string ElectricityComplaint::getCategoryLabel() const { return "Electricity"; }


WaterComplaint::WaterComplaint( string city,  string locality,  string description,
                                 string citizenName, int impactScore, int urgencyScore)
    : Complaint("Water",  move(city),  move(locality),  move(description),
                 move(citizenName), impactScore, urgencyScore) {}

double WaterComplaint::calculatePriorityScore() const {
    return impactScore * 0.65 + urgencyScore * 0.35;
}

 string WaterComplaint::getCategoryLabel() const { return "Water"; }
