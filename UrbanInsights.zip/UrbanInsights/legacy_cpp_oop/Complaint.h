#ifndef COMPLAINT_H
#define COMPLAINT_H

/*
    ================================================================
    URBAN INSIGHTS -- Complaint.h
    ================================================================
    The OOP core of the project. Complaint is an abstract base class;
    TrafficComplaint / GarbageComplaint / ElectricityComplaint /
    WaterComplaint are the four concrete issue types from the plan.

    Maps to the Integrated Review course outcomes:
        CO1 - real-world entity modeled as a class
        CO2 - Encapsulation / Inheritance / Polymorphism / Abstraction
        CO3 - each issue type is its own class, polymorphism at work
        CO4 - full complaint lifecycle organised with reusable logic

    And to the OOP lab practicals (full table in
    docs/OOP_PRACTICALS_MAP.md):
        01  class & objects, constructor, destructor, user-defined fns
        02  constructor types (default / parameterised / copy)
        03  operator overloading (==, <, <<)
        05  this pointer, inline function, static member, friend class
        06  inheritance (hierarchical - the 4 classes below)
        07  polymorphism (pure virtual, overridden per type)
        08  exception handling (throws InvalidComplaintException)
        09  move semantics (move constructor / move assignment)
    ================================================================
*/

#include <string>
#include <iostream>
using namespace std;
// ---------------------------------------------------------------
// Shared enums + helpers
// ---------------------------------------------------------------

enum class Severity        { LOW, MEDIUM, HIGH, UNSET };
enum class ComplaintStatus { PENDING, ASSIGNED, IN_PROGRESS, RESOLVED };

 string severityToString(Severity s);
 string statusToString(ComplaintStatus s);

class Department; // forward declaration, needed for the friend declaration below

// ---------------------------------------------------------------
// Complaint - abstract base class
// ---------------------------------------------------------------

class Complaint {

protected:
    int complaintId;
    string  category;            // "Traffic" | "Garbage" | "Electricity" | "Water"
    string  city;
    string  locality;
    string  description;
    string  citizenName;
    string  reportedAt;
    string  assignedDepartment;  // only Department may set this directly (friend)
    Severity        severity;
    ComplaintStatus status;

    int impactScore;    // 0-10, later fed to the Assembly severity engine
    int urgencyScore;   // 0-10

    static int nextId;        // Practical 05 - static data member
    static int totalCreated;  // Practical 05 - static counter

public:
    // ---- Practical 02: constructor types ----
    Complaint();                                                     // default constructor
    Complaint( string category, string city, string locality,
              string description, string citizenName,
              int impactScore = 5, int urgencyScore = 5);            // parameterised constructor
    Complaint(const Complaint& other);                                // copy constructor
    Complaint(Complaint&& other) noexcept;                            // Practical 09 - move constructor

    Complaint& operator=(const Complaint& other);                     // copy assignment
    Complaint& operator=(Complaint&& other) noexcept;                 // Practical 09 - move assignment

    virtual ~Complaint();                                             // Practical 01 - virtual destructor

    // ---- Practical 05: 'this' pointer, chainable setters ----
    Complaint& setDescription(const string& desc);
    Complaint& setStatus(ComplaintStatus s);
    Complaint& setSeverity(Severity s);

    // ---- Practical 05: inline functions ----
    inline int getId() const { return complaintId; }
    inline const string& getCategory() const { return category; }
    inline const string& getCity() const { return city; }
    inline const string& getLocality() const { return locality; }
    inline const string& getDescription() const { return description; }
    inline const string& getCitizenName() const { return citizenName; }
    inline const string& getAssignedDepartment() const { return assignedDepartment; }
    inline Severity getSeverity() const { return severity; }
    inline ComplaintStatus getStatus() const { return status; }
    inline int getImpactScore() const { return impactScore; }
    inline int getUrgencyScore() const { return urgencyScore; }

    // ---- Practical 05: static member function ----
    static int getTotalComplaints();

    // ---- Practical 07: polymorphism / abstraction (CO4) ----
    virtual double calculatePriorityScore() const = 0;
    virtual string getCategoryLabel() const = 0;
    virtual void displayDetails() const;

    // Classifies this complaint as Low/Medium/High by calling the real
    // assembly module (assembly/severity.asm), passing category and the
    // impact/urgency scores below. Deliberately NOT called from the
    // constructor: category isn't fully known to a virtual dispatch at
    // that point (a virtual call made during base-class construction
    // cannot reach a derived override yet), so this runs afterwards
    // instead - see main.cpp.
    void evaluateSeverity();

    // ---- Practical 03: operator overloading ----
    bool operator==(const Complaint& other) const;  // compares identity (id)
    bool operator<(const Complaint& other) const;   // compares priority score

    friend ostream& operator<<( ostream& os, const Complaint& c);

    // ---- Practical 05: friend class ----
    // Department needs to set assignedDepartment directly when it takes a
    // complaint, bypassing the normal public interface - a textbook
    // reason to grant `friend` access instead of adding a public setter
    // that anyone could call.
    friend class Department;
};

// ---------------------------------------------------------------
// Practical 06: hierarchical inheritance - four concrete issue types
// Practical 07: each overrides calculatePriorityScore() differently
// ---------------------------------------------------------------

class TrafficComplaint : public Complaint {
public:
    TrafficComplaint( string city, string locality, string description,
                      string citizenName, int impactScore = 5, int urgencyScore = 5);
    double calculatePriorityScore() const override;
    string getCategoryLabel() const override;
};

class GarbageComplaint : public Complaint {
public:
    GarbageComplaint( string city, string locality, string description,
                      string citizenName, int impactScore = 5, int urgencyScore = 5);
    double calculatePriorityScore() const override;
    string getCategoryLabel() const override;
};

class ElectricityComplaint : public Complaint {
public:
    ElectricityComplaint( string city, string locality, string description,
                          string citizenName, int impactScore = 5, int urgencyScore = 5);
    double calculatePriorityScore() const override;
    string getCategoryLabel() const override;
};

class WaterComplaint : public Complaint {
public:
    WaterComplaint( string city, string locality, string description,
                    string citizenName, int impactScore = 5, int urgencyScore = 5);
    double calculatePriorityScore() const override;
    string getCategoryLabel() const override;
};

#endif // COMPLAINT_H
