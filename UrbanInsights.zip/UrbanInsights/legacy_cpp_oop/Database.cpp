#include "Database.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <map>

Database::Database(const std::string& conninfo) {
    try {
        conn_ = std::make_unique<pqxx::connection>(conninfo);
        statusMessage_ = conn_->is_open()
            ? (std::string("Connected to ") + conn_->dbname())
            : "Connection object created but not open";
    } catch (const std::exception& e) {
        conn_.reset();
        statusMessage_ = std::string("Database connection failed: ") + e.what();
        std::cerr << statusMessage_ << "\n";
    }
}

static std::string slugify(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (std::isalnum(static_cast<unsigned char>(c))) out += static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        else if (!out.empty() && out.back() != '.') out += '.';
    }
    return out.empty() ? "citizen" : out;
}

int Database::ensureDemoCitizen(pqxx::work& txn, const std::string& name) {
    auto found = txn.exec_params("SELECT id FROM users WHERE name = $1 AND role = 'citizen' LIMIT 1", name);
    if (!found.empty()) return found[0][0].as<int>();

    std::string email = slugify(name) + "@demo.urbaninsights.local";
    auto inserted = txn.exec_params(
        "INSERT INTO users (name, email, password_hash, role) "
        "VALUES ($1, $2, 'demo_no_auth_yet', 'citizen') "
        "ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name "
        "RETURNING id", name, email);
    int userId = inserted[0][0].as<int>();

    txn.exec_params(
        "INSERT INTO citizen_profiles (user_id, trust_score, complaints_filed) "
        "VALUES ($1, 50.0, 0) ON CONFLICT (user_id) DO NOTHING", userId);
    return userId;
}

json Database::getStateSeveritySummary(const std::string& category) {
    std::lock_guard<std::mutex> lock(dbMutex_);
    json out = json::array();
    try {
        pqxx::work txn(*conn_);
        const bool filtered = category != "all" && !category.empty();
        std::string sql =
    std::string("SELECT st.id, st.name AS state_name, "
    "count(c.id) AS total, count(c.id) FILTER (WHERE c.status <> 'resolved') AS active, "
    "count(c.id) FILTER (WHERE c.severity='high' AND c.status <> 'resolved') AS high, "
    "count(c.id) FILTER (WHERE c.severity='medium' AND c.status <> 'resolved') AS medium, "
    "count(c.id) FILTER (WHERE c.severity='low' AND c.status <> 'resolved') AS low, "
    "count(c.id) FILTER (WHERE c.status='resolved') AS resolved "
    "FROM states st LEFT JOIN districts di ON di.state_id=st.id LEFT JOIN cities ci ON ci.district_id=di.id "
    "LEFT JOIN complaints c ON c.city_id=ci.id ")
    + (filtered ? "AND c.category=$1::complaint_category " : "")
    + "GROUP BY st.id, st.name ORDER BY st.name";
        auto rows = filtered ? txn.exec_params(sql, category) : txn.exec(sql);
        for (const auto& row : rows) {
            int active=row["active"].as<int>(), high=row["high"].as<int>(), medium=row["medium"].as<int>(), low=row["low"].as<int>();
            std::string level = active==0 ? "none" : (high>0 ? "high" : (medium>0 ? "medium" : "low"));
            out.push_back({{"id",row["id"].as<int>()},{"state",row["state_name"].c_str()},{"total",row["total"].as<int>()},{"active",active},{"high",high},{"medium",medium},{"low",low},{"resolved",row["resolved"].as<int>()},{"severity",level}});
        }
        txn.commit();
    } catch (const std::exception& e) { std::cerr << "getStateSeveritySummary error: " << e.what() << "\n"; return {{"error", e.what()}}; }
    return out;
}

json Database::getDistrictSeveritySummary(const std::string& stateName, const std::string& category) {
    std::lock_guard<std::mutex> lock(dbMutex_); json out=json::array();
    try { pqxx::work txn(*conn_); bool filtered=category!="all" && !category.empty();
      std::string sql =
    std::string("SELECT di.id, di.name, "
    "count(c.id) total, "
    "count(c.id) FILTER (WHERE c.status<>'resolved') active, "
    "count(c.id) FILTER (WHERE c.severity='high' AND c.status<>'resolved') high, "
    "count(c.id) FILTER (WHERE c.severity='medium' AND c.status<>'resolved') medium, "
    "count(c.id) FILTER (WHERE c.severity='low' AND c.status<>'resolved') low, "
    "count(c.id) FILTER (WHERE c.status='resolved') resolved "
    "FROM districts di "
    "JOIN states st ON st.id=di.state_id "
    "LEFT JOIN cities ci ON ci.district_id=di.id "
    "LEFT JOIN complaints c ON c.city_id=ci.id "
    "WHERE st.name=$1 ")
    + (filtered ? "AND c.category=$2::complaint_category " : "")
    + "GROUP BY di.id,di.name ORDER BY di.name";
      auto rows=filtered?txn.exec_params(sql,stateName,category):txn.exec_params(sql,stateName);
      for(auto const& r:rows){int a=r["active"].as<int>(),h=r["high"].as<int>(),m=r["medium"].as<int>(),l=r["low"].as<int>(); std::string level=a==0?"none":(h?"high":(m?"medium":"low")); out.push_back({{"id",r["id"].as<int>()},{"district",r["name"].c_str()},{"total",r["total"].as<int>()},{"active",a},{"high",h},{"medium",m},{"low",l},{"resolved",r["resolved"].as<int>()},{"severity",level}});}
      txn.commit();
    } catch(const std::exception&e){std::cerr<<"getDistrictSeveritySummary error: "<<e.what()<<"\n"; return {{"error",e.what()}};} return out;
}

json Database::getGeography() {
 std::lock_guard<std::mutex> lock(dbMutex_); json out=json::array(); try{pqxx::work txn(*conn_); auto rows=txn.exec("SELECT st.id state_id,st.name state,di.id district_id,di.name district,ci.id city_id,ci.name city FROM states st LEFT JOIN districts di ON di.state_id=st.id LEFT JOIN cities ci ON ci.district_id=di.id ORDER BY st.name,di.name,ci.name"); std::map<int,json> states; for(auto const&r:rows){int sid=r["state_id"].as<int>(); if(!states.count(sid)) states[sid]={{"id",sid},{"name",r["state"].c_str()},{"districts",json::array()}}; if(!r["district_id"].is_null()){int did=r["district_id"].as<int>(); json* d=nullptr; for(auto& x:states[sid]["districts"]) if(x["id"].get<int>()==did){d=&x;break;} if(!d){states[sid]["districts"].push_back({{"id",did},{"name",r["district"].c_str()},{"cities",json::array()}}); d=&states[sid]["districts"].back();} if(!r["city_id"].is_null()) d->at("cities").push_back({{"id",r["city_id"].as<int>()},{"name",r["city"].c_str()}});}} for(auto& kv:states) out.push_back(kv.second); txn.commit();}catch(const std::exception&e){std::cerr<<"getGeography error: "<<e.what()<<"\n"; return {{"error",e.what()}};} return out; }

json Database::getCityRankings(int page, int pageSize, const std::string& state, const std::string& district, const std::string& severity) {
 std::lock_guard<std::mutex> lock(dbMutex_); json out={{"items",json::array()},{"page",page},{"pageSize",pageSize},{"total",0}}; try{pqxx::work txn(*conn_); page=std::max(1,page); pageSize=std::min(100,std::max(1,pageSize)); std::string where=" WHERE 1=1 "; if(!state.empty()) where+=" AND state_name=$1 "; if(!district.empty()) where+=(state.empty()?" AND district_name=$1 ":" AND district_name=$2 "); if(severity=="high") where+=" AND high_severity_count>0 "; else if(severity=="medium") where+=" AND medium_severity_count>0 "; else if(severity=="low") where+=" AND low_severity_count>0 "; std::string countSql="SELECT count(*) FROM city_rankings"+where; pqxx::result cr; if(!state.empty()&&!district.empty()) cr=txn.exec_params(countSql,state,district); else if(!state.empty()) cr=txn.exec_params(countSql,state); else if(!district.empty()) cr=txn.exec_params(countSql,district); else cr=txn.exec(countSql); out["total"]=cr[0][0].as<int>(); std::string baseSql="SELECT city_id,city_name,district_name,state_name,total_complaints,active_complaints,high_severity_count,medium_severity_count,low_severity_count,resolved_count,resolution_rate FROM city_rankings"+where+" ORDER BY total_complaints DESC, city_name ASC ";
        std::string sql = baseSql;
        pqxx::result rows;
        const int offset=(page-1)*pageSize;
        if(!state.empty()&&!district.empty()){ sql += "LIMIT $3 OFFSET $4"; rows=txn.exec_params(sql,state,district,pageSize,offset); }
        else if(!state.empty()){ sql += "LIMIT $2 OFFSET $3"; rows=txn.exec_params(sql,state,pageSize,offset); }
        else if(!district.empty()){ sql += "LIMIT $2 OFFSET $3"; rows=txn.exec_params(sql,district,pageSize,offset); }
        else { sql += "LIMIT $1 OFFSET $2"; rows=txn.exec_params(sql,pageSize,offset); } int rank=(page-1)*pageSize+1; for(auto const&r:rows) out["items"].push_back({{"rank",rank++},{"city",r["city_name"].c_str()},{"district",r["district_name"].c_str()},{"state",r["state_name"].c_str()},{"totalComplaints",r["total_complaints"].as<int>()},{"active",r["active_complaints"].as<int>()},{"high",r["high_severity_count"].as<int>()},{"medium",r["medium_severity_count"].as<int>()},{"low",r["low_severity_count"].as<int>()},{"resolved",r["resolved_count"].as<int>()},{"resolutionRate",r["resolution_rate"].as<double>()}}); txn.commit(); }catch(const std::exception&e){std::cerr<<"getCityRankings error: "<<e.what()<<"\n"; out["error"]=e.what();} return out; }

json Database::getDashboardSummary() {
    std::lock_guard<std::mutex> lock(dbMutex_);
    json out = {{"total", 0}, {"resolved", 0}, {"pending", 0}, {"highSeverity", 0}};
    try {
        pqxx::work txn(*conn_);
        auto row = txn.exec(
            "SELECT count(*) AS total, "
            "       count(*) FILTER (WHERE status='resolved') AS resolved, "
            "       count(*) FILTER (WHERE status IN ('pending','assigned','in_progress')) AS pending, "
            "       count(*) FILTER (WHERE severity='high') AS high_severity "
            "FROM complaints")[0];
        out = {
            {"total", row["total"].as<int>()},
            {"resolved", row["resolved"].as<int>()},
            {"pending", row["pending"].as<int>()},
            {"highSeverity", row["high_severity"].as<int>()},
        };
        txn.commit();
    } catch (const std::exception& e) {
        std::cerr << "getDashboardSummary error: " << e.what() << "\n";
    }
    return out;
}
json Database::getDepartments() {
    std::lock_guard<std::mutex> lock(dbMutex_);
    json out = json::array();

    try {
        pqxx::work txn(*conn_);

        auto rows = txn.exec(
            "SELECT id, name, category, staff_count "
            "FROM departments "
            "ORDER BY name"
        );

        for (const auto& row : rows) {
            out.push_back({
                {"id", row["id"].as<int>()},
                {"name", row["name"].c_str()},
                {"category", row["category"].c_str()},
                {"staffCount", row["staff_count"].as<int>()}
            });
        }

        txn.commit();
    }
    catch (const std::exception& e) {
        std::cerr << "getDepartments error: "
                  << e.what() << "\n";
        return {
            {"error", e.what()}
        };
    }

    return out;
}
json Database::listComplaints(int limit) {
    std::lock_guard<std::mutex> lock(dbMutex_);
    json out = json::array();
    try {
        pqxx::work txn(*conn_);
        auto rows = txn.exec_params(
            "SELECT c.id, c.reference_code, c.category, ci.name AS city, st.name AS state, "
            "       c.locality, c.description, c.severity, c.status, c.impact_score, "
            "       c.urgency_score, c.reported_at, u.name AS citizen_name "
            "FROM complaints c "
            "JOIN cities ci ON ci.id = c.city_id "
            "JOIN states st ON st.id = ci.state_id "
            "JOIN users u ON u.id = c.citizen_id "
            "ORDER BY c.reported_at DESC LIMIT $1", limit);
        for (const auto& row : rows) {
            out.push_back({
                {"id", row["id"].as<int>()},
                {"referenceCode", row["reference_code"].c_str()},
                {"category", row["category"].c_str()},
                {"city", row["city"].c_str()},
                {"state", row["state"].c_str()},
                {"locality", row["locality"].c_str()},
                {"description", row["description"].c_str()},
                {"severity", row["severity"].c_str()},
                {"status", row["status"].c_str()},
                {"impactScore", row["impact_score"].as<int>()},
                {"urgencyScore", row["urgency_score"].as<int>()},
                {"reportedAt", row["reported_at"].c_str()},
                {"citizenName", row["citizen_name"].c_str()},
            });
        }
        txn.commit();
    } catch (const std::exception& e) {
        std::cerr << "listComplaints error: " << e.what() << "\n";
    }
    return out;
}

json Database::getComplaintById(int id) {
    std::lock_guard<std::mutex> lock(dbMutex_);
    try {
        pqxx::work txn(*conn_);
        auto rows = txn.exec_params(
            "SELECT c.id, c.reference_code, c.category, ci.name AS city, st.name AS state, "
            "       c.locality, c.description, c.severity, c.status, c.impact_score, "
            "       c.urgency_score, c.reported_at, u.name AS citizen_name "
            "FROM complaints c "
            "JOIN cities ci ON ci.id = c.city_id "
            "JOIN states st ON st.id = ci.state_id "
            "JOIN users u ON u.id = c.citizen_id "
            "WHERE c.id = $1", id);
        txn.commit();
        if (rows.empty()) return json(nullptr);
        const auto& row = rows[0];
        return {
            {"id", row["id"].as<int>()},
            {"referenceCode", row["reference_code"].c_str()},
            {"category", row["category"].c_str()},
            {"city", row["city"].c_str()},
            {"state", row["state"].c_str()},
            {"locality", row["locality"].c_str()},
            {"description", row["description"].c_str()},
            {"severity", row["severity"].c_str()},
            {"status", row["status"].c_str()},
            {"impactScore", row["impact_score"].as<int>()},
            {"urgencyScore", row["urgency_score"].as<int>()},
            {"reportedAt", row["reported_at"].c_str()},
            {"citizenName", row["citizen_name"].c_str()},
        };
    } catch (const std::exception& e) {
        std::cerr << "getComplaintById error: " << e.what() << "\n";
        return json(nullptr);
    }
}

json Database::createComplaint(const std::string& category, int stateId, int districtId, int cityId,
                                const std::string& locality, const std::string& description,
                                const std::string& citizenName, int impactScore, int urgencyScore,
                                int severityCode) {
    std::lock_guard<std::mutex> lock(dbMutex_);
    static const char* severityWords[] = {"low", "medium", "high"};
    std::string severity = (severityCode >= 0 && severityCode <= 2) ? severityWords[severityCode] : "unset";
    std::string categoryLower = category;
    std::transform(categoryLower.begin(), categoryLower.end(), categoryLower.begin(),
                    [](unsigned char c) { return std::tolower(c); });

    try {
        pqxx::work txn(*conn_);
        int citizenId = ensureDemoCitizen(txn, citizenName.empty() ? "Anonymous" : citizenName);
        auto geo = txn.exec_params("SELECT ci.id FROM cities ci JOIN districts di ON di.id=ci.district_id WHERE ci.id=$1 AND ci.district_id=$2 AND di.state_id=$3", cityId, districtId, stateId);
        if (geo.empty()) return {{"error", "Invalid state/district/city relationship"}};

        std::string refCode = txn.exec("SELECT next_complaint_reference()")[0][0].as<std::string>();

        auto inserted = txn.exec_params(
            "INSERT INTO complaints "
            "  (reference_code, category, city_id, district_id, locality, description, citizen_id, "            "   impact_score, urgency_score, severity) "
            "VALUES ($1, $2::complaint_category, $3, $4, $5, $6, $7, $8, $9, $10::severity_level) "
            "RETURNING id, reported_at",
            refCode, categoryLower, cityId, districtId, locality, description, citizenId,
            impactScore, urgencyScore, severity);

        int newId = inserted[0][0].as<int>();
        std::string reportedAt = inserted[0][1].as<std::string>();

        txn.exec_params(
            "UPDATE citizen_profiles SET complaints_filed = complaints_filed + 1 "
            "WHERE user_id = $1", citizenId);

        txn.commit();

        return {
            {"id", newId},
            {"referenceCode", refCode},
            {"category", categoryLower},
            
            {"locality", locality},
            {"description", description},
            {"severity", severity},
            {"status", "pending"},
            {"impactScore", impactScore},
            {"urgencyScore", urgencyScore},
            {"reportedAt", reportedAt},
        };
    } catch (const std::exception& e) {
        std::cerr << "createComplaint error: " << e.what() << "\n";
        return {{"error", std::string("Could not create complaint: ") + e.what()}};
    }
}

// Escapes one CSV field per RFC 4180: wrap in quotes and double any
// interior quotes whenever the field contains a comma, quote, or
// newline (a complaint description can easily contain a comma).
static std::string csvField(const std::string& raw) {
    bool needsQuoting = raw.find_first_of(",\"\n\r") != std::string::npos;
    if (!needsQuoting) return raw;
    std::string out = "\"";
    for (char c : raw) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    out += "\"";
    return out;
}

std::string Database::exportComplaintsCsv() {
    std::lock_guard<std::mutex> lock(dbMutex_);
    std::ostringstream csv;
    csv << "Reference Code,Category,City,Locality,Description,Severity,Status,"
           "Impact Score,Urgency Score,Reported At\n";
    try {
        pqxx::work txn(*conn_);
        auto rows = txn.exec(
            "SELECT c.reference_code, c.category, ci.name AS city, c.locality, "
            "       c.description, c.severity, c.status, c.impact_score, c.urgency_score, "
            "       c.reported_at "
            "FROM complaints c JOIN cities ci ON ci.id = c.city_id "
            "ORDER BY c.reported_at DESC");
        for (const auto& row : rows) {
            csv << csvField(row["reference_code"].c_str()) << ","
                << csvField(row["category"].c_str()) << ","
                << csvField(row["city"].c_str()) << ","
                << csvField(row["locality"].c_str()) << ","
                << csvField(row["description"].c_str()) << ","
                << csvField(row["severity"].c_str()) << ","
                << csvField(row["status"].c_str()) << ","
                << row["impact_score"].as<int>() << ","
                << row["urgency_score"].as<int>() << ","
                << csvField(row["reported_at"].c_str()) << "\n";
        }
        txn.commit();
    } catch (const std::exception& e) {
        std::cerr << "exportComplaintsCsv error: " << e.what() << "\n";
    }
    return csv.str();
}
