#ifndef DATABASE_H
#define DATABASE_H

/*
    ================================================================
    URBAN INSIGHTS -- backend/Database.h
    ================================================================
    Thin wrapper around libpqxx - the actual C++ <-> PostgreSQL
    connection that database/schema.sql was written for. Every method
    returns nlohmann::json already shaped for the HTTP API
    (ApiServer.h) to send straight back to the browser.
    ================================================================
*/

#include "third_party/json.hpp"
#include <pqxx/pqxx>
#include <memory>
#include <mutex>
#include <string>
using namespace std;
using json = nlohmann::json;

class Database {
public:
    explicit Database(const  string& conninfo);

    bool ok() const { return static_cast<bool>(conn_) && conn_->is_open(); }
     string statusMessage() const { return statusMessage_; }

    json getStateSeveritySummary(const  string& category = "all");
    json getDistrictSeveritySummary(const  string& stateName, const  string& category = "all");
    json getGeography();          // -> array of {state, total, high, medium, low, resolved}
    json getCityRankings(int page = 1, int pageSize = 25, const  string& state = "", const  string& district = "", const  string& severity = "");     // -> uses the city_rankings VIEW
    json getDashboardSummary();               // -> total/resolved/pending/highSeverity + % deltas
    json getDepartments();
    json listComplaints(int limit = 50);
    json getComplaintById(int id);
     string exportComplaintsCsv(); // Plan.pdf: "download complaint data in form of excel file"

    // category, cityName, locality, description, citizenName, impact, urgency -> the created row (with severity + reference_code)
    json createComplaint(const  string& category, int stateId, int districtId, int cityId,
                          const  string& locality, const  string& description,
                          const  string& citizenName, int impactScore, int urgencyScore,
                          int severityCode /* 0=Low 1=Medium 2=High, from assembly */);

private:
     unique_ptr<pqxx::connection> conn_;
     string statusMessage_;
    // httplib runs each request on a thread from a pool, but a single
    // pqxx::connection can only run one transaction at a time - without
    // this, two requests arriving close together throw "Started new
    // transaction while transaction was still active." Every public
    // method below takes this lock before touching conn_. Fine for an
    // app this size; a real high-traffic service would use a connection
    // pool (one connection per worker) instead of serializing on one.
     mutex dbMutex_;

    int ensureDemoCitizen(pqxx::work& txn, const  string& name);
};

#endif // DATABASE_H
