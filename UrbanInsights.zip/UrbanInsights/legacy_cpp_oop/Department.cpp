#include "Department.h"
#include "Exceptions.h"

#include <iostream>

Department::Department(std::string name, std::string categoryHandled, int staffCount)
    : name(std::move(name)), categoryHandled(std::move(categoryHandled)),
      staffCount(staffCount), resolvedCount(0) {}

Department::~Department() {
    // Practical 04: delete - a Department owns every Complaint* it holds,
    // wherever it currently sits (assigned, or still queued).
    for (Complaint* c : assignedComplaints) {
        delete c;
    }
    for (Complaint* c : processingQueue) {
        delete c;
    }
}

Department& Department::operator+=(Complaint* complaint) {
    receiveComplaint(complaint);
    assignNext();
    return *this;
}

void Department::receiveComplaint(Complaint* complaint) {
    if (complaint == nullptr) {
        throw InvalidComplaintException("Cannot receive a null complaint pointer");
    }
    processingQueue.push_back(complaint);
}

bool Department::assignNext() {
    if (processingQueue.empty()) {
        return false;
    }

    Complaint* next = processingQueue.front();
    processingQueue.pop_front();

    next->assignedDepartment = name;   // legal only because Department is a friend of Complaint
    next->setStatus(ComplaintStatus::ASSIGNED);

    assignedComplaints.push_back(next);
    return true;
}

void Department::markResolved(int complaintId) {
    for (Complaint* c : assignedComplaints) {
        if (c->getId() == complaintId) {
            c->setStatus(ComplaintStatus::RESOLVED);
            resolvedCount++;
            return;
        }
    }
    throw NotFoundException("Department " + name + " has no complaint #" + std::to_string(complaintId));
}

double Department::resolutionRate() const {
    if (assignedComplaints.empty()) return 0.0;
    return (static_cast<double>(resolvedCount) / assignedComplaints.size()) * 100.0;
}

void Department::displaySummary() const {
    std::cout << "  " << name << " (" << categoryHandled << ") - staff: " << staffCount
              << ", assigned: " << assignedComplaints.size()
              << ", queued: " << processingQueue.size()
              << ", resolved: " << resolvedCount
              << ", resolution rate: " << resolutionRate() << "%\n";
}
