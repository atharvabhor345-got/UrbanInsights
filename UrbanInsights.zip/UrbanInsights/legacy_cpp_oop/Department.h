#ifndef DEPARTMENT_H
#define DEPARTMENT_H

/*
    ================================================================
    URBAN INSIGHTS -- Department.h
    ================================================================
    A Department owns the complaints assigned to it. It is declared a
    `friend` inside Complaint (see Complaint.h) so it can set
    assignedDepartment directly - the rest of the codebase must go
    through Complaint's normal public interface.

    OOP LAB PRACTICAL 11 (STL): uses std::vector AND std::list - the
    two container types the practical asks for - for two different
    jobs (assigned complaints vs. an intake queue).

    NOTE: this is intentionally separate from the DSA course's own
    linked-list / queue implementations in dsa/, which are built by
    hand (no STL) because that is what the DSA practicals ask for.
    ================================================================
*/

#include <string>
#include <vector>
#include <list>
#include "Complaint.h"

class Department {
private:
    std::string name;                            // "Road Department", "Water Department", ...
    std::string categoryHandled;                 // "Traffic", "Water", ...
    std::vector<Complaint*> assignedComplaints;   // STL vector container
    std::list<Complaint*> processingQueue;        // STL list container (FIFO intake)
    int staffCount;
    int resolvedCount;

public:
    Department(std::string name, std::string categoryHandled, int staffCount);
    ~Department();  // deletes every Complaint* it owns (Practical 04: delete)

    // Practical 03: operator overloading - `dept += complaint` reads as
    // "hand this complaint straight to the department".
    Department& operator+=(Complaint* complaint);

    void receiveComplaint(Complaint* complaint);  // enqueue into processingQueue
    bool assignNext();                            // dequeue -> move into assignedComplaints
    void markResolved(int complaintId);

    double resolutionRate() const;
    inline int getAssignedCount() const { return static_cast<int>(assignedComplaints.size()); }
    inline int getQueueCount() const { return static_cast<int>(processingQueue.size()); }
    inline const std::string& getName() const { return name; }
    inline const std::string& getCategoryHandled() const { return categoryHandled; }
    const std::vector<Complaint*>& getAssignedComplaints() const { return assignedComplaints; }

    void displaySummary() const;
};

#endif // DEPARTMENT_H
