#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

/*
    ================================================================
    URBAN INSIGHTS -- Exceptions.h
    ================================================================
    OOP LAB PRACTICAL 08 : Exception Handling

    Custom exception types used across the backend. Each derives from
    std::exception so callers can catch a specific problem first, or
    fall back to a general `catch (const std::exception&)`.
    ================================================================
*/

#include <exception>
#include <string>

// Thrown when a Complaint (or User) is created / updated with invalid data
class InvalidComplaintException : public std::exception {
private:
    std::string message;

public:
    explicit InvalidComplaintException(const std::string& msg)
        : message("InvalidComplaintException: " + msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};

// Thrown when code looks up a complaint / user / department that doesn't exist
class NotFoundException : public std::exception {
private:
    std::string message;

public:
    explicit NotFoundException(const std::string& msg)
        : message("NotFoundException: " + msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};

// Thrown when a department is asked to take on more work than it can handle
class DepartmentOverloadException : public std::exception {
private:
    std::string message;

public:
    explicit DepartmentOverloadException(const std::string& msg)
        : message("DepartmentOverloadException: " + msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};

#endif // EXCEPTIONS_H
