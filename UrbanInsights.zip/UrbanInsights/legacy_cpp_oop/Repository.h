#ifndef REPOSITORY_H
#define REPOSITORY_H

/*
    ================================================================
    URBAN INSIGHTS -- Repository.h
    ================================================================
    OOP LAB PRACTICAL 10 : Templates (class template + function template)
    OOP LAB PRACTICAL 11 : Standard Template Library (vector container)

    Repository<T> is a generic, reusable container for any Urban
    Insights entity that exposes ->getId(). It is instantiated in
    main.cpp as Repository<Complaint*>, but nothing here mentions
    Complaint by name - that's the whole point of a template.
    ================================================================
*/

#include <vector>
#include <algorithm>
#include <iostream>
#include <string>
#include "Exceptions.h"

// ---- Class template ----
template <typename T>
class Repository {
private:
    std::vector<T> items;   // STL vector as the underlying container (Practical 11)

public:
    Repository() = default;

    void add(const T& item) {
        items.push_back(item);
    }

    // Move-aware overload - lets callers hand off ownership with std::move
    void add(T&& item) {
        items.push_back(std::move(item));
    }

    size_t size() const {
        return items.size();
    }

    bool isEmpty() const {
        return items.empty();
    }

    // T is expected to be pointer-like and expose ->getId()
    T findById(int id) const {
        for (const auto& item : items) {
            if (item->getId() == id) {
                return item;
            }
        }
        throw NotFoundException("No record with id " + std::to_string(id));
    }

    const std::vector<T>& getAll() const {
        return items;
    }

    void removeById(int id) {
        auto it = std::remove_if(items.begin(), items.end(),
            [id](const T& item) { return item->getId() == id; });

        if (it == items.end()) {
            throw NotFoundException("No record with id " + std::to_string(id));
        }
        items.erase(it, items.end());
    }
};

// ---- Function template #1 ----
// Works for any element type that supports operator<< (Complaint does).
template <typename T>
void printAll(const std::vector<T>& items) {
    for (const auto& item : items) {
        std::cout << "    " << *item << "\n";
    }
}

// ---- Function template #2 ----
// Generic "find the best element by some comparator" - comparator decides
// what "best" means, so this works for priority, severity, date, etc.
template <typename T, typename Compare>
T findBest(const std::vector<T>& items, Compare comp) {
    if (items.empty()) {
        throw NotFoundException("Cannot find the best element of an empty collection");
    }
    T best = items.front();
    for (const auto& item : items) {
        if (comp(item, best)) {
            best = item;
        }
    }
    return best;
}

#endif // REPOSITORY_H
