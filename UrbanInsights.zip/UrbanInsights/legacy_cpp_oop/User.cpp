#include "User.h"
#include "Exceptions.h"

#include <utility>
#include <sstream>
#include <functional>

int User::nextUserId = 1;

std::string User::hashPassword(const std::string& plainPassword) {
    // NOTE: a real deployment must use bcrypt/argon2 with a per-user salt.
    // This is a lightweight stand-in so the demo never stores plain text.
    std::size_t h = std::hash<std::string>{}(plainPassword);
    std::ostringstream oss;
    oss << std::hex << h;
    return oss.str();
}

// ---------------------------------------------------------------
// User (constructor types - Practical 02)
// ---------------------------------------------------------------

User::User()
    : userId(nextUserId++), name("Unknown"), email(""), passwordHash(""), phone("") {}

User::User(std::string name, std::string email, std::string plainPassword, std::string phone)
    : userId(nextUserId++), name(std::move(name)), email(std::move(email)),
      passwordHash(hashPassword(plainPassword)), phone(std::move(phone)) {

    if (this->name.empty() || this->email.empty()) {
        throw InvalidComplaintException("User must have both a name and an email");
    }
}

User::User(const User& other)
    : userId(nextUserId++), name(other.name), email(other.email),
      passwordHash(other.passwordHash), phone(other.phone) {}

User::~User() {}

bool User::checkPassword(const std::string& attempt) const {
    return hashPassword(attempt) == passwordHash;
}

void User::displayProfile() const {
    std::cout << *this;
}

std::ostream& operator<<(std::ostream& os, const User& u) {
    os << "[#" << u.userId << "] " << u.name << " <" << u.email << ">";
    return os;
}

// ---------------------------------------------------------------
// Citizen : User   (hierarchical / single inheritance)
// ---------------------------------------------------------------

Citizen::Citizen(std::string name, std::string email, std::string plainPassword, std::string phone)
    : User(std::move(name), std::move(email), std::move(plainPassword), std::move(phone)),
      complaintsFiled(0), trustScore(50.0) {}

UserRole Citizen::getRole() const { return UserRole::CITIZEN; }

void Citizen::fileComplaint() {
    complaintsFiled++;
    if (trustScore < 100.0) trustScore += 1.5;
}

// ---------------------------------------------------------------
// Admin : User, Auditable, Notifiable   (multiple inheritance)
// ---------------------------------------------------------------

Admin::Admin(std::string name, std::string email, std::string plainPassword,
             std::string phone, std::string department)
    : User(std::move(name), std::move(email), std::move(plainPassword), std::move(phone)),
      department(std::move(department)), complaintsResolved(0) {}

UserRole Admin::getRole() const { return UserRole::ADMIN; }

std::string Admin::auditLog() const {
    return name + " (Admin, " + department + ") resolved " +
           std::to_string(complaintsResolved) + " complaint(s)";
}

void Admin::notify(const std::string& message) {
    notificationsSent++;
    std::cout << "  [notify -> " << name << "] " << message << "\n";
}

void Admin::resolveComplaint() {
    complaintsResolved++;
}

// ---------------------------------------------------------------
// SuperAdmin : Admin   (multilevel inheritance)
// ---------------------------------------------------------------

SuperAdmin::SuperAdmin(std::string name, std::string email, std::string plainPassword,
                        std::string phone, int citiesManaged)
    : Admin(std::move(name), std::move(email), std::move(plainPassword), std::move(phone), "All Departments"),
      citiesManaged(citiesManaged) {}

UserRole SuperAdmin::getRole() const { return UserRole::SUPER_ADMIN; }

std::string SuperAdmin::auditLog() const {
    return Admin::auditLog() + ", overseeing " + std::to_string(citiesManaged) + " cities";
}
