#ifndef USER_H
#define USER_H

/*
    ================================================================
    URBAN INSIGHTS -- User.h
    ================================================================
    OOP LAB PRACTICAL 06 : Inheritance (different types)

    This tree deliberately demonstrates several inheritance styles in
    one place, using people instead of complaints:

        User (abstract base)
          |-- Citizen                                (single / hierarchical)
          |-- Admin : User, Auditable, Notifiable     (MULTIPLE inheritance)
                |-- SuperAdmin                        (MULTILEVEL inheritance)

    Taken together (User branches into Citizen and Admin = hierarchical;
    Admin also pulls in two unrelated interfaces = multiple; SuperAdmin
    extends Admin one level further = multilevel) the whole tree is a
    HYBRID inheritance graph - several "types" at once, in one design.
    ================================================================
*/

#include <string>
#include <iostream>
using namespace std;
enum class UserRole { CITIZEN, ADMIN, SUPER_ADMIN };

// ---- small abstract interfaces, used for MULTIPLE inheritance below ----

class Auditable {
public:
    virtual  string auditLog() const = 0;
    virtual ~Auditable() = default;
};

class Notifiable {
protected:
    int notificationsSent = 0;

public:
    virtual void notify(const  string& message) = 0;
    int getNotificationsSent() const { return notificationsSent; }
    virtual ~Notifiable() = default;
};

// ---------------------------------------------------------------
// User - abstract base class
// ---------------------------------------------------------------

class User {
protected:
    int userId;
     string name;
     string email;
     string passwordHash;   // never store plain-text passwords
     string phone;

    static int nextUserId;

    static  string hashPassword(const  string& plainPassword);

public:
    User();
    User( string name,  string email,  string plainPassword,  string phone);
    User(const User& other);
    virtual ~User();

    inline int getUserId() const { return userId; }
    inline const  string& getName() const { return name; }
    inline const  string& getEmail() const { return email; }

    bool checkPassword(const  string& attempt) const;

    virtual UserRole getRole() const = 0;   // pure virtual -> User is abstract
    virtual void displayProfile() const;

    friend  ostream& operator<<( ostream& os, const User& u);
};

// ---------------------------------------------------------------
// Citizen : User                     (hierarchical / single inheritance)
// ---------------------------------------------------------------

class Citizen : public User {
private:
    int complaintsFiled;
    double trustScore; // rises as a citizen files real, verified complaints

public:
    Citizen( string name,  string email,  string plainPassword,  string phone);

    UserRole getRole() const override;
    void fileComplaint();  // increments complaintsFiled
    inline int getComplaintsFiled() const { return complaintsFiled; }
    inline double getTrustScore() const { return trustScore; }
};

// ---------------------------------------------------------------
// Admin : User, Auditable, Notifiable         (MULTIPLE inheritance)
// ---------------------------------------------------------------

class Admin : public User, public Auditable, public Notifiable {
protected:
     string department;
    int complaintsResolved;

public:
    Admin( string name,  string email,  string plainPassword,
           string phone,  string department);

    UserRole getRole() const override;
     string auditLog() const override;
    void notify(const  string& message) override;

    void resolveComplaint(); // increments complaintsResolved
    inline int getComplaintsResolved() const { return complaintsResolved; }
};

// ---------------------------------------------------------------
// SuperAdmin : Admin                           (MULTILEVEL inheritance)
// ---------------------------------------------------------------

class SuperAdmin : public Admin {
private:
    int citiesManaged;

public:
    SuperAdmin( string name,  string email,  string plainPassword,
                string phone, int citiesManaged);

    UserRole getRole() const override;
     string auditLog() const override; // overridden again -> deeper polymorphism
};

#endif // USER_H
