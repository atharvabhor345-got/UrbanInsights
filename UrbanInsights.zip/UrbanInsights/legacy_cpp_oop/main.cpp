/*
    ================================================================
    URBAN INSIGHTS -- main.cpp
    ================================================================
    A runnable walkthrough of every OOP lab practical (MITAOE syllabus),
    built on the real Urban Insights domain model instead of throwaway
    examples. Run it and read the console output top to bottom - it
    doubles as a script for the review.

        Build:  make
        Run:    ./bin/urban_insights_oop_demo      (or just `make run`)

    Full practical -> file/function table: docs/OOP_PRACTICALS_MAP.md
    ================================================================
*/

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

#include "Complaint.h"
#include "User.h"
#include "Department.h"
#include "Exceptions.h"
#include "Repository.h"

#include "DoublyLinkedList.h"
#include "HashTable.h"
#include "Queue.h"
#include "Stack.h"
#include "CityArray.h"
#include "Searching.h"
#include "Sorting.h"

static void banner(const std::string& title) {
    std::cout << "\n============================================================\n"
              << title << "\n"
              << "============================================================\n";
}

// Practical 04: reference parameter - avoids copying the Complaint
static void printComplaintByReference(const Complaint& c) {
    std::cout << "  by reference -> " << c << "\n";
}

int main() {
    std::cout << std::fixed << std::setprecision(1);

    // ------------------------------------------------------------
    banner("PRACTICAL 01 & 02 : Classes, Objects & Constructor types");
    // ------------------------------------------------------------

    TrafficComplaint      t1("Pune", "Kothrud", "Pothole outside college gate", "Aarav Sharma", 8, 7);
    GarbageComplaint       g1("Pune", "Wakad", "Garbage not collected for 5 days", "Meera Iyer", 6, 5);
    WaterComplaint          w1("Mumbai", "Andheri", "No water supply since morning", "Rohit Verma", 7, 8);
    ElectricityComplaint   e1("Nashik", "College Road", "Street light not working", "Sneha Patil", 3, 2);

    std::cout << "Created 4 complaints with parameterised constructors.\n";
    std::cout << "Complaint::getTotalComplaints() [static] = " << Complaint::getTotalComplaints() << "\n";

    Complaint* copyOfT1 = new TrafficComplaint(t1); // TrafficComplaint's compiler-generated
                                                     // copy ctor calls Complaint(const Complaint&)
    std::cout << "Copy-constructed complaint -> " << *copyOfT1 << "\n";

    // ------------------------------------------------------------
    banner("PRACTICAL 09 : Move semantics (std::move)");
    // ------------------------------------------------------------

    GarbageComplaint tempComplaint("Pune", "Aundh", "Overflowing bin near the market", "Kunal Deshmukh", 5, 4);
    std::cout << "Before move -> tempComplaint id " << tempComplaint.getId() << "\n";

    GarbageComplaint movedComplaint(std::move(tempComplaint)); // invokes the move constructor
    std::cout << "After move  -> movedComplaint  " << movedComplaint << "\n";
    std::cout << "               tempComplaint is now id " << tempComplaint.getId()
              << " (valid but empty - moved from)\n";

    // ------------------------------------------------------------
    banner("PRACTICAL 08 : Exception handling");
    // ------------------------------------------------------------

    try {
        WaterComplaint invalid("Pune", "Baner", "", "Test User", 5, 5); // empty description
        (void)invalid;
    } catch (const InvalidComplaintException& ex) {
        std::cout << "Caught InvalidComplaintException -> " << ex.what() << "\n";
    } catch (const std::exception& ex) {
        std::cout << "Caught a general exception -> " << ex.what() << "\n";
    }

    try {
        Repository<Complaint*> emptyRepo;
        emptyRepo.findById(9999); // nothing in it yet
    } catch (const NotFoundException& ex) {
        std::cout << "Caught NotFoundException -> " << ex.what() << "\n";
    }

    // ------------------------------------------------------------
    banner("PRACTICAL 03 & 05 : Operators, this pointer, friend, inline, static");
    // ------------------------------------------------------------

    t1.setSeverity(Severity::HIGH).setStatus(ComplaintStatus::IN_PROGRESS); // chained via 'this'
    std::cout << "Chained setters (each returns *this) -> " << t1 << "\n";
    std::cout << "t1 == g1 (two different complaints)?  " << std::boolalpha << (t1 == g1) << "\n";
    std::cout << "operator<< is a friend function       -> " << g1 << "\n";

    // ------------------------------------------------------------
    banner("PRACTICAL 07 : Polymorphism (priority score per complaint type)");
    // ------------------------------------------------------------

    std::vector<Complaint*> allComplaints = { &t1, &g1, &w1, &e1 };
    for (Complaint* c : allComplaints) {
        c->evaluateSeverity(); // calls into assembly/severity.asm for the real classification
        std::cout << "  " << std::setw(14) << std::left << c->getCategoryLabel()
                  << " priority=" << std::setw(5) << c->calculatePriorityScore()
                  << " -> " << severityToString(c->getSeverity()) << "\n";
    }
    std::cout << "(priority is a C++ floating-point score for sorting; the Low/Medium/High\n"
              << " label comes from assembly/severity.asm's integer arithmetic - the two can\n"
              << " differ right at a threshold, e.g. 7.6 truncates to 7 in assembly, which is\n"
              << " Medium, not High. See docs/ASSEMBLY_CONCEPTS_MAP.md.)\n";

    // ------------------------------------------------------------
    banner("PRACTICAL 06 : Inheritance styles (see User.h for the full tree)");
    // ------------------------------------------------------------

    Citizen    citizen("Aarav Sharma", "aarav@example.com", "pass123", "9999900000");
    Admin      admin("Priya Nair", "priya@uinsights.gov.in", "adminpass", "9888800000", "Road Department");
    SuperAdmin root("Karan Mehta", "karan@uinsights.gov.in", "rootpass", "9777700000", 5);

    citizen.fileComplaint();
    admin.resolveComplaint();
    admin.notify("A new high-severity complaint needs review");

    std::cout << "Citizen   : User -> Citizen                (hierarchical / single) \n";
    std::cout << "Admin     : User + Auditable + Notifiable  (multiple)      -> " << admin.auditLog() << "\n";
    std::cout << "SuperAdmin: Admin -> SuperAdmin             (multilevel)   -> " << root.auditLog() << "\n";

    // ------------------------------------------------------------
    banner("PRACTICAL 04 & 12 : Dynamic memory, references, and type casting");
    // ------------------------------------------------------------

    Complaint* heapComplaint = new ElectricityComplaint(
        "Nagpur", "Civil Lines", "Transformer sparking near bus stop", "Devika Rao", 9, 9);
    heapComplaint->evaluateSeverity();

    printComplaintByReference(*heapComplaint); // Practical 04 - pass by reference

    int severityAsInt = static_cast<int>(heapComplaint->getSeverity()); // static_cast
    std::cout << "  static_cast<int>(severity)          = " << severityAsInt << "\n";

    if (ElectricityComplaint* elec = dynamic_cast<ElectricityComplaint*>(heapComplaint)) {
        (void)elec;
        std::cout << "  dynamic_cast<ElectricityComplaint*> = succeeded (matches actual type)\n";
    }
    if (dynamic_cast<WaterComplaint*>(heapComplaint) == nullptr) {
        std::cout << "  dynamic_cast<WaterComplaint*>       = nullptr (correctly rejected)\n";
    }

    const Complaint& readOnlyView = *heapComplaint;
    // const_cast: rarely justified, shown here only for the practical -
    // strips constness so a mutating setter can be called, then we go
    // straight back to treating the object as read-only again.
    Complaint& mutableAgain = const_cast<Complaint&>(readOnlyView);
    mutableAgain.setStatus(ComplaintStatus::IN_PROGRESS);
    std::cout << "  const_cast<Complaint&>(...)         -> status now "
              << statusToString(readOnlyView.getStatus()) << "\n";

    delete heapComplaint; // matches `new` above
    delete copyOfT1;      // matches `new` from Practical 01/02

    // ------------------------------------------------------------
    banner("PRACTICAL 10 & 11 : Templates + STL (vector & list)");
    // ------------------------------------------------------------

    Repository<Complaint*> repo;               // class template
    repo.add(new TrafficComplaint(t1));
    repo.add(new GarbageComplaint(g1));
    repo.add(new WaterComplaint(w1));

    std::cout << "Repository<Complaint*> (template class, backed by std::vector) holds "
              << repo.size() << " items:\n";
    printAll(repo.getAll());                    // function template #1

    Complaint* highestPriority = findBest(repo.getAll(),
        [](Complaint* a, Complaint* b) { return a->calculatePriorityScore() > b->calculatePriorityScore(); });
    std::cout << "findBest<T,Compare> (function template #2) -> highest priority in repo:\n"
              << "    " << *highestPriority << "\n";

    Department roadDept("Road Department", "Traffic", 12);
    roadDept += new TrafficComplaint("Pune", "Hinjewadi", "Signal not working", "Ibrahim Sheikh", 6, 6);
    roadDept.displaySummary();

    for (Complaint* c : repo.getAll()) delete c; // release repo-owned heap complaints

    // ================================================================
    // DSA MODULE - the structures in dsa/ take over the SAME kind of
    // Complaint objects the OOP section above just finished
    // demonstrating, this time managed by hand-built data structures
    // instead of Repository<T> / std::vector / std::list.
    // Concept -> file/function table: docs/DSA_CONCEPTS_MAP.md
    // ================================================================

    banner("DSA : Doubly Linked List + Hashing (master store & O(1) lookup)");

    ComplaintList masterList;     // dsa/DoublyLinkedList.h - OWNS every Complaint* below
    ComplaintHashTable idIndex;   // dsa/HashTable.h - non-owning O(1) index into masterList
    ComplaintQueue intake(10);    // dsa/Queue.h - non-owning FIFO intake pipeline
    StatusHistoryStack statusLog; // dsa/Stack.h - value-type audit trail
    CityComplaintGrid cityGrid;   // dsa/CityArray.h - real 2D array

    struct Seed {
        const char* city; const char* locality; const char* category;
        const char* desc; const char* citizen; int impact; int urgency;
    };
    Seed seeds[] = {
        {"Pune",   "Kothrud",      "Traffic",     "Pothole outside college gate",     "Aarav Sharma",   8, 7},
        {"Pune",   "Wakad",        "Garbage",     "Garbage not collected for 5 days", "Meera Iyer",     6, 5},
        {"Mumbai", "Andheri",      "Water",       "No water supply since morning",    "Rohit Verma",    7, 8},
        {"Nashik", "College Road", "Electricity", "Street light not working",         "Sneha Patil",    3, 2},
        {"Pune",   "Hinjewadi",    "Traffic",     "Signal not working",               "Ibrahim Sheikh", 6, 6},
        {"Mumbai", "Bandra",       "Garbage",     "Overflowing bin near market",      "Devika Rao",     5, 4},
    };

    for (const Seed& s : seeds) {
        Complaint* c;
        std::string category = s.category;
        if (category == "Traffic")      c = new TrafficComplaint(s.city, s.locality, s.desc, s.citizen, s.impact, s.urgency);
        else if (category == "Garbage") c = new GarbageComplaint(s.city, s.locality, s.desc, s.citizen, s.impact, s.urgency);
        else if (category == "Water")   c = new WaterComplaint(s.city, s.locality, s.desc, s.citizen, s.impact, s.urgency);
        else                             c = new ElectricityComplaint(s.city, s.locality, s.desc, s.citizen, s.impact, s.urgency);

        c->evaluateSeverity();
        ComplaintNode* node = masterList.insertAtTail(c); // linked list takes ownership
        idIndex.insert(c->getId(), node);                  // hash table indexes the node
        intake.enqueue(c);                                 // queue holds intake order (non-owning)
        cityGrid.recordComplaint(c->getCity(), c->getCategory());
        statusLog.push(StatusChangeRecord(c->getId(), ComplaintStatus::PENDING, "filed"));
    }

    std::cout << "ComplaintList (doubly linked list) holds " << masterList.size() << " records.\n";
    idIndex.displayStats();
    intake.display();

    // Prove the hash table is really O(1)-ish: look up a real id both ways.
    int sampleId = masterList.getHead()->next->data->getId();
    ComplaintNode* viaHash = idIndex.search(sampleId);
    ComplaintNode* viaScan = masterList.findById(sampleId);
    std::cout << "Lookup #" << sampleId << " -> hash table and linked-list scan agree: "
              << std::boolalpha << (viaHash == viaScan) << "\n";

    // ------------------------------------------------------------
    banner("DSA : Queue-driven routing (ownership stays with masterList)");
    // ------------------------------------------------------------
    // masterList already owns every complaint here, and
    // Department::receiveComplaint() (OOP module) takes ownership of
    // whatever it's handed - so rather than transferring the SAME
    // pointer to two owners, dequeuing decides routing and logs it;
    // it doesn't hand the object across module boundaries.
    while (!intake.isEmpty()) {
        Complaint* c = intake.dequeue();
        std::string dept = (c->getCategory() == "Garbage")     ? "Sanitation Department"
                          : (c->getCategory() == "Water")       ? "Water Supply Department"
                          : (c->getCategory() == "Electricity") ? "Electricity Board"
                                                                  : "Road Department";
        std::cout << "  #" << c->getId() << " (" << c->getCategoryLabel() << ", " << c->getCity()
                  << ") -> routed to " << dept << "\n";
        statusLog.push(StatusChangeRecord(c->getId(), ComplaintStatus::ASSIGNED, "routed to " + dept));
    }

    // ------------------------------------------------------------
    banner("DSA : Searching - linear vs binary (same data, real comparison counts)");
    // ------------------------------------------------------------

    int masterCount = masterList.size();
    Complaint** snapshot = masterList.toArray(); // borrowed pointers - masterList still owns them

    long linComparisons = 0, binComparisons = 0, insComparisons = 0, insSwaps = 0;
    int searchTargetId = snapshot[masterCount / 2]->getId();

    int linIdx = linearSearchById(snapshot, masterCount, searchTargetId, linComparisons);
    insertionSortById(snapshot, masterCount, insComparisons, insSwaps); // sorts the snapshot only
    int binIdx = binarySearchById(snapshot, masterCount, searchTargetId, binComparisons);

    std::cout << "Searching for complaint #" << searchTargetId << " among " << masterCount << " records:\n";
    std::cout << "  linearSearchById -> index " << linIdx << ", " << linComparisons << " comparison(s)\n";
    std::cout << "  insertionSortById first (" << insComparisons << " comparisons, " << insSwaps << " swaps), then:\n";
    std::cout << "  binarySearchById -> index " << binIdx << ", " << binComparisons << " comparison(s)\n";

    delete[] snapshot; // frees the snapshot array only - NOT the Complaint*s inside it

    // ------------------------------------------------------------
    banner("DSA : Sorting - bubble vs quick sort (city leaderboard)");
    // ------------------------------------------------------------

    int cityCount = cityGrid.getCityCount();
    CityStat* bubbleRanking = new CityStat[cityCount];
    CityStat* quickRanking  = new CityStat[cityCount];
    for (int i = 0; i < cityCount; i++) {
        std::string name = cityGrid.cityNameAt(i);
        int total = cityGrid.getCityTotal(name);
        bubbleRanking[i] = { name, total };
        quickRanking[i]  = { name, total };
    }

    long bubbleComparisons = 0, bubbleSwaps = 0, quickComparisons = 0, quickSwaps = 0;
    bubbleSortByCount(bubbleRanking, cityCount, bubbleComparisons, bubbleSwaps);
    quickSortByCount(quickRanking, 0, cityCount - 1, quickComparisons, quickSwaps);

    std::cout << "Ranking " << cityCount << " cities by total complaints:\n";
    std::cout << "  bubble sort -> " << bubbleComparisons << " comparisons, " << bubbleSwaps << " swaps\n";
    std::cout << "  quick  sort -> " << quickComparisons << " comparisons, " << quickSwaps << " swaps\n";
    for (int i = 0; i < cityCount; i++) {
        std::cout << "  " << (i + 1) << ". " << quickRanking[i].name << " - " << quickRanking[i].count << " complaint(s)\n";
    }
    delete[] bubbleRanking;
    delete[] quickRanking;

    // ------------------------------------------------------------
    banner("DSA : 2D Array (city x category) + Stack (status history)");
    // ------------------------------------------------------------

    cityGrid.printTable();
    std::cout << "\n";
    statusLog.displayRecent(6);

    // ------------------------------------------------------------
    banner("SUMMARY");
    // ------------------------------------------------------------

    std::cout << "Complaint objects created this run : " << Complaint::getTotalComplaints() << "\n";
    std::cout << "All 12 OOP practicals and the full DSA module ran above without leaking or crashing.\n";
    std::cout << "Full maps: docs/OOP_PRACTICALS_MAP.md and docs/DSA_CONCEPTS_MAP.md\n\n";

    return 0; // masterList goes out of scope here -> its destructor frees every complaint it owns
}
