/*
    ================================================================
    URBAN INSIGHTS -- backend/server_main.cpp
    ================================================================
    The missing piece flagged in PROJECT_STATUS.md for the last few
    sessions: an actual HTTP server. Every module built so far meets
    here on a real request instead of living in its own demo:

        request arrives -> OOP builds the right Complaint subclass
                         -> Complaint::evaluateSeverity() calls the
                            real assembly module (assembly/severity.asm)
                         -> Database.cpp persists it in PostgreSQL
                         -> the JSON response goes back to the browser

    Serves the frontend's static files AND the JSON API from the same
    port, so there's no CORS to configure - the whole app is one
    process, one port.

    Build:  make server        (see root Makefile)
    Run:    ./bin/urban_insights_server [port] [pg-connection-string]
    Then:   open http://localhost:8080/
    ================================================================
*/

#include "third_party/httplib.h"
#include "third_party/json.hpp"
#include "Database.h"
#include "Complaint.h"
#include "Exceptions.h"

#include <iostream>
#include <memory>
#include <cstdlib>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <mutex>
#include <unordered_map>

using json = nlohmann::json;

extern "C" int calculateSeverityAsm(int category, int impactScore, int urgencyScore);

static std::string normalizeCategory(std::string category) {
    std::transform(category.begin(), category.end(), category.begin(), [](unsigned char c){ return static_cast<char>(std::tolower(c)); });
    if (category == "road") category = "traffic";
    return category;
}

static int categoryToAsmCode(const std::string& category) {
    if (category == "Traffic" || category == "traffic")         return 0;
    if (category == "Garbage" || category == "garbage")         return 1;
    if (category == "Electricity" || category == "electricity") return 2;
    return 3; // Water / anything else
}

// Builds the right Complaint subclass for a category string, exactly
// like main.cpp's DSA demo does - reused here so a real HTTP request
// exercises the same OOP hierarchy, not a parallel shortcut.
static std::unique_ptr<Complaint> makeComplaint(const std::string& category, const std::string& city,
                                                 const std::string& locality, const std::string& description,
                                                 const std::string& citizen, int impact, int urgency) {
    if (category == "Traffic" || category == "traffic")
        return std::make_unique<TrafficComplaint>(city, locality, description, citizen, impact, urgency);
    if (category == "Garbage" || category == "garbage")
        return std::make_unique<GarbageComplaint>(city, locality, description, citizen, impact, urgency);
    if (category == "Electricity" || category == "electricity")
        return std::make_unique<ElectricityComplaint>(city, locality, description, citizen, impact, urgency);
    return std::make_unique<WaterComplaint>(city, locality, description, citizen, impact, urgency);
}

static void setJson(httplib::Response& res, const json& body, int status = 200) {
    res.status = status;
    res.set_content(body.dump(), "application/json");
}

int main(int argc, char** argv) {
    int port = 8080;
    std::string conninfo = "dbname=urbaninsights";
    if (const char* envPort = std::getenv("PORT")) port = std::atoi(envPort);
    if (argc > 1) port = std::atoi(argv[1]);
    if (argc > 2) conninfo = argv[2];
    else {
        const char* host=std::getenv("DB_HOST"), *db=std::getenv("DB_NAME"), *user=std::getenv("DB_USER"), *pass=std::getenv("DB_PASSWORD"), *dbport=std::getenv("DB_PORT");
        if (db || user || pass || host || dbport) {
            conninfo.clear();
            if(host) conninfo += "host="+std::string(host)+" ";
            if(dbport) conninfo += "port="+std::string(dbport)+" ";
            if(db) conninfo += "dbname="+std::string(db)+" ";
            if(user) conninfo += "user="+std::string(user)+" ";
            if(pass) conninfo += "password="+std::string(pass)+" ";
        }
    }

    Database db(conninfo);
    std::cout << "Database: " << db.statusMessage() << "\n";
    if (!db.ok()) {
        std::cout << "Continuing without a live database - endpoints that need it will\n"
                     "report an error instead of crashing the server. Start PostgreSQL and\n"
                     "load database/schema.sql (+ seed.sql) to get real data.\n";
    }

    httplib::Server svr;
    svr.set_payload_max_length(1024 * 1024);
    std::mutex rateMutex;
    std::unordered_map<std::string, std::pair<std::chrono::steady_clock::time_point, int>> complaintRate;
    const int maxComplaintsPerMinute = 20;

    // Serve the actual frontend + opengl/ (for india-states-data.js) from
    // this same server - one process, one port, no CORS to configure.
    svr.set_mount_point("/", "../frontend");
    svr.set_mount_point("/opengl", "../opengl");

    svr.Get("/api/health", [&](const httplib::Request&, httplib::Response& res) {
        setJson(res, {{"status", "ok"}, {"database", db.ok()}});
    });

    svr.Get("/api/states", [&](const httplib::Request& req, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        std::string category = req.has_param("category") ? normalizeCategory(req.get_param_value("category")) : "all";
        if (category != "all" && category != "traffic" && category != "garbage" && category != "electricity" && category != "water") { setJson(res, {{"error", "invalid category"}}, 400); return; }
        setJson(res, db.getStateSeveritySummary(category));
    });

    svr.Get("/api/map/districts", [&](const httplib::Request& req, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        if (!req.has_param("state")) { setJson(res, {{"error", "state is required"}}, 400); return; }
        std::string category = req.has_param("category") ? normalizeCategory(req.get_param_value("category")) : "all";
        if (category != "all" && category != "traffic" && category != "garbage" && category != "electricity" && category != "water") { setJson(res, {{"error", "invalid category"}}, 400); return; }
        setJson(res, db.getDistrictSeveritySummary(req.get_param_value("state"), category));
    });

    svr.Get("/api/geography", [&](const httplib::Request&, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        setJson(res, db.getGeography());
    });

    svr.Get("/api/rankings/cities", [&](const httplib::Request& req, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        int page = req.has_param("page") ? std::atoi(req.get_param_value("page").c_str()) : 1;
        int pageSize = req.has_param("pageSize") ? std::atoi(req.get_param_value("pageSize").c_str()) : 25;
        std::string state = req.has_param("state") ? req.get_param_value("state") : "";
        std::string district = req.has_param("district") ? req.get_param_value("district") : "";
        std::string severity = req.has_param("severity") ? req.get_param_value("severity") : "";
        if (!severity.empty() && severity != "high" && severity != "medium" && severity != "low") { setJson(res, {{"error", "invalid severity filter"}}, 400); return; }
        setJson(res, db.getCityRankings(page, pageSize, state, district, severity));
    });

    svr.Get("/api/dashboard/summary", [&](const httplib::Request&, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        setJson(res, db.getDashboardSummary());
    });

    svr.Get("/api/departments", [&](const httplib::Request&, httplib::Response& res) {
    if (!db.ok()) {
        setJson(res, {{"error", "database unavailable"}}, 503);
        return;
    }

    setJson(res, db.getDepartments());
});

    svr.Get("/api/complaints", [&](const httplib::Request& req, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        int limit = req.has_param("limit") ? std::atoi(req.get_param_value("limit").c_str()) : 50;
        setJson(res, db.listComplaints(limit));
    });

    svr.Get(R"(/api/complaints/(\d+))", [&](const httplib::Request& req, httplib::Response& res) {
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        int id = std::atoi(req.matches[1].str().c_str());
        json result = db.getComplaintById(id);
        if (result.is_null()) setJson(res, {{"error", "not found"}}, 404);
        else setJson(res, result);
    });

    // Plan.pdf, Map page: "an option to download complaint data in form
    // of excel file" - CSV, which Excel opens natively (double-click),
    // rather than hand-rolling the OOXML .xlsx zip format in C++.
    svr.Get("/api/complaints/export", [&](const httplib::Request&, httplib::Response& res) {
        if (!db.ok()) { res.status = 503; res.set_content("database unavailable", "text/plain"); return; }
        std::string csv = db.exportComplaintsCsv();
        res.set_header("Content-Disposition", "attachment; filename=\"urban-insights-complaints.csv\"");
        res.set_content(csv, "text/csv");
    });

    // The Report page posts here. This is the one request that walks
    // through every module: OOP builds the object, the object's
    // evaluateSeverity() calls the real assembly module, then the
    // result is persisted to Postgres.
    svr.Post("/api/complaints", [&](const httplib::Request& req, httplib::Response& res) {
        {
            std::lock_guard<std::mutex> guard(rateMutex);
            const auto now = std::chrono::steady_clock::now();
            auto &entry = complaintRate[req.remote_addr];
            if (entry.second == 0 || now - entry.first >= std::chrono::minutes(1)) { entry = {now, 1}; }
            else if (++entry.second > maxComplaintsPerMinute) { setJson(res, {{"error", "rate limit exceeded"}}, 429); return; }
        }
        if (!db.ok()) { setJson(res, {{"error", "database unavailable"}}, 503); return; }
        try {
            json body = json::parse(req.body);
            std::string category    = normalizeCategory(body.value("category", ""));
            int stateId             = body.value("stateId", 0);
            int districtId          = body.value("districtId", 0);
            int cityId              = body.value("cityId", 0);
            std::string locality    = body.value("locality", "");
            std::string description = body.value("description", "");
            std::string citizen     = body.value("citizenName", "Anonymous");
            int impact  = body.value("impactScore", 5);
            int urgency = body.value("urgencyScore", 5);

            if ((category != "traffic" && category != "garbage" && category != "electricity" && category != "water") || stateId <= 0 || districtId <= 0 || cityId <= 0 || description.empty() || locality.empty()) {
                setJson(res, {{"error", "valid category, state, district, city, locality and description are required"}}, 400);
                return;
            }
            if (impact < 0 || impact > 10 || urgency < 0 || urgency > 10) {
                setJson(res, {{"error", "impactScore and urgencyScore must be between 0 and 10"}}, 400);
                return;
            }

            // OOP: build the real polymorphic object (throws
            // InvalidComplaintException on bad input, e.g. empty description).
            std::unique_ptr<Complaint> complaint =
                makeComplaint(category, "", locality, description, citizen, impact, urgency);

            // Assembly: the SAME call Complaint::evaluateSeverity() makes
            // internally - done explicitly here too so the HTTP response
            // can report the numeric code alongside the word.
            int severityCode = calculateSeverityAsm(categoryToAsmCode(category), impact, urgency);
            complaint->evaluateSeverity();

            json created = db.createComplaint(category, stateId, districtId, cityId, locality, description, citizen,
                                               impact, urgency, severityCode);
            if (created.contains("error")) { setJson(res, created, 500); return; }
            setJson(res, created, 201);

        } catch (const InvalidComplaintException& e) {
            setJson(res, {{"error", e.what()}}, 400);
        } catch (const std::exception& e) {
            setJson(res, {{"error", std::string("Bad request: ") + e.what()}}, 400);
        }
    });

    const std::string allowedOrigin = std::getenv("URBAN_INSIGHTS_ORIGIN") ? std::getenv("URBAN_INSIGHTS_ORIGIN") : "http://localhost:8080";
    svr.set_default_headers({{"Access-Control-Allow-Origin", allowedOrigin}, {"Access-Control-Allow-Headers", "Content-Type, Authorization"}});

    std::cout << "Urban Insights server listening on http://localhost:" << port << "\n";
    std::cout << "  GET  /api/health\n";
    std::cout << "  GET  /api/states\n";
    std::cout << "  GET  /api/rankings/cities?limit=20\n";
    std::cout << "  GET  /api/dashboard/summary\n";
    std::cout << "  GET  /api/complaints?limit=50\n";
    std::cout << "  GET  /api/complaints/:id\n";
    std::cout << "  GET  /api/complaints/export  (CSV, opens in Excel)\n";
    std::cout << "  POST /api/complaints\n";

    svr.listen("0.0.0.0", port);
    return 0;
}
