#define _USE_MATH_DEFINES

#include <GL/freeglut.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>

namespace {

struct CitySeverity {
	const char* name;
	float x;
	int low;
	int medium;
	int high;
};

// Illustrative local sample; the demo does not query the live database.
constexpr CitySeverity cities[] = {
	{"Pune",      -8.5f,  4,  8, 14},
	{"Mumbai",    -5.1f,  6, 10, 20},
	{"Nashik",    -1.7f,  9,  6,  4},
	{"New Delhi",  1.7f, 12, 13, 16},
	{"Bengaluru",  5.1f,  8, 12,  9},
	{"Jaipur",     8.5f,  7,  6,  5},
};

constexpr float severityColors[][3] = {
	{0.20f, 0.68f, 0.48f},
	{0.91f, 0.65f, 0.24f},
	{0.86f, 0.29f, 0.31f},
};
constexpr float reportHeight = 0.14f;
constexpr float barWidth = 1.65f;
constexpr float barDepth = 1.8f;

bool perspective = true;
bool autoRotate = false;
int windowWidth = 1000;
int windowHeight = 760;
float cameraYaw = 42.0f;
float cameraPitch = 34.0f;
float cameraDistance = 25.0f;
int previousMouseX = 0;
int previousMouseY = 0;
bool dragging = false;

void setMaterialColor(float red, float green, float blue) {
	glColor3f(red, green, blue);
	const GLfloat color[] = {red, green, blue, 1.0f};
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, color);
}

void drawBox(float x, float y, float z, float width, float height, float depth, const float color[3]) {
	setMaterialColor(color[0], color[1], color[2]);
	const float x0 = x - width / 2.0f;
	const float x1 = x + width / 2.0f;
	const float y1 = y + height;
	const float z0 = z - depth / 2.0f;
	const float z1 = z + depth / 2.0f;

	glBegin(GL_QUADS);
	glNormal3f(0.0f, 1.0f, 0.0f);
	glVertex3f(x0, y1, z0); glVertex3f(x0, y1, z1);
	glVertex3f(x1, y1, z1); glVertex3f(x1, y1, z0);

	glNormal3f(0.0f, 0.0f, 1.0f);
	glVertex3f(x0, y, z1); glVertex3f(x1, y, z1);
	glVertex3f(x1, y1, z1); glVertex3f(x0, y1, z1);

	glNormal3f(0.0f, 0.0f, -1.0f);
	glVertex3f(x1, y, z0); glVertex3f(x0, y, z0);
	glVertex3f(x0, y1, z0); glVertex3f(x1, y1, z0);

	glNormal3f(1.0f, 0.0f, 0.0f);
	glVertex3f(x1, y, z1); glVertex3f(x1, y, z0);
	glVertex3f(x1, y1, z0); glVertex3f(x1, y1, z1);

	glNormal3f(-1.0f, 0.0f, 0.0f);
	glVertex3f(x0, y, z0); glVertex3f(x0, y, z1);
	glVertex3f(x0, y1, z1); glVertex3f(x0, y1, z0);
	glEnd();
}

void drawGround() {
	setMaterialColor(0.89f, 0.90f, 0.86f);
	glNormal3f(0.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);
	glVertex3f(-11.0f, 0.0f, -4.5f); glVertex3f(-11.0f, 0.0f, 4.5f);
	glVertex3f( 11.0f, 0.0f,  4.5f); glVertex3f( 11.0f, 0.0f, -4.5f);
	glEnd();

	setMaterialColor(0.75f, 0.78f, 0.74f);
	glNormal3f(0.0f, 1.0f, 0.0f);
	glBegin(GL_LINES);
	for (float x = -10.2f; x <= 10.2f; x += 3.4f) {
		glVertex3f(x, 0.025f, -2.0f); glVertex3f(x, 0.025f, 3.5f);
	}
	for (float z = -2.0f; z <= 3.5f; z += 1.1f) {
		glVertex3f(-10.2f, 0.025f, z); glVertex3f(10.2f, 0.025f, z);
	}
	glEnd();

	setMaterialColor(0.30f, 0.33f, 0.34f);
	glBegin(GL_QUADS);
	glVertex3f(-11.0f, 0.03f, -3.8f); glVertex3f(-11.0f, 0.03f, -2.9f);
	glVertex3f( 11.0f, 0.03f, -2.9f); glVertex3f( 11.0f, 0.03f, -3.8f);
	glEnd();
}

void drawWorldText(float x, float y, float z, const std::string& text) {
	glRasterPos3f(x, y, z);
	for (unsigned char character : text) {
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, character);
	}
}

void drawCity() {
	drawGround();
	for (const CitySeverity& city : cities) {
		const int reports[] = {city.low, city.medium, city.high};
		float baseY = 0.05f;
		for (int severity = 0; severity < 3; ++severity) {
			const float height = reports[severity] * reportHeight;
			drawBox(city.x, baseY, -0.2f, barWidth, height, barDepth, severityColors[severity]);
			baseY += height;
	}
	}

	glDisable(GL_LIGHTING);
	glColor3f(0.12f, 0.17f, 0.18f);
	for (const CitySeverity& city : cities) {
		const int total = city.low + city.medium + city.high;
		const float totalHeight = total * reportHeight;
		drawWorldText(city.x - 0.72f, 0.12f, 1.55f, city.name);
		drawWorldText(city.x - 0.58f, totalHeight + 0.22f, -0.2f, std::to_string(total));
	}
	glEnable(GL_LIGHTING);
}

void drawText(float x, float y, const std::string& text) {
	glRasterPos2f(x, y);
	for (unsigned char character : text) {
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, character);
	}
}

void drawLegendItem(float x, float y, const char* label, const float color[3]) {
	glColor3fv(color);
	glBegin(GL_QUADS);
	glVertex2f(x, y); glVertex2f(x + 10.0f, y);
	glVertex2f(x + 10.0f, y + 10.0f); glVertex2f(x, y + 10.0f);
	glEnd();
	glColor3f(0.12f, 0.17f, 0.18f);
	drawText(x + 16.0f, y + 1.0f, label);
}

void drawOverlay() {
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0.0, static_cast<double>(windowWidth), 0.0, static_cast<double>(windowHeight));
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glColor3f(0.12f, 0.17f, 0.18f);
	drawText(22.0f, static_cast<float>(windowHeight - 30), "URBAN PULSE   /   COMPLAINT SEVERITY BY CITY");
	drawText(22.0f, static_cast<float>(windowHeight - 53),
			 std::string("Projection: ") + (perspective ? "Perspective" : "Orthographic") +
			 "    |    Camera: " + std::to_string(static_cast<int>(cameraYaw)) + " deg    |    Sample: 169 reports");
	const float legendY = static_cast<float>(windowHeight - 78);
	drawLegendItem(22.0f, legendY, "Low", severityColors[0]);
	drawLegendItem(95.0f, legendY, "Medium", severityColors[1]);
	drawLegendItem(195.0f, legendY, "High", severityColors[2]);
	drawText(22.0f, 24.0f, "Bar height = total   Left-drag/arrow orbit   [ ] step 45 deg   A auto 360   Wheel/+/- zoom   P projection");

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}

void display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	const double aspect = static_cast<double>(windowWidth) / windowHeight;
	if (perspective) {
		gluPerspective(48.0, aspect, 0.1, 100.0);
	} else {
		const double halfHeight = cameraDistance * 0.52;
		const double halfWidth = halfHeight * aspect;
		glOrtho(-halfWidth, halfWidth, -halfHeight, halfHeight, 0.1, 100.0);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	const double yaw = cameraYaw * M_PI / 180.0;
	const double pitch = cameraPitch * M_PI / 180.0;
	const double eyeX = cameraDistance * std::cos(pitch) * std::sin(yaw);
	const double eyeY = cameraDistance * std::sin(pitch) + 1.2;
	const double eyeZ = cameraDistance * std::cos(pitch) * std::cos(yaw);
	gluLookAt(eyeX, eyeY, eyeZ, 0.0, 1.4, 0.0, 0.0, 1.0, 0.0);

	const GLfloat lightPosition[] = {-8.0f, 14.0f, 9.0f, 1.0f};
	glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
	drawCity();
	drawOverlay();
	glutSwapBuffers();
}

void reshape(int width, int height) {
	windowWidth = std::max(width, 1);
	windowHeight = std::max(height, 1);
	glViewport(0, 0, windowWidth, windowHeight);
	glutPostRedisplay();
}

void wrapCameraYaw() {
	cameraYaw = std::fmod(cameraYaw, 360.0f);
	if (cameraYaw < 0.0f) cameraYaw += 360.0f;
}

void resetCamera() {
	cameraYaw = 42.0f;
	cameraPitch = 34.0f;
	cameraDistance = 25.0f;
	autoRotate = false;
}

void keyboard(unsigned char key, int, int) {
	switch (key) {
		case 27: std::exit(0);
		case 'p': case 'P': perspective = !perspective; break;
		case 'a': case 'A': autoRotate = !autoRotate; break;
		case '[': cameraYaw -= 45.0f; wrapCameraYaw(); break;
		case ']': cameraYaw += 45.0f; wrapCameraYaw(); break;
		case '+': case '=': cameraDistance = std::max(9.0f, cameraDistance - 1.5f); break;
		case '-': case '_': cameraDistance = std::min(55.0f, cameraDistance + 1.5f); break;
		case 'r': case 'R': resetCamera(); perspective = true; break;
		case '1': cameraYaw = 0.0f; cameraPitch = 20.0f; break;
		case '2': cameraYaw = 42.0f; cameraPitch = 34.0f; break;
		case '3': cameraYaw = 0.0f; cameraPitch = 78.0f; break;
		default: return;
	}
	glutPostRedisplay();
}

void specialKeys(int key, int, int) {
	if (key == GLUT_KEY_LEFT) cameraYaw -= 5.0f;
	if (key == GLUT_KEY_RIGHT) cameraYaw += 5.0f;
	if (key == GLUT_KEY_UP) cameraPitch = std::min(82.0f, cameraPitch + 4.0f);
	if (key == GLUT_KEY_DOWN) cameraPitch = std::max(8.0f, cameraPitch - 4.0f);
	wrapCameraYaw();
	glutPostRedisplay();
}

void mouseButton(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) {
		dragging = state == GLUT_DOWN;
		previousMouseX = x;
		previousMouseY = y;
	}
	if (button == 3 && state == GLUT_DOWN) cameraDistance = std::max(9.0f, cameraDistance - 1.0f);
	if (button == 4 && state == GLUT_DOWN) cameraDistance = std::min(55.0f, cameraDistance + 1.0f);
	glutPostRedisplay();
}

void mouseMotion(int x, int y) {
	if (!dragging) return;
	cameraYaw += (x - previousMouseX) * 0.65f;
	wrapCameraYaw();
	cameraPitch = std::clamp(cameraPitch + (previousMouseY - y) * 0.35f, 8.0f, 82.0f);
	previousMouseX = x;
	previousMouseY = y;
	glutPostRedisplay();
}

void autoOrbit(int) {
	if (autoRotate) {
		cameraYaw += 0.6f;
		wrapCameraYaw();
		glutPostRedisplay();
	}
	glutTimerFunc(16, autoOrbit, 0);
}

} // namespace

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(windowWidth, windowHeight);
	glutCreateWindow("Urban Pulse | CO4 Projection and Viewing");

	glClearColor(0.84f, 0.87f, 0.85f, 1.0f);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
	glShadeModel(GL_SMOOTH);

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(specialKeys);
	glutMouseFunc(mouseButton);
	glutMotionFunc(mouseMotion);
	glutTimerFunc(16, autoOrbit, 0);
	glutMainLoop();
	return 0;
}
