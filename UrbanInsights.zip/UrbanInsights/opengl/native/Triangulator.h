#ifndef TRIANGULATOR_H
#define TRIANGULATOR_H

/*
    ================================================================
    URBAN INSIGHTS -- opengl/native/Triangulator.h
    ================================================================
    Ear-clipping triangulation - a direct C++ port of the same
    algorithm already tested in opengl/webgl-india-map.js. OpenGL
    (same as WebGL) only rasterises triangles, and a state boundary
    is an arbitrary, often-concave polygon, so this is what turns one
    into the other. Ported rather than re-derived so both renderers
    (WebGL for the product's Map page, this native program for the
    CG Lab course) are provably running the same geometry logic.
    ================================================================
*/

#include <vector>
#include <cmath>
#include <cstdint>
#include <algorithm>
using namespace std;
struct Point2 {
    double x, y;
};

inline double cross2(const Point2& o, const Point2& a, const Point2& b) {
    return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

inline bool pointInTriangle(const Point2& p, const Point2& a, const Point2& b, const Point2& c) {
    double d1 = cross2(a, b, p), d2 = cross2(b, c, p), d3 = cross2(c, a, p);
    bool hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    bool hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    return !(hasNeg && hasPos);
}

// Triangulates a single ring, returning a flat list of triangle indices
// into `outPoints` (which this function fills with the ring's points,
// duplicate closing point removed).
inline  vector<int> triangulateRing(const  vector<Point2>& ringIn,  vector<Point2>& outPoints) {
     vector<Point2> pts = ringIn;
    if (pts.size() > 1) {
        const Point2& first = pts.front();
        const Point2& last = pts.back();
        if ( fabs(first.x - last.x) < 1e-9 &&  fabs(first.y - last.y) < 1e-9) {
            pts.pop_back();
        }
    }
    int n = static_cast<int>(pts.size());
    outPoints = pts;
     vector<int> triangles;
    if (n < 3) return triangles;

    double area = 0;
    for (int i = 0; i < n; i++) {
        const Point2& a = pts[i];
        const Point2& b = pts[(i + 1) % n];
        area += a.x * b.y - b.x * a.y;
    }
    if (area < 0) {
         reverse(pts.begin(), pts.end());
        outPoints = pts;
    }

     vector<int> indices(n);
    for (int i = 0; i < n; i++) indices[i] = i;

    int guard = 0;
    while (static_cast<int>(indices.size()) > 3 && guard < 20000) {
        guard++;
        bool earFound = false;
        int m = static_cast<int>(indices.size());
        for (int i = 0; i < m; i++) {
            int iPrev = indices[(i - 1 + m) % m];
            int iCurr = indices[i];
            int iNext = indices[(i + 1) % m];
            const Point2& a = pts[iPrev];
            const Point2& b = pts[iCurr];
            const Point2& c = pts[iNext];
            if (cross2(a, b, c) <= 1e-12) continue;

            bool isEar = true;
            for (int j = 0; j < m; j++) {
                int idx = indices[j];
                if (idx == iPrev || idx == iCurr || idx == iNext) continue;
                if (pointInTriangle(pts[idx], a, b, c)) { isEar = false; break; }
            }
            if (isEar) {
                triangles.push_back(iPrev);
                triangles.push_back(iCurr);
                triangles.push_back(iNext);
                indices.erase(indices.begin() + i);
                earFound = true;
                break;
            }
        }
        if (!earFound) break;
    }
    if (indices.size() == 3) {
        triangles.push_back(indices[0]);
        triangles.push_back(indices[1]);
        triangles.push_back(indices[2]);
    } else if (indices.size() > 3) {
        // Fan-triangulation fallback for the rare leftover from
        // near-degenerate input - keeps every state solid-filled.
        for (size_t i = 1; i + 1 < indices.size(); i++) {
            triangles.push_back(indices[0]);
            triangles.push_back(indices[i]);
            triangles.push_back(indices[i + 1]);
        }
    }
    return triangles;
}

#endif // TRIANGULATOR_H
