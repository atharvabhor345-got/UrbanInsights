/*
    ================================================================
    URBAN INSIGHTS -- opengl/native/main.cpp
    ================================================================
    The Computer Graphics Lab (2310218L) deliverable in the language
    the course actually grades: C++, linked against real OpenGL
    (GL/GLU) and FreeGLUT - not WebGL. Renders the same India severity
    map as the product's browser-based Map page
    (opengl/webgl-india-map.js), using the same tested algorithms
    (ear-clipping triangulation, the same projection math, the same
    hit-testing) ported to C++ rather than re-derived from scratch,
    so both renderers are provably doing the same thing.

    Course outcomes (full detail: docs/CG_CONCEPTS_MAP.md):
        CO1  primitives          -> GL_TRIANGLES (fills), GL_LINE_LOOP (borders)
        CO2  transformations     -> pan/zoom drive glOrtho's parameters every frame
        CO3  2D objects via      -> Triangulator.h's ear-clipping
             algorithms
        CO4  projection/viewing  -> glOrtho + gluOrtho2D-style viewport mapping
        CO5  clipping            -> OpenGL's own clip-space discard on glOrtho's
                                     bounds (states panned off-view are clipped by
                                     the GL pipeline itself - the hardware form of
                                     the same idea webgl-india-map.js does by hand
                                     for its HTML labels)
        CO6  colour/light        -> severity fill colour; a mouse hover
                                     brightens the hovered state (glColor3f)

    Build:  make -C opengl/native        (see opengl/native/Makefile)
    Run:    ./opengl/native/bin/urban_insights_gl
    ================================================================
*/

#define _USE_MATH_DEFINES // MSVC/MinGW: M_PI isn't defined by <cmath> without this

#include <GL/freeglut.h>
#include <vector>
#include <string>
#include <map>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdint>

#include "Triangulator.h"
#include "../../backend/third_party/json.hpp"

using json = nlohmann::json;

// ---------------------------------------------------------------
// Offline educational demo data. This native renderer is not part of the live production data path.
// 
// ---------------------------------------------------------------

enum class Severity { LOW, MEDIUM, HIGH, NONE };

struct SeverityInfo { Severity level; int complaints; };

static const std::map<std::string, SeverityInfo> OFFLINE_DEMO_SEVERITY = {
    {"Maharashtra",        {Severity::HIGH,   3868}},
    {"Delhi",              {Severity::HIGH,   2140}},
    {"Uttar Pradesh",      {Severity::MEDIUM, 1350}},
    {"Rajasthan",          {Severity::MEDIUM,  980}},
    {"Tamil Nadu",         {Severity::MEDIUM, 1120}},
    {"Karnataka",          {Severity::MEDIUM, 1046}},
    {"West Bengal",        {Severity::MEDIUM,  890}},
    {"Gujarat",            {Severity::LOW,     410}},
    {"Jammu and Kashmir",  {Severity::LOW,     145}},
    {"Bihar",              {Severity::LOW,     366}},
    {"Kerala",             {Severity::LOW,     298}},
    {"Punjab",             {Severity::LOW,     210}},
};

static const std::map<std::string, std::string> DISPLAY_NAME_OVERRIDES = {
    {"Orissa", "Odisha"}, {"Uttaranchal", "Uttarakhand"},
};

struct Color3 { float r, g, b; };
static Color3 colorFor(Severity s) {
    switch (s) {
        case Severity::HIGH:   return {0.937f, 0.384f, 0.427f};
        case Severity::MEDIUM: return {0.949f, 0.741f, 0.337f};
        case Severity::LOW:    return {0.333f, 0.784f, 0.600f};
        default:                return {0.522f, 0.541f, 0.616f};
    }
}

// ---------------------------------------------------------------
// A loaded, triangulated state
// ---------------------------------------------------------------

struct GLState {
    std::string name;
    std::string displayName;
    std::vector<std::vector<Point2>> rings;          // original rings, for borders
    std::vector<std::vector<Point2>> triPositions;    // per-ring triangulated points
    std::vector<std::vector<int>> triIndices;         // per-ring triangle index lists
    double bbox[4]; // minLon, minLat, maxLon, maxLat
    double centroid[2];
    Severity severity = Severity::NONE;
    int complaints = 0;
};

static std::vector<GLState> g_states;
static double g_minLon, g_maxLon, g_minLat, g_maxLat;
static double g_centerLon, g_centerLat;
static double g_scaleLon, g_scaleLat; // world-unit -> "fit" scale, aspect-corrected

// view (pan/zoom), applied on top of the fit scale via glOrtho bounds
static double g_zoom = 1.0;
static double g_panX = 0.0, g_panY = 0.0;
static int g_windowW = 900, g_windowH = 760;

static int g_hoveredIndex = -1;
static int g_selectedIndex = -1;

// ---------------------------------------------------------------
// Data loading + CO3: triangulation
// ---------------------------------------------------------------

static void loadStates(const std::string& path) {
    std::ifstream in(path);
    if (!in) {
        std::cerr << "Could not open " << path << "\n";
        std::exit(1);
    }
    json data;
    in >> data;

    g_minLon = g_minLat = 1e18;
    g_maxLon = g_maxLat = -1e18;

    for (const auto& raw : data) {
        GLState st;
        st.name = raw.at("name").get<std::string>();
        auto override_it = DISPLAY_NAME_OVERRIDES.find(st.name);
        st.displayName = (override_it != DISPLAY_NAME_OVERRIDES.end()) ? override_it->second : st.name;

        for (const auto& ring : raw.at("rings")) {
            std::vector<Point2> pts;
            pts.reserve(ring.size());
            for (const auto& p : ring) pts.push_back({p[0].get<double>(), p[1].get<double>()});
            st.rings.push_back(pts);

            std::vector<Point2> outPts;
            std::vector<int> tris = triangulateRing(pts, outPts);
            st.triPositions.push_back(outPts);
            st.triIndices.push_back(tris);
        }

        auto bboxArr = raw.at("bbox");
        st.bbox[0] = bboxArr[0]; st.bbox[1] = bboxArr[1];
        st.bbox[2] = bboxArr[2]; st.bbox[3] = bboxArr[3];
        auto centroidArr = raw.at("centroid");
        st.centroid[0] = centroidArr[0]; st.centroid[1] = centroidArr[1];

        auto sev_it = OFFLINE_DEMO_SEVERITY.find(st.displayName);
        if (sev_it != OFFLINE_DEMO_SEVERITY.end()) {
            st.severity = sev_it->second.level;
            st.complaints = sev_it->second.complaints;
        }

        g_minLon = std::min(g_minLon, st.bbox[0]);
        g_minLat = std::min(g_minLat, st.bbox[1]);
        g_maxLon = std::max(g_maxLon, st.bbox[2]);
        g_maxLat = std::max(g_maxLat, st.bbox[3]);

        g_states.push_back(std::move(st));
    }

    g_centerLon = (g_minLon + g_maxLon) / 2.0;
    g_centerLat = (g_minLat + g_maxLat) / 2.0;

    int totalTris = 0;
    for (auto& s : g_states) for (auto& t : s.triIndices) totalTris += static_cast<int>(t.size() / 3);
    std::cout << "Loaded " << g_states.size() << " states, " << totalTris << " triangles.\n";
}

// ---------------------------------------------------------------
// CO4: projection & viewing - lon/lat -> world units centred at 0,0,
// aspect-corrected by cos(latitude), fit to the window, then pan/zoom
// applied via glOrtho's bounds every frame (see reshape()/display()).
// ---------------------------------------------------------------

static void computeFitScale() {
    double aspectCorrection = std::cos(g_centerLat * M_PI / 180.0);
    double lonSpan = (g_maxLon - g_minLon) * aspectCorrection;
    double latSpan = (g_maxLat - g_minLat);
    double margin = 1.12; // leave a little breathing room around the map
    g_scaleLon = aspectCorrection / (lonSpan / 2.0 * margin);
    g_scaleLat = 1.0 / (latSpan / 2.0 * margin);
}

// world position (unitless, roughly -1..1 at zoom 1) for a lon/lat
static void worldPos(double lon, double lat, double& wx, double& wy) {
    wx = (lon - g_centerLon) * g_scaleLon;
    wy = (lat - g_centerLat) * g_scaleLat;
}

// current glOrtho bounds, incorporating pan/zoom
static void orthoBounds(double& left, double& right, double& bottom, double& top) {
    double halfW = static_cast<double>(g_windowW) / std::min(g_windowW, g_windowH) / g_zoom;
    double halfH = static_cast<double>(g_windowH) / std::min(g_windowW, g_windowH) / g_zoom;
    left = -halfW - g_panX; right = halfW - g_panX;
    bottom = -halfH - g_panY; top = halfH - g_panY;
}

// screen pixel -> world position (inverse of the projection above) -
// used for mouse picking (CO4's viewing transform, run backwards)
static void screenToWorld(int sx, int sy, double& wx, double& wy) {
    double left, right, bottom, top;
    orthoBounds(left, right, bottom, top);
    wx = left + (static_cast<double>(sx) / g_windowW) * (right - left);
    wy = top - (static_cast<double>(sy) / g_windowH) * (top - bottom);
}

static bool pointInRing(double x, double y, const std::vector<Point2>& ring) {
    bool inside = false;
    size_t n = ring.size();
    for (size_t i = 0, j = n - 1; i < n; j = i++) {
        double xi = ring[i].x, yi = ring[i].y;
        double xj = ring[j].x, yj = ring[j].y;
        bool intersect = ((yi > y) != (yj > y)) &&
                          (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    return inside;
}

static int hitTest(double lon, double lat) {
    for (size_t i = 0; i < g_states.size(); i++) {
        const GLState& s = g_states[i];
        if (lon < s.bbox[0] || lon > s.bbox[2] || lat < s.bbox[1] || lat > s.bbox[3]) continue;
        for (const auto& ring : s.rings) {
            std::vector<Point2> lonLatRing = ring; // hitTest works in lon/lat directly
            if (pointInRing(lon, lat, lonLatRing)) return static_cast<int>(i);
        }
    }
    return -1;
}

// ---------------------------------------------------------------
// CO1: primitives.  CO6: colour + a hover "light" highlight.
// ---------------------------------------------------------------

// CO6 texture: a 32x32 diagonal-stripe stipple mask, the classic
// legacy-OpenGL way to pattern-fill a polygon - the same "no data yet"
// hatch idea as webgl-india-map.js's fragment shader, done here with
// glPolygonStipple instead of a shader.
static GLubyte g_hatchStipple[128];
static void buildHatchStipple() {
    for (int row = 0; row < 32; row++) {
        std::uint32_t bits = 0;
        for (int col = 0; col < 32; col++) {
            if (((col + row) / 3) % 2 == 0) bits |= (1u << (31 - col));
        }
        g_hatchStipple[row * 4 + 0] = static_cast<GLubyte>((bits >> 24) & 0xFF);
        g_hatchStipple[row * 4 + 1] = static_cast<GLubyte>((bits >> 16) & 0xFF);
        g_hatchStipple[row * 4 + 2] = static_cast<GLubyte>((bits >> 8) & 0xFF);
        g_hatchStipple[row * 4 + 3] = static_cast<GLubyte>(bits & 0xFF);
    }
}

static void drawState(const GLState& s, bool hovered, bool selected) {
    Color3 c = colorFor(s.severity);
    if (hovered) { c.r += (1 - c.r) * 0.18f; c.g += (1 - c.g) * 0.18f; c.b += (1 - c.b) * 0.18f; }
    glColor3f(c.r, c.g, c.b);

    bool noData = (s.severity == Severity::NONE);
    if (noData) { glEnable(GL_POLYGON_STIPPLE); glPolygonStipple(g_hatchStipple); }

    glBegin(GL_TRIANGLES);
    for (size_t ringIdx = 0; ringIdx < s.triPositions.size(); ringIdx++) {
        const auto& pts = s.triPositions[ringIdx];
        const auto& tris = s.triIndices[ringIdx];
        for (size_t t = 0; t < tris.size(); t += 3) {
            for (int k = 0; k < 3; k++) {
                const Point2& p = pts[tris[t + k]];
                double wx, wy;
                worldPos(p.x, p.y, wx, wy);
                glVertex2d(wx, wy);
            }
        }
    }
    glEnd();

    if (noData) glDisable(GL_POLYGON_STIPPLE);

    glColor3f(selected ? 1.0f : 0.90f, selected ? 1.0f : 0.93f, selected ? 1.0f : 0.99f);
    glLineWidth(selected ? 2.0f : 1.0f);
    for (const auto& ring : s.rings) {
        glBegin(GL_LINE_LOOP);
        for (const auto& p : ring) {
            double wx, wy;
            worldPos(p.x, p.y, wx, wy);
            glVertex2d(wx, wy);
        }
        glEnd();
    }
}

static void display() {
    glClearColor(0.043f, 0.063f, 0.114f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    double left, right, bottom, top;
    orthoBounds(left, right, bottom, top);
    glOrtho(left, right, bottom, top, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    for (size_t i = 0; i < g_states.size(); i++) {
        drawState(g_states[i], static_cast<int>(i) == g_hoveredIndex, static_cast<int>(i) == g_selectedIndex);
    }

    glutSwapBuffers();
}

static void reshape(int w, int h) {
    g_windowW = w; g_windowH = h;
    glViewport(0, 0, w, h);
}

// ---------------------------------------------------------------
// CO2: interactive transformations - pan (drag) & zoom (wheel/keys)
// ---------------------------------------------------------------

static bool g_dragging = false;
static int g_lastX = 0, g_lastY = 0;

static void updateHover(int x, int y) {
    double wx, wy; screenToWorld(x, y, wx, wy);
    double lon = wx / g_scaleLon + g_centerLon;
    double lat = wy / g_scaleLat + g_centerLat;
    int hit = hitTest(lon, lat);
    if (hit != g_hoveredIndex) { g_hoveredIndex = hit; glutPostRedisplay(); }
}

static void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) { g_dragging = true; g_lastX = x; g_lastY = y; }
        else {
            g_dragging = false;
            double wx, wy; screenToWorld(x, y, wx, wy);
            double lon = wx / g_scaleLon + g_centerLon;
            double lat = wy / g_scaleLat + g_centerLat;
            int hit = hitTest(lon, lat);
            g_selectedIndex = hit;
            if (hit >= 0) {
                const GLState& s = g_states[hit];
                const char* label = s.severity == Severity::HIGH ? "High" : s.severity == Severity::MEDIUM ? "Medium"
                                     : s.severity == Severity::LOW ? "Low" : "No data yet";
                std::cout << s.displayName << " -> severity: " << label;
                if (s.complaints > 0) std::cout << ", " << s.complaints << " complaints";
                std::cout << "\n";
                char title[256];
                snprintf(title, sizeof(title), "Urban Insights - CG Lab OpenGL Map | %s (%s)",
                          s.displayName.c_str(), label);
                glutSetWindowTitle(title);
            }
            glutPostRedisplay();
        }
    } else if (button == 3 || button == 4) { // most GLUT builds report the scroll wheel this way
        double factor = (button == 3) ? 1.15 : 1.0 / 1.15;
        g_zoom = std::max(1.0, std::min(14.0, g_zoom * factor));
        glutPostRedisplay();
    }
}

static void mouseMotion(int x, int y) {
    if (g_dragging) {
        double left, right, bottom, top;
        orthoBounds(left, right, bottom, top);
        double dx = (x - g_lastX) / static_cast<double>(g_windowW) * (right - left);
        double dy = (y - g_lastY) / static_cast<double>(g_windowH) * (top - bottom);
        g_panX -= dx;
        g_panY += dy;
        g_lastX = x; g_lastY = y;
        glutPostRedisplay();
    } else {
        updateHover(x, y);
    }
}
static void mousePassive(int x, int y) { updateHover(x, y); }

static void keyboard(unsigned char key, int, int) {
    if (key == 27) std::exit(0);              // Esc
    else if (key == 'r' || key == 'R') { g_zoom = 1.0; g_panX = g_panY = 0.0; glutPostRedisplay(); }
    else if (key == '+') { g_zoom = std::min(14.0, g_zoom * 1.15); glutPostRedisplay(); }
    else if (key == '-') { g_zoom = std::max(1.0, g_zoom / 1.15); glutPostRedisplay(); }
}

int main(int argc, char** argv) {
    std::string dataPath = "india-states.json";
    if (argc > 1) dataPath = argv[1];

    loadStates(dataPath);
    computeFitScale();
    buildHatchStipple();

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(g_windowW, g_windowH);
    glutCreateWindow("Urban Insights - CG Lab OpenGL Map");

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMotion);
    glutPassiveMotionFunc(mousePassive);
    glutKeyboardFunc(keyboard);

    std::cout << "Drag to pan, scroll (or +/-) to zoom, click a state, R to reset, Esc to quit.\n";
    glutMainLoop();
    return 0;
}
