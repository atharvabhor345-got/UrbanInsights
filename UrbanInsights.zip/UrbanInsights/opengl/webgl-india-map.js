/*
    ================================================================
    URBAN INSIGHTS -- opengl/webgl-india-map.js
    ================================================================
    The real "Map" page of the app: an interactive, zoomable/pannable
    choropleth of India, states coloured by complaint severity. This
    is rendered with raw WebGL (the browser's OpenGL ES pipeline) -
    not a picture, not a canvas-2D drawing, an actual GPU pipeline
    with shaders, buffers, and a projection matrix, same as the
    Computer Graphics Lab (2310218L) course asks for.

    How this maps to the course outcomes (full detail in
    docs/CG_CONCEPTS_MAP.md):

        CO1  OpenGL primitives   -> gl.TRIANGLES for state fills,
                                     gl.LINE_LOOP for borders
        CO2  Transformations     -> pan (translate) + zoom (scale),
                                     recombined into the matrix every frame
        CO3  2D objects via      -> ear-clipping triangulation turns each
             algorithms             state's boundary polygon into GPU triangles
        CO4  Projection/viewing  -> lon/lat -> clip space via a uProjection
                                     mat3 (equirectangular + aspect correction)
        CO5  Clipping            -> off-screen state labels are explicitly
                                     culled against the visible viewport
        CO6  Texture/light/colour-> severity fill colour, a hover "light"
                                     highlight, and a procedural hatch
                                     texture for states with no data yet

    Boundary data: opengl/india-states-data.js (load that file first).
    Depends on nothing else - no build step, no external requests.
    ================================================================
*/
(function () {
  'use strict';

  // ================================================================
  // CO3: polygon triangulation (ear clipping), so the GPU - which can
  // only draw triangles - can fill an arbitrary (possibly concave)
  // state boundary. A fan-triangulation fallback runs for the rare
  // vertex ear-clipping can't resolve, so every state fills solid
  // with no gaps.
  // ================================================================
  function cross(o, a, b) {
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  }

  function pointInTriangle(p, a, b, c) {
    const d1 = cross(a, b, p), d2 = cross(b, c, p), d3 = cross(c, a, p);
    const hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    const hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    return !(hasNeg && hasPos);
  }

  function triangulateRing(ring) {
    let pts = ring.slice();
    if (pts.length > 1) {
      const first = pts[0], last = pts[pts.length - 1];
      if (Math.abs(first[0] - last[0]) < 1e-9 && Math.abs(first[1] - last[1]) < 1e-9) pts.pop();
    }
    const n = pts.length;
    if (n < 3) return { positions: pts, indices: [] };

    let area = 0;
    for (let i = 0; i < n; i++) {
      const a = pts[i], b = pts[(i + 1) % n];
      area += a[0] * b[1] - b[0] * a[1];
    }
    if (area < 0) pts.reverse(); // ear-clipping below assumes CCW winding

    let indices = pts.map((_, i) => i);
    const triangles = [];
    let guard = 0;
    while (indices.length > 3 && guard < 20000) {
      guard++;
      let earFound = false;
      for (let i = 0; i < indices.length; i++) {
        const iPrev = indices[(i - 1 + indices.length) % indices.length];
        const iCurr = indices[i];
        const iNext = indices[(i + 1) % indices.length];
        const a = pts[iPrev], b = pts[iCurr], c = pts[iNext];
        if (cross(a, b, c) <= 1e-12) continue; // reflex/collinear -> can't be an ear

        let isEar = true;
        for (let j = 0; j < indices.length; j++) {
          const idx = indices[j];
          if (idx === iPrev || idx === iCurr || idx === iNext) continue;
          if (pointInTriangle(pts[idx], a, b, c)) { isEar = false; break; }
        }
        if (isEar) {
          triangles.push(iPrev, iCurr, iNext);
          indices.splice(i, 1);
          earFound = true;
          break;
        }
      }
      if (!earFound) break;
    }
    if (indices.length === 3) {
      triangles.push(indices[0], indices[1], indices[2]);
    } else if (indices.length > 3) {
      // Fallback fan for the rare leftover from near-degenerate input
      // (a couple of these state outlines have tiny self-intersections
      // even after simplification) - keeps every state solid-filled.
      for (let i = 1; i < indices.length - 1; i++) {
        triangles.push(indices[0], indices[i], indices[i + 1]);
      }
    }
    return { positions: pts, indices: triangles };
  }

  // ================================================================
  // Point-in-polygon (ray casting) - hit testing for hover/click.
  // A cheap bounding-box pre-check skips most states before the
  // exact-but-pricier ring test ever runs.
  // ================================================================
  function pointInRing(pt, ring) {
    let inside = false;
    const x = pt[0], y = pt[1];
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const xi = ring[i][0], yi = ring[i][1];
      const xj = ring[j][0], yj = ring[j][1];
      const intersect = ((yi > y) !== (yj > y)) &&
        (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  function hitTestState(lon, lat, state) {
    const [minx, miny, maxx, maxy] = state.bbox;
    if (lon < minx || lon > maxx || lat < miny || lat > maxy) return false;
    return state.rings.some((r) => pointInRing([lon, lat], r));
  }

  // ================================================================
    // ================================================================
  // Fallback severity data - used immediately so the map paints
  // without waiting on a network round-trip, then silently replaced
  // by real numbers from GET /api/states the moment that resolves
  // (see loadLiveSeverity() below). If the page is opened directly
  // as a file, or the server isn't running, this is what's shown -
  // the map still works, just without live data.
  // ================================================================
  const DISPLAY_NAME_OVERRIDES = { Orissa: 'Odisha', Uttaranchal: 'Uttarakhand' };

  const COLORS = {
    high:   [0.937, 0.384, 0.427],  // #ef626d
    medium: [0.949, 0.741, 0.337],  // #f2bd56
    low:    [0.333, 0.784, 0.600],  // #55c899
    none:   [0.718, 0.733, 0.784],  // muted grey-blue
    border: [0.90, 0.93, 0.99],
    hoverLift: 0.16,                 // CO6 "light": brighten on hover
  };

  // ================================================================
  // mat3 helpers - 2D homogeneous transform (column-major, like the
  // mat4 convention OpenGL itself uses, just one dimension down).
  // ================================================================
  function mat3Multiply(a, b) {
    const out = new Array(9);
    for (let col = 0; col < 3; col++) {
      for (let row = 0; row < 3; row++) {
        let sum = 0;
        for (let k = 0; k < 3; k++) sum += a[k * 3 + row] * b[col * 3 + k];
        out[col * 3 + row] = sum;
      }
    }
    return out;
  }

  // ================================================================
  // Shaders
  // ================================================================
  const VERT_SRC = `
    attribute vec2 aPosition; // lon, lat
    uniform mat3 uProjection; // CO4: lon/lat -> clip space (fit + pan + zoom)
    void main() {
      vec3 clip = uProjection * vec3(aPosition, 1.0);
      gl_Position = vec4(clip.xy, 0.0, 1.0);
    }
  `;
  const FRAG_SRC = `
    precision mediump float;
    uniform vec3 uColor;
    uniform float uHatch; // CO6: 1.0 draws a diagonal "no data" texture
    void main() {
      vec3 color = uColor;
      if (uHatch > 0.5) {
        float stripe = mod(gl_FragCoord.x + gl_FragCoord.y, 12.0);
        if (stripe < 6.0) color *= 0.82;
      }
      gl_FragColor = vec4(color, 1.0);
    }
  `;

  function compileShader(gl, type, src) {
    const sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      throw new Error('Shader compile error: ' + gl.getShaderInfoLog(sh));
    }
    return sh;
  }

  function createProgram(gl, vsSrc, fsSrc) {
    const p = gl.createProgram();
    gl.attachShader(p, compileShader(gl, gl.VERTEX_SHADER, vsSrc));
    gl.attachShader(p, compileShader(gl, gl.FRAGMENT_SHADER, fsSrc));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      throw new Error('Program link error: ' + gl.getProgramInfoLog(p));
    }
    return p;
  }

  // ================================================================
  // Main entry point
  // ================================================================
  function initIndiaMap(opts) {
    const canvas = opts.canvas;
    const labelLayer = opts.labelLayer;       // container for HTML state-name labels
    const tooltipEl = opts.tooltipEl;         // small hover tooltip element
    const infoPanel = opts.infoPanel;         // { name, severity, complaints, badge } elements
    const searchInput = opts.searchInput;     // optional <input>
    const searchResults = opts.searchResults; // optional results dropdown container

    const gl = canvas.getContext('webgl', { antialias: true });
    if (!gl) { console.error('WebGL unavailable'); return null; }

    const geometry = window.INDIA_STATES_GEOMETRY || [];

    const program = createProgram(gl, VERT_SRC, FRAG_SRC);
    gl.useProgram(program);
    const aPosition = gl.getAttribLocation(program, 'aPosition');
    const uProjection = gl.getUniformLocation(program, 'uProjection');
    const uColor = gl.getUniformLocation(program, 'uColor');
    const uHatch = gl.getUniformLocation(program, 'uHatch');

    // ---- build GPU buffers (triangulated fill + border rings) for one
    // feature - reused for both India-level states and, on drill-in,
    // a state's districts (see drillIntoState() further down). ----
    function buildFeatureBuffers(raw, severity, complaints, metrics) {
      const fillPositions = [];
      const fillIndices = [];
      raw.rings.forEach((ring) => {
        const { positions, indices } = triangulateRing(ring);
        const base = fillPositions.length / 2;
        positions.forEach((p) => fillPositions.push(p[0], p[1]));
        indices.forEach((idx) => fillIndices.push(base + idx));
      });

      const fillVBO = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, fillVBO);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(fillPositions), gl.STATIC_DRAW);
      const fillIBO = gl.createBuffer();
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, fillIBO);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(fillIndices), gl.STATIC_DRAW);

      const borderBuffers = raw.rings.map((ring) => {
        let pts = ring;
        if (pts.length > 1) {
          const f = pts[0], l = pts[pts.length - 1];
          if (Math.abs(f[0] - l[0]) < 1e-9 && Math.abs(f[1] - l[1]) < 1e-9) pts = pts.slice(0, -1);
        }
        const flat = [];
        pts.forEach((p) => flat.push(p[0], p[1]));
        const vbo = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(flat), gl.STATIC_DRAW);
        return { vbo, count: pts.length };
      });

      return {
        name: raw.name,
        displayName: raw.displayName || raw.name,
        rings: raw.rings,
        bbox: raw.bbox,
        centroid: raw.centroid,
        fillVBO, fillIndexCount: fillIndices.length, fillIBO,
        borderBuffers,
        severity, complaints,
        metrics: metrics || { total: complaints || 0, active: 0, high: 0, medium: 0, low: 0, resolved: 0 },
        labelEl: null,
      };
    }

    const states = geometry.map((raw) => {
      const displayName = DISPLAY_NAME_OVERRIDES[raw.name] || raw.name;
      return buildFeatureBuffers(Object.assign({}, raw, { displayName }), 'none', 0);
    });

    // ---- CO4: base fit transform (lon/lat -> clip space) ----
    // Mutable (not const): drilling into a state recomputes all of this
    // against that state's own bbox instead of all of India's - see
    // setBounds()/drillIntoState() further down.
    let minLon = Infinity, maxLon = -Infinity, minLat = Infinity, maxLat = -Infinity;
    states.forEach((s) => {
      minLon = Math.min(minLon, s.bbox[0]); minLat = Math.min(minLat, s.bbox[1]);
      maxLon = Math.max(maxLon, s.bbox[2]); maxLat = Math.max(maxLat, s.bbox[3]);
    });
    let centerLon = (minLon + maxLon) / 2;
    let centerLat = (minLat + maxLat) / 2;
    let aspectCorrection = Math.cos(centerLat * Math.PI / 180);
    let lonSpan = (maxLon - minLon) * aspectCorrection;
    let latSpan = (maxLat - minLat);
    const indiaBounds = { minLon, maxLon, minLat, maxLat }; // kept to restore on exitDrilldown()

    let scaleLon = 1, scaleLat = 1; // filled in by fitToCanvas()

    function setBounds(bMinLon, bMinLat, bMaxLon, bMaxLat) {
      centerLon = (bMinLon + bMaxLon) / 2;
      centerLat = (bMinLat + bMaxLat) / 2;
      aspectCorrection = Math.cos(centerLat * Math.PI / 180);
      lonSpan = (bMaxLon - bMinLon) * aspectCorrection;
      latSpan = (bMaxLat - bMinLat);
      fitToCanvas();
    }

    function fitToCanvas() {
      const cssW = canvas.clientWidth || canvas.width;
      const cssH = canvas.clientHeight || canvas.height;
      canvas.width = Math.round(cssW * (window.devicePixelRatio || 1));
      canvas.height = Math.round(cssH * (window.devicePixelRatio || 1));
      const margin = 0.90;
      const availW = canvas.width * margin;
      const availH = canvas.height * margin;
      const worldToPixel = Math.min(availW / lonSpan, availH / latSpan);
      scaleLon = aspectCorrection * worldToPixel / (canvas.width / 2);
      scaleLat = worldToPixel / (canvas.height / 2);
    }
    fitToCanvas();

    // ---- CO2: interactive view transform (pan + zoom) ----
    const view = { zoom: 1, panX: 0, panY: 0, minZoom: 1, maxZoom: 12 };

    function project(lon, lat) {
      const clipX = (lon - centerLon) * scaleLon * view.zoom + view.panX;
      const clipY = (lat - centerLat) * scaleLat * view.zoom + view.panY;
      return [clipX, clipY];
    }
    function unproject(clipX, clipY) {
      const lon = (clipX - view.panX) / (scaleLon * view.zoom) + centerLon;
      const lat = (clipY - view.panY) / (scaleLat * view.zoom) + centerLat;
      return [lon, lat];
    }
    function currentMatrix() {
      // column-major 3x3: [sx,0,0, 0,sy,0, tx,ty,1]
      return [
        scaleLon * view.zoom, 0, 0,
        0, scaleLat * view.zoom, 0,
        -centerLon * scaleLon * view.zoom + view.panX,
        -centerLat * scaleLat * view.zoom + view.panY, 1,
      ];
    }

    function clampPan() {
      // Keep at least a sliver of India on-screen at all times.
      const limit = 1.4 * view.zoom;
      view.panX = Math.max(-limit, Math.min(limit, view.panX));
      view.panY = Math.max(-limit, Math.min(limit, view.panY));
    }

    // ---- render ----
    let hoveredState = null;
    let selectedState = null;
    let mode = 'india';           // 'india' | 'district'
    let drilldownStateName = null; // displayName of the state currently drilled into
    let currentFeatures = states;  // what render()/hit-testing operate on right now

    function render() {
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0.043, 0.063, 0.114, 1); // matches the app's dark map background
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(program);
      gl.uniformMatrix3fv(uProjection, false, currentMatrix());
      gl.enableVertexAttribArray(aPosition);

      // CO1: fill every feature - one gl.TRIANGLES draw call each
      currentFeatures.forEach((s) => {
        let [r, g, b] = severityColor(s.metrics);
        if (s === hoveredState) {
          r += (1 - r) * COLORS.hoverLift; g += (1 - g) * COLORS.hoverLift; b += (1 - b) * COLORS.hoverLift;
        }
        gl.bindBuffer(gl.ARRAY_BUFFER, s.fillVBO);
        gl.vertexAttribPointer(aPosition, 2, gl.FLOAT, false, 0, 0);
        gl.uniform3f(uColor, r, g, b);
        gl.uniform1f(uHatch, s.severity === 'none' ? 1.0 : 0.0);
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, s.fillIBO);
        gl.drawElements(gl.TRIANGLES, s.fillIndexCount, gl.UNSIGNED_SHORT, 0);
      });

      // CO1: borders - one gl.LINE_LOOP draw call per ring
      gl.uniform1f(uHatch, 0.0);
      currentFeatures.forEach((s) => {
        const isSelected = s === selectedState;
        gl.uniform3f(uColor, ...(isSelected ? [1, 1, 1] : COLORS.border));
        gl.lineWidth(isSelected ? 2 : 1);
        s.borderBuffers.forEach((b) => {
          gl.bindBuffer(gl.ARRAY_BUFFER, b.vbo);
          gl.vertexAttribPointer(aPosition, 2, gl.FLOAT, false, 0, 0);
          gl.drawArrays(gl.LINE_LOOP, 0, b.count);
        });
      });

      updateLabels();
    }

    // ---- CO5: clipping - only place a label if it actually falls
    // within the visible canvas, computed explicitly every frame
    // rather than relying only on hardware clip-space discard. ----
    function updateLabels() {
      if (!labelLayer) return;
      const w = canvas.clientWidth, h = canvas.clientHeight;
      currentFeatures.forEach((s) => {
        if (!s.labelEl) return;
        const [cx, cy] = project(s.centroid[0], s.centroid[1]);
        const px = (cx + 1) / 2 * w;
        const py = (1 - cy) / 2 * h;
        const margin = 40;
        // District mode: always show (there are few enough per state to
        // read comfortably). India mode: only "important" states or once
        // zoomed in enough, same as before.
        const worthShowing = mode === 'district' || s.severity !== 'none' || view.zoom > 3.2;
        const visible = px > -margin && px < w + margin && py > -margin && py < h + margin && worthShowing;
        if (!visible) { s.labelEl.style.display = 'none'; return; }
        s.labelEl.style.display = 'block';
        s.labelEl.style.left = px + 'px';
        s.labelEl.style.top = py + 'px';
      });
    }

    function buildLabels() {
      if (!labelLayer) return;
      labelLayer.innerHTML = '';
      currentFeatures.forEach((s) => {
        const el = document.createElement('div');
        el.className = 'india-map-label';
        el.textContent = s.displayName;
        labelLayer.appendChild(el);
        s.labelEl = el;
      });
    }
    buildLabels();

    // ---- CO3 (again, at a smaller scale) + drill-down: on-demand
    // district-level geometry, loaded and triangulated only for the one
    // state the person actually clicks into, not all 594 up front. ----
    const districtFeatureCache = {};   // slug -> already-built features
    const districtScriptPromises = {}; // slug -> in-flight/loaded script promise

    function districtVarName(slug) {
      return 'INDIA_DISTRICTS_' + slug.replace(/-/g, '_').toUpperCase();
    }

    function loadDistrictScript(slug) {
      const varName = districtVarName(slug);
      if (window[varName]) return Promise.resolve(window[varName]);
      if (districtScriptPromises[slug]) return districtScriptPromises[slug];
      districtScriptPromises[slug] = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        // Relative to the HTML document (same as how index.html itself
        // references this file: "../opengl/webgl-india-map.js"), NOT
        // relative to this script - browsers always resolve a new
        // <script src> against the page's URL, never the currently
        // executing script's location.
        script.src = '../opengl/districts/' + slug + '.js';
        script.onload = () => {
          if (window[varName]) resolve(window[varName]);
          else reject(new Error('districts/' + slug + '.js did not define ' + varName));
        };
        script.onerror = () => reject(new Error('failed to load districts/' + slug + '.js'));
        document.head.appendChild(script);
      });
      return districtScriptPromises[slug];
    }

    function drillIntoState(state) {
      const manifest = window.INDIA_DISTRICTS_MANIFEST || {};
      const slug = manifest[state.displayName];
      if (!slug) return;
      if (drillButton) { drillButton.textContent = 'Loading districts…'; drillButton.disabled = true; }
      Promise.all([loadDistrictScript(slug), fetch('/api/map/districts?state=' + encodeURIComponent(state.displayName) + '&category=' + encodeURIComponent(currentCategory))])
        .then(async ([rawDistricts, response]) => {
          if (!response.ok) throw new Error('District API HTTP ' + response.status);
          const rows = await response.json();
          const byName = {}; rows.forEach(r => { byName[r.district] = normalizeMetrics(r); });
          const built = rawDistricts.map(raw => { const row = byName[raw.name]; return buildFeatureBuffers(raw, row ? row.severity : 'none', row ? row.total : 0, row || undefined); });
          districtFeatureCache[slug + '|' + currentCategory] = built;
          mode='district'; drilldownStateName=state.displayName; currentFeatures=built; hoveredState=null;
          let dMinLon=Infinity,dMaxLon=-Infinity,dMinLat=Infinity,dMaxLat=-Infinity; built.forEach(d=>{dMinLon=Math.min(dMinLon,d.bbox[0]);dMinLat=Math.min(dMinLat,d.bbox[1]);dMaxLon=Math.max(dMaxLon,d.bbox[2]);dMaxLat=Math.max(dMaxLat,d.bbox[3]);});
          setBounds(dMinLon,dMinLat,dMaxLon,dMaxLat); view.zoom=1; view.panX=0; view.panY=0; buildLabels(); selectState(null); updateBackControl(); render();
        })
        .catch(err => { console.error('India map district API error',err); if(drillButton){drillButton.textContent='District data unavailable';drillButton.disabled=false;} });
    }

    function exitDrilldown() {
      if (mode !== 'district') return;
      mode = 'india';
      drilldownStateName = null;
      currentFeatures = states;
      hoveredState = null;
      setBounds(indiaBounds.minLon, indiaBounds.minLat, indiaBounds.maxLon, indiaBounds.maxLat);
      view.zoom = 1; view.panX = 0; view.panY = 0;
      buildLabels();
      selectState(null);
      updateBackControl();
      render();
    }

    // "<- Back to India Map" - a floating control on the canvas itself,
    // shown only while drilled into a state.
    let backControl = null;
    function updateBackControl() {
      if (!canvas.parentElement) return;
      if (mode === 'district') {
        if (!backControl) {
          backControl = document.createElement('button');
          backControl.className = 'india-map-back-control';
          backControl.addEventListener('click', exitDrilldown);
          canvas.parentElement.appendChild(backControl);
        }
        backControl.textContent = '\u2190 ' + drilldownStateName;
        backControl.style.display = 'block';
      } else if (backControl) {
        backControl.style.display = 'none';
      }
    }

    // ---- info panel + selection ----
    function describeSeverity(level) {
      return { high: 'High', medium: 'Medium', low: 'Low', none: 'No data yet' }[level] || 'No data yet';
    }

    let drillButton = null;
    function selectState(s) {
      selectedState = s;
      if (!infoPanel) return;
      if (!s) {
        infoPanel.root.classList.remove('is-active');
        if (drillButton) drillButton.style.display = 'none';
        return;
      }
      infoPanel.root.classList.add('is-active');
      infoPanel.name.textContent = s.displayName;
      infoPanel.severity.textContent = describeSeverity(s.severity);
      infoPanel.severity.className = 'india-map-info-badge ' + s.severity;
      infoPanel.complaints.textContent = s.metrics.total.toLocaleString();
      if (infoPanel.breakdown) infoPanel.breakdown.textContent = [s.metrics.active,s.metrics.high,s.metrics.medium,s.metrics.low,s.metrics.resolved].join(' / ');

      const manifest = window.INDIA_DISTRICTS_MANIFEST || {};
      const hasDistricts = mode === 'india' && manifest[s.displayName];
      if (hasDistricts) {
        if (!drillButton) {
          drillButton = document.createElement('button');
          drillButton.className = 'india-map-drill-button';
          infoPanel.root.appendChild(drillButton);
        }
        drillButton.disabled = false;
        drillButton.textContent = 'View city-level map \u2192';
        drillButton.style.display = 'block';
        drillButton.onclick = () => drillIntoState(s);
      } else if (drillButton) {
        drillButton.style.display = 'none';
      }
    }

    function flyTo(s, zoomLevel) {
      const [cx, cy] = [(s.bbox[0] + s.bbox[2]) / 2, (s.bbox[1] + s.bbox[3]) / 2];
      view.zoom = zoomLevel || 3;
      view.panX = -(cx - centerLon) * scaleLon * view.zoom;
      view.panY = -(cy - centerLat) * scaleLat * view.zoom;
      clampPan();
      render();
    }

    // ---- interaction: wheel zoom (centred on the cursor) ----
    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ndcY = 1 - ((e.clientY - rect.top) / rect.height) * 2;
      const zoomOld = view.zoom;
      const factor = e.deltaY < 0 ? 1.18 : 1 / 1.18;
      const zoomNew = Math.max(view.minZoom, Math.min(view.maxZoom, zoomOld * factor));
      view.panX = ndcX - (ndcX - view.panX) * (zoomNew / zoomOld);
      view.panY = ndcY - (ndcY - view.panY) * (zoomNew / zoomOld);
      view.zoom = zoomNew;
      clampPan();
      render();
    }, { passive: false });

    // ---- interaction: drag to pan ----
    let dragging = false, lastX = 0, lastY = 0, dragMoved = false;
    canvas.addEventListener('mousedown', (e) => {
      dragging = true; dragMoved = false; lastX = e.clientX; lastY = e.clientY;
    });
    window.addEventListener('mouseup', () => { dragging = false; });
    canvas.addEventListener('mouseleave', () => {
      if (tooltipEl) tooltipEl.style.display = 'none';
      if (hoveredState) { hoveredState = null; render(); }
    });

    canvas.addEventListener('mousemove', (e) => {
      const rect = canvas.getBoundingClientRect();
      if (dragging) {
        const dx = e.clientX - lastX, dy = e.clientY - lastY;
        if (Math.abs(dx) + Math.abs(dy) > 2) dragMoved = true;
        view.panX += (dx / rect.width) * 2;
        view.panY -= (dy / rect.height) * 2;
        lastX = e.clientX; lastY = e.clientY;
        clampPan();
        render();
        return;
      }
      const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ndcY = 1 - ((e.clientY - rect.top) / rect.height) * 2;
      const [lon, lat] = unproject(ndcX, ndcY);
      const hit = currentFeatures.find((s) => hitTestState(lon, lat, s)) || null;
      if (hit !== hoveredState) { hoveredState = hit; render(); }
      if (tooltipEl) {
        if (hit) {
          tooltipEl.style.display = 'block';
          tooltipEl.style.left = (e.clientX - rect.left + 14) + 'px';
          tooltipEl.style.top = (e.clientY - rect.top + 10) + 'px';
          tooltipEl.textContent = hit.displayName + ' \u00b7 ' + describeSeverity(hit.severity);
        } else {
          tooltipEl.style.display = 'none';
        }
      }
    });

    canvas.addEventListener('click', (e) => {
      if (dragMoved) return; // a drag just ended - don't also treat it as a click
      const rect = canvas.getBoundingClientRect();
      const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ndcY = 1 - ((e.clientY - rect.top) / rect.height) * 2;
      const [lon, lat] = unproject(ndcX, ndcY);
      const hit = currentFeatures.find((s) => hitTestState(lon, lat, s)) || null;
      selectState(hit);
      render();
    });

    window.addEventListener('resize', () => { fitToCanvas(); render(); });

    // ---- search ----
    if (searchInput && searchResults) {
      searchInput.addEventListener('input', () => {
        const q = searchInput.value.trim().toLowerCase();
        searchResults.innerHTML = '';
        if (!q) { searchResults.style.display = 'none'; return; }
        const matches = states.filter((s) => s.displayName.toLowerCase().includes(q)).slice(0, 6);
        if (!matches.length) { searchResults.style.display = 'none'; return; }
        searchResults.style.display = 'block';
        matches.forEach((s) => {
          const item = document.createElement('div');
          item.className = 'india-map-search-item';
          item.textContent = s.displayName;
          item.onclick = () => {
            exitDrilldown(); // searching always searches states; leave district mode if active
            flyTo(s, 3.4);
            selectState(s);
            searchResults.style.display = 'none';
            searchInput.value = s.displayName;
          };
          searchResults.appendChild(item);
        });
      });
      document.addEventListener('click', (e) => {
        if (e.target !== searchInput) searchResults.style.display = 'none';
      });
    }

    function zoomBy(factor) {
      // Button-driven zoom anchors on screen centre (clip 0,0): the same
      // derivation as the cursor-anchored wheel zoom, with ndcX=ndcY=0.
      const zoomOld = view.zoom;
      const zoomNew = Math.max(view.minZoom, Math.min(view.maxZoom, zoomOld * factor));
      const ratio = zoomNew / zoomOld;
      view.panX *= ratio;
      view.panY *= ratio;
      view.zoom = zoomNew;
      clampPan();
      render();
    }

    function resetView() {
      if (mode === 'district') { exitDrilldown(); return; } // exitDrilldown already resets+renders
      view.zoom = 1; view.panX = 0; view.panY = 0;
      selectState(null);
      hoveredState = null;
      render();
    }

    // ================================================================
    // Live data is authoritative: no demo/fallback business metrics are painted.
    // ================================================================
    function weightedSeverityScore(row) {
      if (!row) return null;
      const high = Number(row.high || 0);
      const medium = Number(row.medium || 0);
      const low = Number(row.low || 0);
      const total = high + medium + low;
      return total ? (3 * high + 2 * medium + low) / (3 * total) : null;
    }

    function deriveLevel(row) {
      const score = weightedSeverityScore(row);
      if (score === null) return 'none';
      if (score >= 5 / 6) return 'high';
      if (score >= 1 / 2) return 'medium';
      return 'low';
    }

    function blendColors(start, end, amount) {
      return start.map((value, index) => value + (end[index] - value) * amount);
    }

    function severityColor(row) {
      const score = weightedSeverityScore(row);
      if (score === null) return COLORS.none;
      if (score <= 2 / 3) {
        return blendColors(COLORS.low, COLORS.medium, (score - 1 / 3) * 3);
      }
      return blendColors(COLORS.medium, COLORS.high, (score - 2 / 3) * 3);
    }

    function normalizeMetrics(row) {
      if (!row) return null;
      const metrics = {
        total: Number(row.total_complaints ?? row.total ?? 0),
        active: Number(row.active_complaints ?? row.active ?? 0),
        high: Number(row.high ?? 0),
        medium: Number(row.medium ?? 0),
        low: Number(row.low ?? 0),
        resolved: Number(row.resolved_count ?? row.resolved ?? 0),
      };
      metrics.severity = deriveLevel(metrics);
      return metrics;
    }

    let currentCategory = 'all';
    function loadLiveSeverity(category) {
      currentCategory = category || currentCategory || 'all';
      if (typeof fetch !== 'function') return;
      fetch('/api/states?category=' + encodeURIComponent(currentCategory))
        .then(r => r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status)))
        .then(rows => {
          const byName={}; rows.forEach(row=>{byName[row.name]=normalizeMetrics(row);}); let changed=false;
          states.forEach(s=>{const row=byName[s.displayName]; const level=row?row.severity:'none'; const total=row?row.total:0; if(level!==s.severity||total!==s.complaints) changed=true; s.severity=level; s.complaints=total; s.metrics=row||{total:0,active:0,high:0,medium:0,low:0,resolved:0};});
          if(changed){render(); if(selectedState) selectState(selectedState);}
        }).catch(err=>console.error('India map: live severity API unavailable',err));
    }

    render();
    loadLiveSeverity('all');
    return {
      render, flyTo, selectState, zoomBy, resetView, states,
      refreshLiveSeverity: loadLiveSeverity,
      drillIntoState, exitDrilldown,
    };
  }

  window.UrbanInsightsIndiaMap = { init: initIndiaMap };
})();
