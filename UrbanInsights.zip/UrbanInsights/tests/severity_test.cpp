#include <cassert>
#include <iostream>

extern "C" int calculateSeverityAsm(int category, int impactScore, int urgencyScore);

int main() {
    // 0=Low, 1=Medium, 2=High. Covers each category and boundaries.
    assert(calculateSeverityAsm(0, 0, 0) == 0);
    assert(calculateSeverityAsm(0, 4, 4) == 1);
    assert(calculateSeverityAsm(0, 10, 10) == 2);
    assert(calculateSeverityAsm(1, 3, 3) == 0);
    assert(calculateSeverityAsm(1, 5, 5) == 1);
    assert(calculateSeverityAsm(1, 10, 10) == 2);
    assert(calculateSeverityAsm(2, 3, 3) == 0);
    assert(calculateSeverityAsm(2, 5, 5) == 1);
    assert(calculateSeverityAsm(2, 10, 10) == 2);
    assert(calculateSeverityAsm(3, 3, 3) == 0);
    assert(calculateSeverityAsm(3, 5, 5) == 1);
    assert(calculateSeverityAsm(3, 10, 10) == 2);
    std::cout << "Assembly severity tests passed\n";
}
